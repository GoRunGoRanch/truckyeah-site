#!/usr/bin/env bash
# The denominator run.
#
# The 57-winner study found winners only. It could not say how many
# identical-looking contracts expired worthless. This script answers that.
#
# It enters AFTER the catalyst is public — the day of (entry-delay 0) and the
# day after (entry-delay 1) — and counts every trade, not just the good ones.
#
# Usage:  bash scripts/run_denominator.sh
#
# Takes a while. It is reading cached history where it can, so a second run is
# much faster than the first. Safe to stop and restart.

set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d .venv ]; then
  echo "No .venv found. Run the setup in START-HERE.md first."
  exit 1
fi
source .venv/bin/activate

if [ ! -f .env ]; then
  echo "No .env found. Copy .env.example to .env and put your ORATS token in it."
  exit 1
fi

START="${START:-2026-05-01}"
END="${END:-2026-08-31}"
mkdir -p state

echo "=============================================="
echo " DENOMINATOR RUN"
echo " window: $START to $END"
echo "=============================================="
echo

for DELAY in 0 1; do
  if [ "$DELAY" = "0" ]; then
    LABEL="entering on the catalyst day's close"
  else
    LABEL="entering the day after the catalyst"
  fi
  echo "----------------------------------------------"
  echo " Pass $((DELAY + 1)) of 2 — $LABEL"
  echo "----------------------------------------------"
  python scripts/study_gaps.py \
    --universe universe.txt \
    --start "$START" \
    --end "$END" \
    --min-dte 8 \
    --hold 4 \
    --entry-delay "$DELAY" \
    --target 5.0 \
    --out "state/denominator_delay${DELAY}.csv"
  echo
done

echo "=============================================="
echo " DONE"
echo "=============================================="
echo "Two files written:"
echo "  state/denominator_delay0.csv   (catalyst day close)"
echo "  state/denominator_delay1.csv   (day after)"
echo
echo "Send both to Claude. The number that matters is what share of"
echo "all trades hit 5x. The bar is 20%. Below that, the setup loses"
echo "money no matter how good the winners look."
