# Do this week

Five steps. One command each. Do them in order and stop if something errors —
send me the error instead of pushing past it.

Steps 1 and 2 take about fifteen minutes total. Step 3 is the one that matters.

---

## Steps 1 and 2 happen on the same page

**https://dashboard.orats.com/api-console**

That one page is where the token lives *and* where the live data agreements
get signed. Not orats.com — `dashboard.orats.com`. That is why you could not
find them: the marketing site never links to it, and the public docs only say
"available after signup."

ORATS' own authentication doc: purchase a token, *"then go to your dashboard to
view your token"*, and to enable live data, *"sign the agreements here"* —
both pointing at `dashboard.orats.com/api-console`.

---

## Step 1 — Rotate the ORATS token (5 minutes)

Your token was pasted into a chat and it appeared inside error URLs. Treat it
as public. Go to the API console above, generate a new token, then:

```bash
cd ~/asymmetry-engine
nano .env
```

Replace the old token, save with `Ctrl-O` then `Enter`, exit with `Ctrl-X`.

Then check it took:

```bash
cd ~/asymmetry-engine && source .venv/bin/activate && python -c "
from engine.data.orats import clean_token
import os, re
from dotenv import load_dotenv; load_dotenv()
t = clean_token(os.getenv('ORATS_TOKEN'))
print('token looks', 'OK' if re.match(r'^[A-Za-z0-9-]{20,}\$', t) else 'WRONG SHAPE')
print('length', len(t))
"
```

It should say **OK**. If it says WRONG SHAPE, something invisible got pasted in
with it — that is the exact bug that cost us a whole run.

---

## Step 2 — Sign the live data agreements (same page, 10 minutes)

While you are on **https://dashboard.orats.com/api-console**, look for the
agreements section and sign them. There are usually several — one per exchange
— so expect to click through a few, not one.

Until they are signed, `/strikes` returns nothing and the live scanner has no
chain to price. Your requests to live endpoints are simply blocked; per ORATS,
once signed *"your requests to the live endpoints will no longer be blocked."*

**Do this today even though you won't use it today** — approval takes a few
days and it is the long pole. Everything else can happen while you wait.

---

## Step 3 — Run the denominator (this is the important one)

```bash
cd ~/asymmetry-engine && bash scripts/run_denominator.sh
```

Let it run. It writes two files into `state/`. Send me both.

**Why this is the step that matters.** The 57-winner study found winners. It
never counted the losers, so it cannot tell you whether the setup makes money.
This run enters after the news is public — the only entry you could actually
take — and counts every trade including the ones that went to zero.

The bar is **20%**. One in five has to reach 5x. If the answer comes back at
6%, then the whole thing is a losing strategy that produces beautiful
screenshots, and you will have found that out for the price of an afternoon
instead of the price of a year of trading.

I do not know which way this comes back. That is the point of running it.

---

## Step 4 — Trade one contract, twenty times

Not $1,000. **One contract.** Whatever the tier ladder says, buy one.

Log every single one — the ones you take and the ones you look at and skip.
Twenty closed positions is the smallest sample that tells you anything, and
your own hit rate is the only number in this whole system that is actually
about you.

Hard caps are in `engine/risk.py` and there is no override parameter. That was
deliberate. Don't add one.

---

## Step 5 — Then, and only then, build the web app

`HANDOFF-PROMPT.md` and `BUILD-SPEC.md` are ready. Paste the handoff prompt
into a fresh Claude Code session.

It is step 5 and not step 1 on purpose. A web app makes it easier to run this
every morning. If step 3 says the edge isn't there, easier is worse.

---

## What I can and cannot do

I tested it just now, both from my own machine and from the sandbox on your
Mac: **I cannot reach ORATS.** Connection refused, not an auth error. Same for
every other market data host.

So the division of labor is fixed:

- **You run.** Anything that touches live market data runs in Terminal on your
  Mac, where the network works.
- **I analyze.** Paste me the output files and I do the statistics, the
  scoring, the writing, and the arguing.

That is not a limitation I can engineer around, and you should be suspicious of
any answer from me that implies otherwise.
