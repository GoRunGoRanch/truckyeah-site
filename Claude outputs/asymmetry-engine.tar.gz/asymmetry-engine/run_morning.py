#!/usr/bin/env python3
"""The morning run. One pass, one dashboard, no interaction.

    python run_morning.py                 # paper, today
    python run_morning.py --date 2026-08-28
    python run_morning.py --dry-run       # screen only, journal nothing

Order of operations, and every one of them can end the run early:

    kill switch -> auth -> catalysts -> RVOL -> edge test -> structures ->
    sizing -> journal -> dashboard

Failing early and loudly is the whole design. A scheduled job that silently
does nothing on a broken token is worse than one that errors, because you find
out in six weeks when you wonder why it never fires.
"""

from __future__ import annotations

import argparse
import logging
import sys
import traceback
from datetime import date, datetime
from pathlib import Path

from engine import dashboard
from engine.catalysts import CatalystCalendar
from engine.config import load_config, load_dotenv
from engine.data.orats import OratsClient, OratsError
from engine.data.orats_live import make_data_client
from engine.data.schwab import SchwabAuthExpired
from engine.execution import Executor, LiveGate, LiveTradingBlocked
from engine.journal import CandidateRecord, Journal
from engine.mispricing import (
    evaluate_edge,
    implied_move_from_straddle,
    implied_move_from_term_structure,
    round_trip_spread_fraction,
)
from engine.risk import size_position
from engine.rvol import passes_gate, premarket_rvol
from engine.structures import build_structures

log = logging.getLogger("asymmetry")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Asymmetric setup finder — morning run")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--date", default=date.today().isoformat())
    ap.add_argument("--dry-run", action="store_true",
                    help="screen and print; write nothing to the journal")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(message)s",
        datefmt="%H:%M:%S",
    )

    root = Path(args.config).resolve().parent
    load_dotenv(root / ".env")
    cfg = load_config(args.config)
    session = datetime.strptime(args.date, "%Y-%m-%d").date()

    # 1. Kill switch, before anything touches the network.
    if cfg.risk.kill_switch_engaged(cfg.root):
        log.error("KILL SWITCH present at %s — no run.", cfg.risk.kill_switch_path)
        return 2

    journal = Journal(cfg.root / cfg.journal_path)
    notes: list[str] = []
    records: list[dict] = []

    # 2. Data sources. Fails loudly rather than skipping a session quietly.
    #    `data_source` in config.yaml picks between ORATS and Schwab for live
    #    chains; ORATS always supplies the historical side either way.
    try:
        live = make_data_client(cfg)
        orats = OratsClient(token=cfg.orats_token)
        log.info("live data source: %s", cfg.data_source)
    except SchwabAuthExpired as e:
        log.error("Schwab auth: %s", e)
        _emergency_dashboard(cfg, args.date, str(e))
        return 3
    except RuntimeError as e:
        log.error("Configuration: %s", e)
        _emergency_dashboard(cfg, args.date, str(e))
        return 4

    executor = Executor(
        mode=cfg.mode,
        journal=journal,
        root=cfg.root,
        gate=LiveGate(
            min_closed_positions_before_live=cfg.min_closed_positions_before_live
        ),
        kill_switch_rel=cfg.risk.kill_switch_path,
        schwab_client=live,
    )
    try:
        executor.preflight()
    except LiveTradingBlocked as e:
        log.error("Live mode refused: %s", e)
        log.error("Falling back to paper for this session.")
        notes.append(f"Live refused, ran as paper: {e}")
        executor.mode = "paper"

    # 3. Catalysts for this session.
    calendar = CatalystCalendar(universe=set(cfg.screen.universe))
    try:
        earnings = _earnings_for_window(orats, cfg.screen.universe, session)
    except OratsError as e:
        log.error("ORATS: %s", e)
        return 5

    catalysts = calendar.for_session(session, earnings)
    log.info("%d catalyst(s) in play for %s", len(catalysts), session)
    if not catalysts:
        notes.append("No catalysts on the calendar for this session.")

    debit_used = journal.debit_used_on(args.date, mode=executor.mode)
    open_now = len(journal.open_positions(mode=executor.mode))

    for cat in catalysts:
        rec = CandidateRecord(
            run_date=args.date,
            underlying=cat.symbol,
            catalyst_kind=cat.kind,
            catalyst_date=cat.event_date.isoformat(),
            verdict="declined",
            reason="",
            mode=executor.mode,
        )
        try:
            _screen_one(
                cat, cfg, live, orats, calendar, rec,
                journal=journal, executor=executor,
                debit_used=debit_used, open_now=open_now,
            )
        except Exception as e:  # one bad name must not kill the session
            rec.verdict = "declined"
            rec.reason = f"error while screening: {e}"
            log.warning("screening %s failed: %s", cat.symbol, e)
            log.debug(traceback.format_exc())

        if rec.verdict == "taken":
            debit_used += rec.debit
            open_now += 1

        d = rec.__dict__.copy()
        records.append(d)
        if not args.dry_run:
            journal.record(rec)
        log.info("%-6s %-22s %s", rec.underlying, rec.verdict,
                 rec.reason.split("\n")[0][:90])

    # 4. Dashboard.
    html = dashboard.render(
        run_date=args.date,
        mode=executor.mode,
        candidates=records,
        track_record=journal.track_record(mode=executor.mode),
        notes=notes,
    )
    out = dashboard.write(cfg.root / cfg.dashboard_path, html)
    log.info("dashboard -> %s", out)
    return 0


def _screen_one(cat, cfg, live, orats, calendar, rec, *, journal,
                executor, debit_used, open_now) -> None:
    """Full pipeline for one catalyst. Mutates `rec` with the verdict."""
    sym = cat.symbol
    reasons: list[str] = []

    # -- RVOL gate --------------------------------------------------------
    bars = live.price_history_daily(sym, days=30)
    if len(bars) < 10:
        rec.reason = "declined: not enough price history for an RVOL baseline"
        return
    today_vol = float(bars[-1].get("volume", 0))
    reading = premarket_rvol(sym, today_vol, [float(b.get("volume", 0)) for b in bars[:-1]])
    rec.rvol = reading.rvol
    ok, why = passes_gate(reading, min_rvol=cfg.screen.min_rvol)
    reasons.append(why)
    if not ok:
        rec.reason = "\n".join(reasons)
        return

    # -- Implied move -----------------------------------------------------
    spot = live.spot(sym)
    if not spot:
        rec.reason = "declined: no spot price"
        return
    rec.spot_at_signal = spot

    chain = live.parsed_chain(sym)
    if not chain:
        rec.reason = "declined: empty option chain"
        return

    expiries = sorted({q.expiry for q in chain})
    front = next((e for e in expiries if e >= cat.event_date.isoformat()), None)
    if front is None:
        rec.reason = "declined: no expiry at or after the catalyst"
        return
    rec.expiry = front
    back = next((e for e in expiries if e > front), None)

    atm_c = min((q for q in chain if q.expiry == front and q.right == "C"),
                key=lambda q: abs(q.strike - spot), default=None)
    atm_p = min((q for q in chain if q.expiry == front and q.right == "P"),
                key=lambda q: abs(q.strike - spot), default=None)
    if not atm_c or not atm_p:
        rec.reason = "declined: no ATM strikes"
        return

    straddle_mid = atm_c.mid + atm_p.mid
    spread_frac = round_trip_spread_fraction(
        [(atm_c.bid, atm_c.ask), (atm_p.bid, atm_p.ask)]
    )

    implied = None
    if back:
        bc = min((q for q in chain if q.expiry == back and q.right == "C"),
                 key=lambda q: abs(q.strike - spot), default=None)
        if bc and bc.iv and atm_c.iv:
            implied = implied_move_from_term_structure(
                symbol=sym, spot=spot, front_expiry=front,
                front_iv=atm_c.iv, front_t_years=_years_to(front),
                back_iv=bc.iv, back_t_years=_years_to(back),
                atm_strike=atm_c.strike, straddle_mid=straddle_mid,
                spread_cost_frac=spread_frac,
            )
    if implied is None:
        implied = implied_move_from_straddle(
            symbol=sym, spot=spot, expiry=front, atm_strike=atm_c.strike,
            straddle_mid=straddle_mid, spread_cost_frac=spread_frac,
        )
    if implied is None:
        rec.reason = "declined: could not compute an implied move"
        return
    rec.implied_move_pct = implied.move_pct
    rec.implied_method = implied.method

    # -- History, conditioned on the catalyst kind ------------------------
    if cat.is_peer and cat.source_symbol:
        hist = orats.peer_catalyst_gaps(sym, cat.source_symbol)
    else:
        hist = orats.catalyst_gaps(sym)
    rec.hist_n = hist.n
    rec.hist_mean_abs_pct = hist.mean_abs() if hist.n else None

    # -- The edge test ----------------------------------------------------
    edge = evaluate_edge(
        implied, hist,
        min_ev_multiple=cfg.screen.min_ev_multiple,
        min_sample=cfg.screen.min_sample,
        max_spread_cost_frac=cfg.screen.max_spread_cost_frac,
        require_exact_method=cfg.screen.require_term_structure,
    )
    rec.ev_multiple = edge.ev_multiple
    rec.ev_multiple_net = edge.ev_multiple_net
    rec.exceed_rate = edge.exceed_rate
    reasons.extend(edge.reasons)
    if not edge.passed:
        rec.reason = "\n".join(reasons)
        return

    # -- Structures -------------------------------------------------------
    structures = build_structures(
        edge, chain, spot=spot, expiry=front,
        min_oi=cfg.screen.min_open_interest,
        max_leg_spread_frac=cfg.screen.max_leg_spread_frac,
    )
    if not structures:
        reasons.append("declined: no tradeable structure (open interest or spreads)")
        rec.reason = "\n".join(reasons)
        return

    best = min(structures, key=lambda s: s.spread_cost_frac)
    payoffs = best.payoff_over_history(spot, hist.gaps)

    # -- Sizing -----------------------------------------------------------
    sizing = size_position(
        debit_per_contract=best.debit_per_contract,
        payoffs_per_contract=payoffs,
        account_equity=cfg.account_equity,
        limits=cfg.risk,
        open_positions=open_now,
        positions_in_underlying=journal.positions_in(sym, mode=executor.mode),
        debit_used_today=debit_used,
    )
    reasons.extend(sizing.notes)
    rec.structure_kind = best.kind.value
    rec.binding_constraint = sizing.binding_constraint
    rec.legs = [{"symbol": l.symbol, "strike": l.strike, "right": l.right,
                 "ask": l.ask, "bid": l.bid} for l in best.legs]
    reasons.append(best.rationale)

    if sizing.contracts == 0:
        rec.verdict = "sized_to_zero"
        rec.reason = "\n".join(reasons)
        return

    best.contracts = sizing.contracts
    best.price(spot)
    rec.contracts = sizing.contracts
    rec.debit = best.max_loss
    rec.verdict = "taken"
    rec.reason = "\n".join(reasons)


def _years_to(expiry: str) -> float:
    d = datetime.strptime(expiry, "%Y-%m-%d").date()
    return max((d - date.today()).days, 1) / 365.0


def _earnings_for_window(orats, universe, session):
    """(symbol, report_date, timing) for names whose event could land on `session`.

    Pulls the peer map's bellwethers too, since a bellwether not in the trading
    universe still creates sympathy catalysts inside it — the MU case exactly.
    """
    from engine.catalysts import DEFAULT_PEER_MAP

    symbols = set(universe) | set(DEFAULT_PEER_MAP)
    out = []
    for sym in sorted(symbols):
        try:
            rows = orats.cores(sym)
        except Exception:
            continue
        if not rows:
            continue
        nxt = rows[0].get("nextErn") or rows[0].get("earnDate")
        if not nxt:
            continue
        try:
            d = datetime.strptime(str(nxt)[:10], "%Y-%m-%d").date()
        except ValueError:
            continue
        if abs((d - session).days) <= 1:
            timing = str(rows[0].get("nextErnTod") or rows[0].get("anncTod") or "amc")
            out.append((sym, d, "bmo" if "before" in timing.lower() else "amc"))
    return out


def _emergency_dashboard(cfg, run_date: str, message: str) -> None:
    """Even a failed run leaves a page, so a silent failure is visible."""
    html = dashboard.render(
        run_date=run_date, mode=cfg.mode, candidates=[],
        track_record={"surfaced": 0, "closed": 0, "total_pnl": 0.0,
                      "caveat": "Run aborted before screening."},
        notes=[message],
    )
    dashboard.write(cfg.root / cfg.dashboard_path, html)


if __name__ == "__main__":
    sys.exit(main())
