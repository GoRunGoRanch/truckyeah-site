"""Catalyst move screen, and the R/R ladder that finds the 1:5 strike.

Three reference trades, three different mechanisms:

    CRM  Aug 2026   beaten down ~25% on the year, printed at 52w lows, good
                    number, re-rated ~30% over three sessions. Expectations
                    floored plus short covering.
    MU   Aug 2026   someone else's catalyst (NVDA printing well), sold off
                    anyway. Sympathy fade / sell-the-news.
    TSLA Aug 2026   not beaten down at all. Rallied ~5.5% overnight on Cybercab
                    and robotaxi anticipation. A scheduled event people were
                    positioning into.

An earlier version of this module gated on "beaten down." TSLA disproved that
inside an hour. Being deep in a drawdown made CRM's tail fatter -- floored
expectations and crowded shorts genuinely do produce violent re-ratings -- but
it is one path to a big move, not the definition of one. It scores now. It does
not gate.

What all three actually share is thinner than it first looks:

    a catalyst, a violent move, volume confirming it, and the move still holding.

That is the screen. And it is worth being blunt about what it is NOT: this is
roughly what every gapper scanner on earth already does, thinkorswim's included.
Finding the movers is the easy half and there is no edge in it.

The edge, if it exists, is in the second half of this module: given the chain
right now, WHICH strike actually pays 5:1, and how far does the underlying have
to travel to get there? That number -- the required continuation -- is what
separates a real 1:5 from a lottery ticket that needs a 40% move nobody is going
to give you. It is computable from the chain, and it is the thing a generic
gapper scan never tells you.

Nothing here claims the setups work. `required_hit_rate` says one in six must be
a 5-bagger to break even. Whether yours are is an empirical question the journal
answers over months, not something this file asserts.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

import numpy as np

CatalystKind = str  # "earnings" | "scheduled_event" | "sympathy" | "news"


@dataclass(frozen=True)
class DrawdownState:
    """Where the stock sits in its 52-week range. Scores, never gates."""

    symbol: str
    spot: float
    high_52w: float
    low_52w: float

    @property
    def off_high_pct(self) -> float:
        if self.high_52w <= 0:
            return 0.0
        return max(0.0, 1.0 - self.spot / self.high_52w)

    @property
    def range_position(self) -> float:
        """0.0 = at the 52w low, 1.0 = at the high."""
        span = self.high_52w - self.low_52w
        if span <= 0:
            return 0.5
        return float(np.clip((self.spot - self.low_52w) / span, 0.0, 1.0))

    @property
    def is_beaten_down(self) -> bool:
        """The CRM condition: hated and near the lows. A bonus, not a filter."""
        return self.off_high_pct >= 0.20 and self.range_position <= 0.35

    def describe(self) -> str:
        return (
            f"{self.off_high_pct * 100:.0f}% off 52w high, "
            f"{self.range_position * 100:.0f}% of range"
        )


@dataclass(frozen=True)
class Move:
    """The catalyst move. Overnight gap or an intraday vertical -- same thing."""

    symbol: str
    reference_px: float     # prior close, or pre-move base
    move_px: float          # price at the end of the initial thrust
    last_px: float

    @property
    def move_pct(self) -> float:
        if self.reference_px <= 0:
            return 0.0
        return self.move_px / self.reference_px - 1.0

    @property
    def direction(self) -> str:
        return "up" if self.move_pct > 0 else "down"

    @property
    def side(self) -> str:
        """Option side taken FROM the move. Never predicted."""
        return "C" if self.move_pct > 0 else "P"

    @property
    def holding(self) -> bool:
        """Still beyond the thrust in its own direction?

        A move that has given itself back is a failing move. Buying it is the
        stop-out-reversal pattern wearing a screener's clothes.
        """
        return self.last_px >= self.move_px if self.move_pct > 0 else self.last_px <= self.move_px


@dataclass
class Candidate:
    symbol: str
    catalyst_kind: CatalystKind
    move: Move
    rvol: float
    drawdown: DrawdownState | None = None
    short_interest_pct: float | None = None
    iv_rank: float | None = None        # 0-1; low means options are cheap

    passed: bool = False
    score: float = 0.0
    reasons: list[str] = field(default_factory=list)

    def summary(self) -> str:
        v = f"TAKE {self.move.side}" if self.passed else "declined"
        return (
            f"{self.symbol} [{self.catalyst_kind}] {self.move.move_pct * 100:+.1f}% "
            f"on {self.rvol:.1f}x -> {v} (score {self.score:.0f})"
        )


@dataclass(frozen=True)
class ScreenConfig:
    min_move_pct: float = 0.04      # below this it is noise, not a repricing
    min_rvol: float = 3.0
    require_holding: bool = True


def screen(
    symbol: str,
    *,
    catalyst_kind: CatalystKind,
    move: Move,
    rvol: float,
    drawdown: DrawdownState | None = None,
    short_interest_pct: float | None = None,
    iv_rank: float | None = None,
    cfg: ScreenConfig | None = None,
) -> Candidate:
    cfg = cfg or ScreenConfig()
    c = Candidate(
        symbol=symbol,
        catalyst_kind=catalyst_kind,
        move=move,
        rvol=rvol,
        drawdown=drawdown,
        short_interest_pct=short_interest_pct,
        iv_rank=iv_rank,
    )

    if abs(move.move_pct) < cfg.min_move_pct:
        c.reasons.append(
            f"declined: {move.move_pct * 100:+.1f}% move below the "
            f"{cfg.min_move_pct * 100:.0f}% floor -- noise, not a repricing"
        )
        return c

    if rvol < cfg.min_rvol:
        c.reasons.append(
            f"declined: RVOL {rvol:.1f}x below {cfg.min_rvol:.1f}x -- a repricing "
            f"nobody is trading is not a repricing"
        )
        return c

    if cfg.require_holding and not move.holding:
        c.reasons.append(
            f"declined: moved {move.direction} then gave it back -- failing move; "
            f"chasing it is the stop-out-reversal pattern"
        )
        return c

    score = 0.0
    score += min(abs(move.move_pct) / 0.20, 1.0) * 35
    score += min(rvol / 10.0, 1.0) * 25

    notes: list[str] = []
    if drawdown is not None:
        if drawdown.is_beaten_down:
            score += 20
            notes.append(
                f"beaten down ({drawdown.describe()}) -- floored expectations, "
                f"the CRM condition; fattest tails live here"
            )
        else:
            notes.append(f"not beaten down ({drawdown.describe()})")

    if short_interest_pct is not None:
        if short_interest_pct >= 0.10 and move.move_pct > 0:
            score += 10
            notes.append(f"{short_interest_pct * 100:.0f}% short interest on an up-move -- covering fuel")
        else:
            notes.append(f"{short_interest_pct * 100:.0f}% short interest")

    # Cheap options are the whole ballgame for a 5x. Elevated IV at entry means
    # you are paying for the move you are trying to profit from.
    if iv_rank is not None:
        score += (1.0 - iv_rank) * 10
        if iv_rank > 0.75:
            notes.append(
                f"IV rank {iv_rank * 100:.0f}% -- options already expensive; "
                f"5:1 will need a much larger continuation"
            )
        else:
            notes.append(f"IV rank {iv_rank * 100:.0f}%")

    c.score = score
    c.passed = True
    c.reasons.append(
        f"passed: {catalyst_kind}, {move.move_pct * 100:+.1f}% on {rvol:.1f}x volume "
        f"and holding. Side is {'calls' if move.side == 'C' else 'puts'} -- the move chose."
    )
    c.reasons.extend(notes)
    return c


# --------------------------------------------------------------------------
# The half that is not already in every gapper scanner.
# --------------------------------------------------------------------------


@dataclass
class RRRung:
    """One strike, and what the underlying must do for it to pay the target."""

    symbol: str
    expiry: str
    strike: float
    right: str
    ask: float
    bid: float
    open_interest: int
    required_underlying_pct: float   # continuation needed for target multiple
    breakeven_px: float
    spread_frac: float
    contracts_for_budget: int
    cost: float

    @property
    def tradeable(self) -> bool:
        return (
            self.bid > 0
            and self.open_interest >= 100
            and self.spread_frac <= 0.25
        )

    def describe(self, target: float) -> str:
        flag = "" if self.tradeable else "  [ILLIQUID — skip]"
        return (
            f"  {self.strike:>8g}{self.right}  ask {self.ask:>6.2f}  "
            f"OI {self.open_interest:>6,}  "
            f"needs {self.required_underlying_pct * 100:>+6.1f}% for {target:g}x  "
            f"({self.contracts_for_budget} ct = ${self.cost:,.0f}){flag}"
        )


def rr_ladder(
    chain: Sequence,
    *,
    symbol: str,
    spot: float,
    expiry: str,
    side: str,
    budget: float = 1000.0,
    target_multiple: float = 5.0,
) -> list[RRRung]:
    """For every strike, how far must the stock move to turn `budget` into 5x?

    This is the question a gapper scan never answers. Two strikes can look
    equally attractive and require wildly different continuations -- one needs
    another 4%, the other needs 22%. Only one of those is a trade.

    Intrinsic value at expiry is used deliberately: it assumes you hold to
    expiry with zero time value left, which is the pessimistic case. Selling
    earlier into remaining extrinsic will beat these numbers; assuming otherwise
    is how backtests flatter themselves.

    Returns rungs sorted by required continuation, easiest first.
    """
    out: list[RRRung] = []
    for q in chain:
        if getattr(q, "expiry", None) != expiry or getattr(q, "right", None) != side:
            continue
        ask = float(getattr(q, "ask", 0) or 0)
        bid = float(getattr(q, "bid", 0) or 0)
        strike = float(getattr(q, "strike", 0) or 0)
        if ask <= 0 or strike <= 0:
            continue

        # Target price for the contract, then the underlying level that produces
        # it as pure intrinsic.
        target_px = ask * target_multiple
        if side == "C":
            needed_px = strike + target_px
        else:
            needed_px = strike - target_px
        if needed_px <= 0:
            continue

        mid = (bid + ask) / 2.0
        contracts = int(budget // (ask * 100)) if ask > 0 else 0

        out.append(
            RRRung(
                symbol=symbol,
                expiry=expiry,
                strike=strike,
                right=side,
                ask=ask,
                bid=bid,
                open_interest=int(getattr(q, "open_interest", 0) or 0),
                required_underlying_pct=needed_px / spot - 1.0,
                breakeven_px=(strike + ask) if side == "C" else (strike - ask),
                spread_frac=((ask - bid) / mid) if mid > 0 else float("inf"),
                contracts_for_budget=contracts,
                cost=contracts * ask * 100,
            )
        )

    out.sort(key=lambda r: abs(r.required_underlying_pct))
    return out


def best_rung(
    rungs: Sequence[RRRung], *, max_required_move: float = 0.10
) -> RRRung | None:
    """Cheapest continuation that is both tradeable and plausible.

    `max_required_move` is the honest filter. A strike needing another 25% move
    to pay 5x is not a 1:5 trade, however good the ratio looks written down --
    it is a lottery ticket, and pricing it as a 1:5 is how you talk yourself
    into a series of total losses.
    """
    for r in rungs:
        if r.tradeable and abs(r.required_underlying_pct) <= max_required_move:
            return r
    return None


def required_hit_rate(reward_multiple: float) -> float:
    """Break-even hit rate for full-loss / reward_multiple-gain.

    At 1:5 this is 16.7% -- about one in six must be a 5-bagger. Kept in code so
    it shows up on the dashboard beside the ACTUAL rate, rather than living in
    someone's head as an assumption that never gets checked.
    """
    return 1.0 / (1.0 + reward_multiple)
