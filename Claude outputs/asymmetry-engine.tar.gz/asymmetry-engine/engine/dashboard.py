"""The local morning page.

Private, on disk, never published. It shows declines as prominently as passes,
because the interesting question on any given morning is usually "why is the
list empty?" and a dashboard that only renders trades cannot answer it.

Palette borrowed from the mu-reversal-sim so this reads as part of the same
toolkit rather than a stranger.
"""

from __future__ import annotations

import html
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Sequence

CSS = """
:root{--bg:#0e1621;--panel:#131f2e;--ink:#e8eef7;--mut:#8ea3bd;--line:#26374d;
      --cyan:#20c4d8;--mag:#e05aa8;--up:#26c281;--dn:#e5533c;--warn:#e8b93a;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.55 -apple-system,
     BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;}
.wrap{max-width:1080px;margin:0 auto;padding:18px 16px 60px;}
h1{font-size:21px;margin:0 0 2px;}
.sub{color:var(--mut);font-size:12.5px;margin-bottom:16px;}
.banner{background:#241f10;border:1px solid #8a6d1b;color:#f2d79a;border-radius:10px;
        padding:11px 14px;font-size:13px;margin-bottom:16px;}
.banner.live{background:#3a1414;border-color:var(--dn);color:#ffb3a6;font-weight:700;}
.row{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;}
.chip{background:var(--panel);border:1px solid var(--line);border-radius:9px;
      padding:8px 13px;font-size:12px;min-width:104px;}
.chip b{display:block;font-size:19px;margin-top:2px;font-variant-numeric:tabular-nums;}
.card{background:var(--panel);border:1px solid var(--line);border-radius:11px;
      padding:14px 16px;margin-bottom:12px;}
.card.pass{border-color:var(--cyan);}
.card.declined{opacity:.72;}
.tick{font-size:17px;font-weight:800;letter-spacing:.3px;}
.kind{color:var(--mut);font-size:12px;margin-left:8px;font-weight:400;}
.verdict{float:right;font-size:11px;font-weight:800;letter-spacing:.6px;
         text-transform:uppercase;padding:3px 9px;border-radius:6px;}
.v-taken{background:#12362a;color:var(--up);border:1px solid var(--up);}
.v-declined{background:#2a1d1d;color:var(--mut);border:1px solid var(--line);}
.v-sized_to_zero{background:#3a2a10;color:var(--warn);border:1px solid var(--warn);}
.nums{display:flex;gap:16px;flex-wrap:wrap;margin:9px 0;font-size:12.5px;
      color:var(--mut);font-variant-numeric:tabular-nums;}
.nums b{color:var(--ink);}
.why{font-size:13px;color:#cdd8e6;border-top:1px solid var(--line);padding-top:9px;
     margin-top:9px;}
.why div{margin:3px 0;}
.legs{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;
      color:var(--cyan);margin-top:6px;}
h2{font-size:14px;text-transform:uppercase;letter-spacing:.7px;color:var(--mut);
   margin:26px 0 10px;border-top:1px solid var(--line);padding-top:16px;}
.empty{color:var(--mut);font-size:13.5px;padding:18px;text-align:center;
       background:var(--panel);border:1px dashed var(--line);border-radius:11px;}
.foot{color:#57616f;font-size:11.5px;margin-top:30px;border-top:1px solid var(--line);
      padding-top:12px;line-height:1.7;}
"""


def render(
    *,
    run_date: str,
    mode: str,
    candidates: Sequence[dict[str, Any]],
    track_record: dict[str, Any],
    notes: Sequence[str] = (),
) -> str:
    e = html.escape
    taken = [c for c in candidates if c.get("verdict") == "taken"]
    passed_screen = [c for c in candidates if c.get("ev_multiple_net")]

    banner = (
        '<div class="banner live">LIVE MODE — this run can place real orders.</div>'
        if mode == "live"
        else '<div class="banner">Paper mode. Orders are built and logged, never sent.</div>'
    )

    hr = track_record.get("hit_rate")
    avg = track_record.get("avg_pnl")
    chips = f"""
    <div class="row">
      <div class="chip">Screened<b>{len(candidates)}</b></div>
      <div class="chip">Passed edge test<b>{len(passed_screen)}</b></div>
      <div class="chip">Taken<b>{len(taken)}</b></div>
      <div class="chip">Closed to date<b>{track_record.get('closed', 0)}</b></div>
      <div class="chip">Hit rate<b>{f'{hr*100:.0f}%' if hr is not None else '—'}</b></div>
      <div class="chip">Avg P/L<b>{f'${avg:,.0f}' if avg is not None else '—'}</b></div>
    </div>"""

    cards = []
    for c in candidates:
        verdict = c.get("verdict", "declined")
        cls = "pass" if verdict == "taken" else "declined"
        nums = []
        if c.get("implied_move_pct") is not None:
            nums.append(
                f"implied <b>{c['implied_move_pct']*100:.1f}%</b> "
                f"({e(str(c.get('implied_method','?')))})"
            )
        if c.get("hist_mean_abs_pct") is not None:
            nums.append(
                f"history <b>{c['hist_mean_abs_pct']*100:.1f}%</b> "
                f"n={c.get('hist_n','?')}"
            )
        if c.get("ev_multiple_net") is not None:
            nums.append(f"EV net <b>x{c['ev_multiple_net']:.2f}</b>")
        if c.get("exceed_rate") is not None:
            nums.append(f"exceeded <b>{c['exceed_rate']*100:.0f}%</b>")
        if c.get("rvol") is not None:
            nums.append(f"RVOL <b>{c['rvol']:.1f}x</b>")
        if c.get("contracts"):
            nums.append(f"size <b>{c['contracts']}</b> @ ${c.get('debit',0):,.0f}")

        reasons = c.get("reason", "")
        why = "".join(
            f"<div>{e(r.strip())}</div>" for r in reasons.split("\n") if r.strip()
        )
        legs = ""
        if c.get("legs"):
            legs = f'<div class="legs">{e(json.dumps(c["legs"]))}</div>'

        cards.append(f"""
        <div class="card {cls}">
          <span class="verdict v-{e(verdict)}">{e(verdict.replace('_',' '))}</span>
          <span class="tick">{e(c.get('underlying','?'))}</span>
          <span class="kind">{e(c.get('catalyst_kind',''))}</span>
          <div class="nums">{' · '.join(nums)}</div>
          <div class="why">{why}</div>
          {legs}
        </div>""")

    body = "".join(cards) or (
        '<div class="empty">Nothing cleared the screen this morning. '
        "That is the expected outcome on most days — the chain usually prices "
        "these events about right.</div>"
    )

    note_html = "".join(f"<div>{e(n)}</div>" for n in notes)

    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Asymmetry — {e(run_date)}</title><style>{CSS}</style></head>
<body><div class="wrap">
  <h1>Asymmetry engine — {e(run_date)}</h1>
  <div class="sub">Private. Not published, not advice, not a signal service.</div>
  {banner}
  {chips}
  <h2>This morning</h2>
  {body}
  <h2>Track record</h2>
  <div class="card">
    <div class="nums">
      <span>surfaced <b>{track_record.get('surfaced',0)}</b></span>
      <span>closed <b>{track_record.get('closed',0)}</b></span>
      <span>total P/L <b>${track_record.get('total_pnl',0):,.0f}</b></span>
    </div>
    <div class="why"><div>{e(str(track_record.get('caveat','')))}</div>{note_html}</div>
  </div>
  <div class="foot">
    Generated {e(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))} ·
    mode <b>{e(mode)}</b><br>
    Declines are shown deliberately. A list of only the trades it liked would
    tell you nothing about whether it is any good.<br>
    Nothing here is investment advice. Historical move distributions do not
    predict the next move; they only say what this chain has underpriced before.
  </div>
</div></body></html>"""


def write(path: str | Path, content: str) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return p
