"""ORATS as the live data source, replacing Schwab.

Schwab's app approval takes days and its order API is irrelevant while the
engine is in paper mode, so ORATS alone can drive everything: live chains for
the R/R ladder, spot prices, and the daily bars RVOL needs.

This class deliberately mirrors SchwabClient's method names -- `spot`,
`parsed_chain`, `price_history_daily` -- so `run_morning.py` can take either one
without knowing the difference. The only thing it cannot do is place an order,
and `place_order` says so rather than failing somewhere confusing later.

TIER MATTERS. The Delayed tier ($99) is roughly 15 minutes behind. For a name
that is moving right now, a 15-minute-old chain will price a strike that no
longer exists at that price, and the R/R ladder will quietly lie to you. Use the
Live tier ($199) if ORATS is the only source. `warn_if_stale()` checks the
quote timestamp and complains rather than letting stale data pass as live.

SHAPE NOTE. ORATS returns ONE ROW PER STRIKE carrying both the call and the put
(callBidPrice, putBidPrice, and so on). Schwab returns separate call and put
maps. So each ORATS row expands into two OptionQuote objects here.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from ..structures import OptionQuote
from .orats import BASE_URL, OratsClient, OratsError, _f

log = logging.getLogger(__name__)

# Beyond this, a "live" quote is not live enough to size a position from.
STALE_QUOTE_SECONDS = 300


def osi_symbol(root: str, expiry: str, right: str, strike: float) -> str:
    """Build the 21-character OSI symbol ORATS does not return.

    Format: 6-char root, padded right with spaces; YYMMDD; C or P; strike in
    thousandths, 8 digits zero-padded.

        CRM   260828C00252500

    Needed for order construction. Schwab returns these directly; ORATS gives
    the components, so they get assembled here.
    """
    d = datetime.strptime(expiry[:10], "%Y-%m-%d")
    return (
        f"{root.upper():<6}"
        f"{d.strftime('%y%m%d')}"
        f"{right.upper()}"
        f"{int(round(strike * 1000)):08d}"
    )


@dataclass
class OratsLiveClient:
    """Drop-in replacement for SchwabClient's read-only surface."""

    token: str
    base_url: str = BASE_URL
    timeout: int = 30
    _client: OratsClient | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self._client = OratsClient(
            token=self.token, base_url=self.base_url, timeout=self.timeout
        )

    # -- parity with SchwabClient -----------------------------------------

    def ensure_auth(self) -> "OratsLiveClient":
        """No OAuth here -- a token either works or it does not.

        Notably this means no weekly re-authorisation chore, which is the one
        real ergonomic win ORATS has over Schwab for a scheduled job.
        """
        try:
            self._client.cores("SPY")
        except OratsError as e:
            raise RuntimeError(f"ORATS token rejected: {e}") from e
        return self

    def strikes(self, symbol: str) -> list[dict[str, Any]]:
        """/strikes -- the current chain, one row per strike."""
        return self._client._get("/strikes", ticker=symbol.upper())

    def spot(self, symbol: str) -> float | None:
        rows = self.strikes(symbol)
        for r in rows:
            px = _f(r, "stockPrice", "spotPrice", "stkPx")
            if px:
                return px
        return None

    def parsed_chain(self, symbol: str, **_: Any) -> list[OptionQuote]:
        """Expand ORATS strike rows into call and put OptionQuotes.

        Falls back to theoretical `callValue`/`putValue` when a bid/ask is
        missing, and marks those by leaving the spread at zero -- which the
        tradeability check then rejects, because a theoretical value is not a
        price anyone will fill you at.
        """
        out: list[OptionQuote] = []
        for r in self.strikes(symbol):
            strike = _f(r, "strike")
            expiry = str(r.get("expirDate") or "")[:10]
            if not strike or not expiry:
                continue

            for right, bid_keys, ask_keys, oi_key, vol_key, iv_key in (
                ("C", ("callBidPrice", "callBid"), ("callAskPrice", "callAsk"),
                 "callOpenInterest", "callVolume", "callMidIv"),
                ("P", ("putBidPrice", "putBid"), ("putAskPrice", "putAsk"),
                 "putOpenInterest", "putVolume", "putMidIv"),
            ):
                bid = _f(r, *bid_keys)
                ask = _f(r, *ask_keys)
                if bid is None or ask is None:
                    continue

                iv = _f(r, iv_key, "smvVol")
                delta = _f(r, "delta")
                if delta is not None and right == "P":
                    delta = delta - 1.0   # ORATS reports call delta

                out.append(
                    OptionQuote(
                        symbol=osi_symbol(symbol, expiry, right, strike),
                        underlying=symbol.upper(),
                        expiry=expiry,
                        strike=strike,
                        right=right,
                        bid=bid,
                        ask=ask,
                        iv=iv,
                        delta=delta,
                        open_interest=int(_f(r, oi_key) or 0),
                        volume=int(_f(r, vol_key) or 0),
                    )
                )
        return out

    def price_history_daily(self, symbol: str, *, days: int = 400) -> list[dict[str, Any]]:
        """Daily bars shaped like Schwab's candles, so RVOL code is unchanged."""
        bars = self._client.dailies(symbol)
        out = []
        for b in bars:
            out.append(
                {
                    "datetime": str(b.get("tradeDate") or "")[:10],
                    "open": _f(b, "opnPx", "open", "oPrice"),
                    "high": _f(b, "hiPx", "high", "hPrice"),
                    "low": _f(b, "loPx", "low", "lPrice"),
                    "close": _f(b, "clsPx", "close", "cPrice"),
                    "volume": _f(b, "stockVolume", "volume", "vol") or 0,
                }
            )
        out.sort(key=lambda r: r["datetime"])
        return out[-days:]

    def place_order(self, order: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError(
            "ORATS is a data vendor and cannot place orders. Enter trades by "
            "hand in thinkorswim, or wire up Schwab when its app is approved. "
            "In paper mode this is never reached."
        )

    def open_orders(self) -> list[dict[str, Any]]:
        return []

    # -- staleness --------------------------------------------------------

    def warn_if_stale(self, symbol: str) -> float | None:
        """Age of the quote in seconds, with a warning if it is not live.

        The Delayed tier is ~15 minutes behind. That is fine for backtesting and
        actively misleading for sizing a position in a moving name, so this
        makes the difference visible rather than letting it pass silently.
        """
        rows = self.strikes(symbol)
        if not rows:
            return None
        ts = rows[0].get("quoteDate") or rows[0].get("updatedAt") or rows[0].get("tradeDate")
        if not ts:
            return None
        try:
            when = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
            if when.tzinfo is None:
                when = when.replace(tzinfo=timezone.utc)
        except ValueError:
            return None

        age = (datetime.now(timezone.utc) - when).total_seconds()
        if age > STALE_QUOTE_SECONDS:
            log.warning(
                "%s quote is %.0f minutes old. If you are on the Delayed tier, "
                "this chain is not live and the R/R ladder will price strikes "
                "that have already moved.",
                symbol,
                age / 60,
            )
        return age


def make_data_client(cfg) -> Any:
    """Pick the live data source from config. Defaults to ORATS.

    `data_source: orats` in config.yaml uses ORATS for everything.
    `data_source: schwab` uses Schwab, once its app is approved.
    """
    source = getattr(cfg, "data_source", "orats").lower()

    if source == "orats":
        return OratsLiveClient(token=cfg.orats_token).ensure_auth()

    if source == "schwab":
        from .schwab import SchwabClient

        c = SchwabClient(
            api_key=cfg.schwab_api_key,
            app_secret=cfg.schwab_app_secret,
            callback_url=cfg.schwab_callback_url,
            token_path=cfg.schwab_token_path,
        )
        c.ensure_auth()
        return c

    raise ValueError(f"unknown data_source {source!r}; use 'orats' or 'schwab'")
