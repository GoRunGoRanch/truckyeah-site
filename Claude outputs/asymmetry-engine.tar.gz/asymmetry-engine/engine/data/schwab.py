"""Schwab Trader API -- live chains, quotes, and (eventually) orders.

Built on `schwab-py` rather than hand-rolled HTTP. That is a deliberate call:
the OAuth dance, the token refresh, and the account-hash indirection are all
places where a subtle mistake shows up as a failed order at 9:31am rather than
as an exception in testing. Use the library other people have already debugged.

Three facts about this API that shape everything downstream:

  1. thinkorswim itself has no supported order endpoint. TOS is a terminal, not
     an API. Anything automated goes through Schwab's Trader API.
  2. The refresh token expires every SEVEN DAYS and re-authorising requires a
     browser. A scheduled morning run will therefore fail on auth roughly once a
     week, forever. `ensure_auth()` makes that failure loud and specific instead
     of letting the run quietly skip a session.
  3. Futures orders return HTTP 400. Equities and options only.

Orders need the account HASH, not the account number. `account_hash` resolves it
once and caches it.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Sequence

from ..structures import OptionQuote

log = logging.getLogger(__name__)

TOKEN_LIFETIME_DAYS = 7


class SchwabAuthExpired(RuntimeError):
    """Raised loudly when the weekly re-auth is due. Never swallowed."""


@dataclass
class SchwabClient:
    api_key: str
    app_secret: str
    callback_url: str
    token_path: str
    account_index: int = 0
    _client: Any = field(default=None, repr=False)
    _account_hash: str | None = field(default=None, repr=False)

    # -- auth -------------------------------------------------------------

    def ensure_auth(self) -> Any:
        """Return an authenticated client, or fail with instructions.

        Deliberately does NOT attempt a browser login. An unattended 8:45am run
        must never open a browser window on a Mac nobody is sitting at; it must
        stop and say so.
        """
        if self._client is not None:
            return self._client

        try:
            from schwab.auth import client_from_token_file
        except ImportError as e:  # pragma: no cover
            raise RuntimeError(
                "schwab-py is not installed. `pip install schwab-py`"
            ) from e

        tp = Path(self.token_path)
        if not tp.exists():
            raise SchwabAuthExpired(
                f"No Schwab token at {tp}. Run `python scripts/schwab_auth.py` "
                f"from a session where you can open a browser."
            )

        age = datetime.now() - datetime.fromtimestamp(tp.stat().st_mtime)
        if age > timedelta(days=TOKEN_LIFETIME_DAYS):
            raise SchwabAuthExpired(
                f"Schwab refresh token is {age.days} days old and Schwab expires "
                f"them at {TOKEN_LIFETIME_DAYS}. Re-run "
                f"`python scripts/schwab_auth.py`. This happens every week; it "
                f"is the API's design, not a bug in this engine."
            )
        if age > timedelta(days=TOKEN_LIFETIME_DAYS - 1):
            log.warning(
                "Schwab token expires within 24h -- re-auth before tomorrow's run."
            )

        self._client = client_from_token_file(
            token_path=str(tp),
            api_key=self.api_key,
            app_secret=self.app_secret,
        )
        return self._client

    @property
    def account_hash(self) -> str:
        if self._account_hash:
            return self._account_hash
        c = self.ensure_auth()
        data = c.get_account_numbers().json()
        if not data:
            raise RuntimeError("Schwab returned no linked accounts")
        self._account_hash = data[self.account_index]["hashValue"]
        return self._account_hash

    # -- market data ------------------------------------------------------

    def quote(self, symbol: str) -> dict[str, Any]:
        c = self.ensure_auth()
        return c.get_quote(symbol).json().get(symbol, {})

    def spot(self, symbol: str) -> float | None:
        q = self.quote(symbol)
        for section in ("quote", "regular"):
            block = q.get(section, {})
            for key in ("lastPrice", "regularMarketLastPrice", "mark"):
                if block.get(key):
                    return float(block[key])
        return None

    def option_chain(
        self, symbol: str, *, from_date=None, to_date=None
    ) -> dict[str, Any]:
        c = self.ensure_auth()
        kwargs: dict[str, Any] = {}
        if from_date:
            kwargs["from_date"] = from_date
        if to_date:
            kwargs["to_date"] = to_date
        return c.get_option_chain(symbol, **kwargs).json()

    def parsed_chain(self, symbol: str, **kw: Any) -> list[OptionQuote]:
        """Flatten Schwab's nested chain into OptionQuote rows.

        Schwab nests as callExpDateMap -> "2026-08-28:2" -> "252.5" -> [ {...} ].
        The date key carries a ":N" days-to-expiry suffix that has to be stripped.
        """
        raw = self.option_chain(symbol, **kw)
        out: list[OptionQuote] = []
        for map_key, right in (("callExpDateMap", "C"), ("putExpDateMap", "P")):
            for exp_key, strikes in (raw.get(map_key) or {}).items():
                expiry = exp_key.split(":")[0]
                for _strike, contracts in strikes.items():
                    for k in contracts:
                        try:
                            out.append(
                                OptionQuote(
                                    symbol=k["symbol"],
                                    underlying=symbol,
                                    expiry=expiry,
                                    strike=float(k["strikePrice"]),
                                    right=right,
                                    bid=float(k.get("bid") or 0.0),
                                    ask=float(k.get("ask") or 0.0),
                                    iv=(
                                        float(k["volatility"]) / 100.0
                                        if k.get("volatility") not in (None, -999.0)
                                        else None
                                    ),
                                    delta=(
                                        float(k["delta"])
                                        if k.get("delta") not in (None, -999.0)
                                        else None
                                    ),
                                    open_interest=int(k.get("openInterest") or 0),
                                    volume=int(k.get("totalVolume") or 0),
                                )
                            )
                        except (KeyError, TypeError, ValueError) as e:
                            log.debug("skipping malformed contract for %s: %s", symbol, e)
        return out

    def price_history_daily(self, symbol: str, *, days: int = 400) -> list[dict[str, Any]]:
        c = self.ensure_auth()
        resp = c.get_price_history_every_day(symbol)
        return resp.json().get("candles", [])[-days:]

    # -- orders -----------------------------------------------------------

    def place_order(self, order: dict[str, Any]) -> dict[str, Any]:
        """Submit. Only ever reached through Executor with every gate open."""
        c = self.ensure_auth()
        resp = c.place_order(self.account_hash, order)
        if resp.status_code >= 400:
            raise RuntimeError(
                f"Schwab rejected the order ({resp.status_code}): {resp.text}. "
                f"Note that futures orders always return 400 -- this API is "
                f"equities and options only."
            )
        location = resp.headers.get("Location", "")
        return {"orderId": location.rsplit("/", 1)[-1] if location else None,
                "status": resp.status_code}

    def open_orders(self) -> list[dict[str, Any]]:
        c = self.ensure_auth()
        return c.get_orders_for_account(self.account_hash).json()
