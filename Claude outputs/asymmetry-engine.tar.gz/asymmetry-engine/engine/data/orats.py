"""ORATS Data API v2 -- the historical side of the edge test.

Base URL: https://api.orats.io/datav2   Token: ?token=...   Limit: 1000 req/min

Why ORATS rather than scraping something free: the whole engine rests on
comparing today's implied move to a distribution of past realized moves. That
comparison is only as good as the history behind it, and free option history is
either absent or wrong in ways you discover six months in. Two endpoints do most
of the work here:

  /hist/earnings   earnings history WITH announcement timing (bmo/amc), which is
                   what decides whether a name moves on session D or D+1. Getting
                   that offset wrong silently screens the day after the move.
  /hist/dailies    end-of-day OHLC, from which the overnight gaps are computed.

`/cores` also carries ORATS's own `impliedEarningsMove` / `impErnMv`. The engine
computes its own implied move from the vol term structure and uses theirs only
as a cross-check -- two independent numbers disagreeing is a signal that
something is stale, and that is worth knowing before sizing a position.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Iterable, Sequence

import requests

from ..mispricing import HistoricalMoves

log = logging.getLogger(__name__)

BASE_URL = "https://api.orats.io/datav2"


class OratsError(RuntimeError):
    pass


class OratsAuthError(OratsError):
    """Token rejected. Fatal, and never retried across a sweep.

    A bad token fails identically on every symbol. Swallowing it per-symbol
    turns a one-line fix into 512 identical error lines and a run that reports
    "0 found" as though the data were clean. Auth failures stop the run.
    """


TOKEN_RE = re.compile(r"^[A-Za-z0-9\-]{20,}$")


def clean_token(raw: str) -> str:
    """Strip whitespace and anything that cannot be in a token.

    Copy-paste picks things up -- a trailing newline, a smart quote, an Option
    key slip that lands a stray character on the end. The API sees the junk,
    URL-encodes it, and returns 403 with no hint about what is wrong.
    """
    return re.sub(r"[^A-Za-z0-9\-]", "", (raw or "").strip())


@dataclass
class OratsClient:
    token: str
    base_url: str = BASE_URL
    timeout: int = 30
    session: requests.Session | None = None
    # On-disk cache for /hist/* responses. A historical chain for 2026-08-28 is
    # the same forever, so re-running a sweep with different thresholds should
    # cost zero requests. Without this, tuning `--min-multiple` nine times
    # against the full universe would spend the whole monthly allowance on data
    # you already had. Set to None to disable.
    cache_dir: str | Path | None = "state/orats_cache"

    def __post_init__(self) -> None:
        raw = self.token
        self.token = clean_token(raw)
        if raw and self.token != raw:
            log.warning(
                "ORATS token had %d stray character(s) stripped (whitespace or "
                "a bad paste). Using the cleaned value.", len(raw) - len(self.token)
            )
        if self.token and not TOKEN_RE.match(self.token):
            log.warning(
                "ORATS token does not look like a valid token (%d chars). "
                "Check the ORATS_TOKEN line in .env.", len(self.token)
            )
        self.session = self.session or requests.Session()
        if self.cache_dir:
            self.cache_dir = Path(self.cache_dir)
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _cache_path(self, path: str, params: dict[str, Any]) -> Path | None:
        """Cache only immutable history. Live endpoints must never be cached."""
        if not self.cache_dir or not path.startswith("/hist/"):
            return None
        key = path + "?" + "&".join(
            f"{k}={v}" for k, v in sorted(params.items()) if k != "token"
        )
        digest = hashlib.sha256(key.encode()).hexdigest()[:20]
        return Path(self.cache_dir) / f"{digest}.json"

    def _get(self, path: str, fresh: bool = False, **params: Any) -> list[dict[str, Any]]:
        # `fresh` skips the cache. Historical chains never change, but today's
        # daily bar does -- serving a cached one to a live scanner would quietly
        # feed it yesterday's price all afternoon.
        cache = None if fresh else self._cache_path(path, params)
        if cache and cache.exists():
            try:
                return json.loads(cache.read_text())
            except (json.JSONDecodeError, OSError):
                cache.unlink(missing_ok=True)   # corrupt entry, refetch

        params["token"] = self.token
        url = f"{self.base_url}{path}"
        r = self.session.get(url, params=params, timeout=self.timeout)
        if r.status_code in (401, 403):
            raise OratsAuthError(
                f"ORATS rejected the token ({r.status_code}). This fails the same "
                f"way for every symbol, so the run is stopping here rather than "
                f"repeating it.\n"
                f"  Check the ORATS_TOKEN line in .env for stray characters, and "
                f"confirm the subscription is active and covers this endpoint."
            )
        if r.status_code == 429:
            raise OratsError("ORATS rate limit hit (1000/min). Back off and retry.")
        r.raise_for_status()
        payload = r.json()
        data = payload.get("data", payload)
        if not isinstance(data, list):
            raise OratsError(f"unexpected ORATS payload shape from {path}: {type(data)}")

        if cache:
            try:
                cache.write_text(json.dumps(data))
            except OSError as e:
                log.debug("could not cache %s: %s", path, e)

        return data

    # -- raw endpoints ----------------------------------------------------

    def earnings_history(self, ticker: str) -> list[dict[str, Any]]:
        """/hist/earnings -- past announcement dates and timing for one name."""
        return self._get("/hist/earnings", ticker=ticker)

    def dailies(self, ticker: str, *, trade_date: str | None = None,
                fresh: bool = False) -> list[dict[str, Any]]:
        """/hist/dailies -- end-of-day OHLC. `fresh=True` for same-session use."""
        params: dict[str, Any] = {"ticker": ticker}
        if trade_date:
            params["tradeDate"] = trade_date
        return self._get("/hist/dailies", fresh=fresh, **params)

    def hist_strikes(self, ticker: str, trade_date: str) -> list[dict[str, Any]]:
        """/hist/strikes -- the full historical chain for one session."""
        return self._get("/hist/strikes", ticker=ticker, tradeDate=trade_date)

    def cores(self, ticker: str) -> list[dict[str, Any]]:
        """/cores -- includes earnDate, nextErn, impliedEarningsMove, impErnMv.

        Not a /hist/ path, so never cached -- it carries today's price and volume.
        """
        return self._get("/cores", ticker=ticker)

    # -- derived ----------------------------------------------------------

    def catalyst_gaps(
        self,
        ticker: str,
        *,
        catalyst_dates: Sequence[date] | None = None,
        catalyst_kind: str = "own_earnings",
        max_events: int = 20,
    ) -> HistoricalMoves:
        """Realized overnight gaps for `ticker` around a set of catalyst dates.

        With `catalyst_dates` omitted, uses the name's own earnings history --
        the CRM case. Pass a peer's earnings dates to build the MU-after-NVDA
        conditioning set instead; the arithmetic is identical, which is the
        point.

        A gap is open(D+1) / close(D) - 1 where D is the last session before the
        move. Overnight rather than close-to-close on purpose: it is the number
        the option actually reprices against at the open, and it is the number
        both motivating trades were made of.
        """
        bars = self.dailies(ticker)
        by_date: dict[str, dict[str, Any]] = {}
        for b in bars:
            d = b.get("tradeDate") or b.get("quoteDate")
            if d:
                by_date[str(d)[:10]] = b
        sessions = sorted(by_date)
        if len(sessions) < 2:
            return HistoricalMoves(symbol=ticker, catalyst_kind=catalyst_kind, gaps=())

        idx = {d: i for i, d in enumerate(sessions)}

        if catalyst_dates is None:
            events = self._own_earnings_move_sessions(ticker)
        else:
            events = [d.isoformat() for d in catalyst_dates]

        gaps: list[float] = []
        used: list[str] = []
        for ev in sorted(set(events), reverse=True):
            if len(gaps) >= max_events:
                break
            # First session on or after the event date that we have data for.
            after = next((s for s in sessions if s >= ev), None)
            if after is None or idx[after] == 0:
                continue
            before = sessions[idx[after] - 1]
            prev_close = _f(by_date[before], "clsPx", "close", "cPrice")
            open_px = _f(by_date[after], "opnPx", "open", "oPrice")
            if not prev_close or not open_px or prev_close <= 0:
                continue
            gaps.append(open_px / prev_close - 1.0)
            used.append(after)

        return HistoricalMoves(
            symbol=ticker,
            catalyst_kind=catalyst_kind,
            gaps=tuple(gaps),
            dates=tuple(used),
        )

    def _own_earnings_move_sessions(self, ticker: str) -> list[str]:
        """Earnings dates mapped to the session the move actually lands in.

        `anncTod` (announcement time of day) decides it: a name reporting after
        the close moves the NEXT session. When the field is missing, amc is
        assumed, because amc is far more common and assuming bmo would put the
        engine a day late.
        """
        out: list[str] = []
        for e in self.earnings_history(ticker):
            raw = e.get("earnDate") or e.get("tradeDate")
            if not raw:
                continue
            d = datetime.strptime(str(raw)[:10], "%Y-%m-%d").date()
            timing = str(e.get("anncTod", "")).lower()
            if "before" in timing or timing == "bmo" or timing == "1":
                out.append(d.isoformat())
            else:
                out.append((d + timedelta(days=1)).isoformat())
        return out

    def peer_catalyst_gaps(
        self, ticker: str, bellwether: str, *, max_events: int = 20
    ) -> HistoricalMoves:
        """MU's gaps on the mornings after NVDA reported. The sympathy set."""
        sessions = self._own_earnings_move_sessions(bellwether)
        dates = [datetime.strptime(s, "%Y-%m-%d").date() for s in sessions]
        return self.catalyst_gaps(
            ticker,
            catalyst_dates=dates,
            catalyst_kind=f"peer_earnings:{bellwether}",
            max_events=max_events,
        )

    def earnings_move_history(self, ticker: str) -> HistoricalMoves:
        """Twelve past earnings moves from ONE /cores call.

        ORATS precomputes `ernMv1`..`ernMv12` -- the percentage move for each of
        the last twelve earnings dates -- alongside `ernDate1`..`ernDate12`.
        That is exactly the conditioning set `catalyst_gaps` was reconstructing
        from daily bars at roughly thirty requests a name. This costs one.

        Prefer this for own-earnings history. `catalyst_gaps` is still needed for
        peer-conditioned sets (MU on NVDA's dates), which ORATS does not
        precompute because nobody else asks that question.
        """
        rows = self.cores(ticker)
        if not rows:
            return HistoricalMoves(symbol=ticker, catalyst_kind="own_earnings", gaps=())

        row = rows[0]
        moves: list[float] = []
        dates: list[str] = []
        for i in range(1, 13):
            mv = _f(row, f"ernMv{i}")
            if mv is None:
                continue
            # ORATS reports these as percentages; the engine works in decimals.
            moves.append(mv / 100.0 if abs(mv) > 1.5 else mv)
            d = row.get(f"ernDate{i}")
            dates.append(str(d)[:10] if d else "")

        return HistoricalMoves(
            symbol=ticker,
            catalyst_kind="own_earnings",
            gaps=tuple(moves),
            dates=tuple(dates),
        )

    def historical_straddle_pcts(self, ticker: str) -> list[float]:
        """`ernStraPct1`..`12` -- what the straddle cost at each past event.

        Paired with `earnings_move_history`, this gives implied AND realized for
        the same twelve events, which is the edge test with no reconstruction at
        all. Returned as decimals.
        """
        rows = self.cores(ticker)
        if not rows:
            return []
        row = rows[0]
        out = []
        for i in range(1, 13):
            v = _f(row, f"ernStraPct{i}")
            if v is not None:
                out.append(v / 100.0 if abs(v) > 1.5 else v)
        return out

    def edge_snapshot(self, ticker: str) -> dict[str, Any]:
        """Everything the screen wants about one name, in a single request.

        Beyond the earnings history: IV rank and percentile for whether options
        are cheap, the one-year price change for the beaten-down score, average
        option volume for liquidity, skew slope, and `tkOver` / `borrow30` --
        the takeover flag and hard-to-borrow rate, which are the closest thing
        ORATS has to a squeeze proxy.
        """
        rows = self.cores(ticker)
        if not rows:
            return {}
        r = rows[0]
        return {
            "ticker": ticker,
            "implied_earnings_move": _f(r, "impliedEarningsMove", "impErnMv"),
            "avg_abs_earn_move": _f(r, "absAvgErnMv"),
            "earn_move_stdev": _f(r, "ernMvStdv"),
            "next_earnings": r.get("nextErn") or r.get("earnDate"),
            "last_earnings": r.get("lastErn"),
            "weeks_to_earnings": _f(r, "wksNextErn"),
            "iv_rank_1y": _f(r, "ivRank1y"),
            "iv_pctile_1y": _f(r, "ivPct1y"),
            "iv_hv_ratio": _f(r, "ivHvXernRatio"),
            "px_change_1y": _f(r, "stkPxChng1y"),
            "px_change_1m": _f(r, "stkPxChng1m"),
            "close_1y_ago": _f(r, "clsPx1y"),
            "avg_option_volume_20d": _f(r, "avgOptVolu20d"),
            "slope": _f(r, "slope"),
            "slope_forecast": _f(r, "slopeFcst"),
            "borrow_30d": _f(r, "borrow30"),
            "takeover_flag": _f(r, "tkOver"),
            "market_cap": _f(r, "mktCap"),
            "sector": r.get("sectorName") or r.get("sector"),
        }

    def implied_earnings_move(self, ticker: str) -> float | None:
        """ORATS's own implied earnings move, as a cross-check on ours."""
        rows = self.cores(ticker)
        if not rows:
            return None
        row = rows[0]
        for key in ("impliedEarningsMove", "impErnMv", "impliedEarningsMv"):
            v = row.get(key)
            if v is not None:
                try:
                    return float(v)
                except (TypeError, ValueError):
                    continue
        return None


def _f(row: dict[str, Any], *keys: str) -> float | None:
    """ORATS field names vary by endpoint; try the known spellings in order."""
    for k in keys:
        v = row.get(k)
        if v is not None:
            try:
                return float(v)
            except (TypeError, ValueError):
                continue
    return None
