"""Turning a passed edge into an actual position.

The edge test says "this event is underpriced." It does not say which way the
stock goes, and nothing downstream is allowed to pretend otherwise. So the
structures here are all move-buyers, not direction-buyers:

  STRANGLE  -- long call and long put outside the implied move. Cheapest way to
               own the tails. Needs a big move to pay; wins large when it does.
  STRADDLE  -- long ATM call and put. Costs more, needs less move to break even.
  SINGLE    -- one side only, and ONLY when the vol surface says that side is
               unusually cheap relative to its own history for this name. This
               is the one place a directional lean is permitted, and it comes
               from skew, not from an opinion about the news.

Every structure here is a long-premium debit position. Max loss is the debit,
known at entry, and that is deliberate: it makes the 5-contract cap a real
dollar cap rather than a notional one, and it means no overnight gap can
produce a loss bigger than the ticket you already agreed to.

Nothing here sells naked premium. That is not a technical limitation.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Sequence

import numpy as np

from .mispricing import EdgeResult, round_trip_spread_fraction


class StructureKind(str, Enum):
    STRANGLE = "strangle"
    STRADDLE = "straddle"
    SINGLE_CALL = "single_call"
    SINGLE_PUT = "single_put"


@dataclass(frozen=True)
class OptionQuote:
    symbol: str          # OSI 21-char, e.g. CRM   260828C00252500
    underlying: str
    expiry: str
    strike: float
    right: str           # "C" | "P"
    bid: float
    ask: float
    iv: float | None = None
    delta: float | None = None
    open_interest: int | None = None
    volume: int | None = None

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2.0

    @property
    def spread_frac(self) -> float:
        if self.mid <= 0:
            return float("inf")
        return (self.ask - self.bid) / self.mid

    def is_tradeable(self, *, min_oi: int = 100, max_spread_frac: float = 0.25) -> bool:
        """Can you actually get filled here, twice, without giving away the trade?

        Open interest is the check that keeps the engine off the strikes that
        look brilliant on a chart and cannot be exited on the day it matters.
        """
        if self.bid <= 0 or self.ask <= 0 or self.ask < self.bid:
            return False
        if self.open_interest is not None and self.open_interest < min_oi:
            return False
        return self.spread_frac <= max_spread_frac


@dataclass
class Structure:
    kind: StructureKind
    underlying: str
    expiry: str
    legs: tuple[OptionQuote, ...]
    contracts: int = 1

    # Filled by price()
    debit_per_contract: float = 0.0     # dollars, already x100
    max_loss: float = 0.0               # dollars, == debit for all of these
    breakevens: tuple[float, ...] = ()
    spread_cost_frac: float = 0.0
    rationale: str = ""

    def price(self, spot: float) -> "Structure":
        per_share = sum(leg.ask for leg in self.legs)   # you pay the ask
        self.debit_per_contract = per_share * 100.0
        self.max_loss = self.debit_per_contract * self.contracts
        self.spread_cost_frac = round_trip_spread_fraction(
            [(leg.bid, leg.ask) for leg in self.legs]
        )

        calls = [l for l in self.legs if l.right == "C"]
        puts = [l for l in self.legs if l.right == "P"]
        bes: list[float] = []
        if calls:
            bes.append(min(c.strike for c in calls) + per_share)
        if puts:
            bes.append(max(p.strike for p in puts) - per_share)
        self.breakevens = tuple(sorted(bes))
        return self

    def payoff_at(self, price_at_expiry: float) -> float:
        """Dollar P/L for the whole position at expiry."""
        per_share = 0.0
        for leg in self.legs:
            if leg.right == "C":
                per_share += max(price_at_expiry - leg.strike, 0.0)
            else:
                per_share += max(leg.strike - price_at_expiry, 0.0)
        return per_share * 100.0 * self.contracts - self.max_loss

    def payoff_over_history(self, spot: float, gaps: Sequence[float]) -> np.ndarray:
        """P/L had this exact structure been held through each past catalyst.

        This is the number that matters and the one a payoff-multiple screen
        never shows you: most entries are a total loss of the debit, and the
        distribution's mean is what decides whether the trade is worth taking.
        """
        return np.array(
            [self.payoff_at(spot * (1.0 + g)) for g in gaps], dtype=float
        )

    def describe(self) -> str:
        legs = " + ".join(
            f"{l.expiry} {l.strike:g}{l.right} @ {l.ask:.2f}" for l in self.legs
        )
        return f"{self.underlying} {self.kind.value} x{self.contracts}: {legs}"


def _nearest(quotes: Iterable[OptionQuote], target: float) -> OptionQuote | None:
    quotes = list(quotes)
    if not quotes:
        return None
    return min(quotes, key=lambda q: abs(q.strike - target))


def build_structures(
    edge: EdgeResult,
    chain: Sequence[OptionQuote],
    *,
    spot: float,
    expiry: str,
    min_oi: int = 100,
    max_leg_spread_frac: float = 0.25,
    skew_cheap_threshold: float = 0.85,
    historical_skew_ratio: float | None = None,
) -> list[Structure]:
    """Produce the candidate expressions of a passed edge, cheapest tail first.

    `historical_skew_ratio` is this name's typical call-IV / put-IV at 25 delta.
    When today's ratio sits meaningfully below it, the call side is on sale
    relative to how this name normally prices, and a single-sided call is
    allowed. That is a statement about the vol surface, not about the company.
    """
    if not edge.passed:
        return []

    live = [
        q
        for q in chain
        if q.expiry == expiry
        and q.is_tradeable(min_oi=min_oi, max_spread_frac=max_leg_spread_frac)
    ]
    calls = [q for q in live if q.right == "C"]
    puts = [q for q in live if q.right == "P"]
    if not calls or not puts:
        return []

    move = edge.implied.move_pct * spot
    out: list[Structure] = []

    # --- Straddle: ATM both sides -------------------------------------------
    atm_c, atm_p = _nearest(calls, spot), _nearest(puts, spot)
    if atm_c and atm_p:
        s = Structure(
            kind=StructureKind.STRADDLE,
            underlying=edge.symbol,
            expiry=expiry,
            legs=(atm_c, atm_p),
        ).price(spot)
        s.rationale = (
            f"Owns the move from the money. Needs {edge.symbol} to travel "
            f"{(s.breakevens[1] - spot) / spot * 100:.1f}% either way; it has "
            f"averaged {edge.history.mean_abs() * 100:.1f}% on the last "
            f"{edge.history.n} of these."
        )
        out.append(s)

    # --- Strangle: one implied move out on each side ------------------------
    up_c, dn_p = _nearest(calls, spot + move), _nearest(puts, spot - move)
    if up_c and dn_p and up_c.strike > (atm_c.strike if atm_c else spot):
        s = Structure(
            kind=StructureKind.STRANGLE,
            underlying=edge.symbol,
            expiry=expiry,
            legs=(up_c, dn_p),
        ).price(spot)
        s.rationale = (
            f"Cheaper tails, struck at roughly the implied move "
            f"({edge.implied.move_pct * 100:.1f}%). Pays only if the chain is "
            f"wrong by a wide margin, which is the whole bet."
        )
        out.append(s)

    # --- Single side, permitted only by skew --------------------------------
    if historical_skew_ratio is not None and atm_c and atm_p:
        c_iv, p_iv = atm_c.iv, atm_p.iv
        if c_iv and p_iv and p_iv > 0:
            today_ratio = c_iv / p_iv
            rel = today_ratio / historical_skew_ratio
            if rel < skew_cheap_threshold:
                s = Structure(
                    kind=StructureKind.SINGLE_CALL,
                    underlying=edge.symbol,
                    expiry=expiry,
                    legs=(up_c or atm_c,),
                ).price(spot)
                s.rationale = (
                    f"Call side is {(1 - rel) * 100:.0f}% cheaper than this "
                    f"name's usual call/put IV balance. Skew, not a view on the "
                    f"news. Half the structures' cost, none of the downside tail."
                )
                out.append(s)
            elif rel > 1.0 / skew_cheap_threshold:
                s = Structure(
                    kind=StructureKind.SINGLE_PUT,
                    underlying=edge.symbol,
                    expiry=expiry,
                    legs=(dn_p or atm_p,),
                ).price(spot)
                s.rationale = (
                    f"Put side is cheap relative to this name's usual call/put "
                    f"IV balance. Skew, not a view on the news."
                )
                out.append(s)

    return out
