"""Configuration. Every threshold that decides a trade lives here, not in code.

The point of putting the numbers in a file you edit before the session is that
changing them is a decision with a timestamp, rather than something that happens
in the ten seconds between seeing a setup and wanting to be in it.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .risk import RiskLimits


@dataclass
class ScreenConfig:
    universe: list[str] = field(default_factory=list)
    min_rvol: float = 2.0
    rvol_window_minutes: int = 15
    min_ev_multiple: float = 1.25
    min_sample: int = 8
    max_spread_cost_frac: float = 0.20
    min_open_interest: int = 100
    max_leg_spread_frac: float = 0.25
    require_term_structure: bool = False
    max_candidates_per_session: int = 3


@dataclass
class AppConfig:
    root: Path
    mode: str = "paper"
    # Where live chains and quotes come from. "orats" needs only a token and
    # has no weekly re-auth; "schwab" is free but needs an approved app and a
    # browser login every 7 days. Order placement requires schwab, and is
    # unreachable in paper mode anyway.
    data_source: str = "orats"
    account_equity: float = 10_000.0
    journal_path: str = "state/journal.db"
    dashboard_path: str = "state/dashboard.html"
    screen: ScreenConfig = field(default_factory=ScreenConfig)
    risk: RiskLimits = field(default_factory=RiskLimits)
    min_closed_positions_before_live: int = 30

    # Secrets come from the environment, never the yaml, never the repo.
    @property
    def orats_token(self) -> str:
        return _require_env("ORATS_TOKEN")

    @property
    def schwab_api_key(self) -> str:
        return _require_env("SCHWAB_API_KEY")

    @property
    def schwab_app_secret(self) -> str:
        return _require_env("SCHWAB_APP_SECRET")

    @property
    def schwab_callback_url(self) -> str:
        return os.environ.get("SCHWAB_CALLBACK_URL", "https://127.0.0.1:8182")

    @property
    def schwab_token_path(self) -> str:
        return os.environ.get(
            "SCHWAB_TOKEN_PATH", str(self.root / "state" / "schwab_token.json")
        )


def _require_env(name: str) -> str:
    v = os.environ.get(name)
    if not v:
        raise RuntimeError(
            f"{name} is not set. Put it in .env next to config.yaml "
            f"(and keep .env out of git -- it is already in .gitignore)."
        )
    return v


def load_config(path: str | Path = "config.yaml") -> AppConfig:
    p = Path(path).resolve()
    root = p.parent
    raw: dict[str, Any] = yaml.safe_load(p.read_text()) or {}

    screen = ScreenConfig(**(raw.get("screen") or {}))
    risk = RiskLimits(**(raw.get("risk") or {}))

    return AppConfig(
        root=root,
        mode=raw.get("mode", "paper"),
        data_source=raw.get("data_source", "orats"),
        account_equity=float(raw.get("account_equity", 10_000.0)),
        journal_path=raw.get("journal_path", "state/journal.db"),
        dashboard_path=raw.get("dashboard_path", "state/dashboard.html"),
        screen=screen,
        risk=risk,
        min_closed_positions_before_live=int(
            raw.get("min_closed_positions_before_live", 30)
        ),
    )


def load_dotenv(path: str | Path = ".env") -> None:
    """Minimal .env loader so no secret ever needs to sit in a shell profile."""
    p = Path(path)
    if not p.exists():
        return
    for line in p.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'").strip())
