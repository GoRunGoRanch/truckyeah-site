"""Order construction, and the gate in front of live submission.

Design position, stated plainly so it is not a surprise later: this module builds
orders and, in paper mode, logs them. Live submission is implemented but it is
locked behind conditions that cannot all be satisfied by editing one flag in a
hurry on a Tuesday morning:

  1. `mode: live` in config.yaml, changed deliberately and committed.
  2. `ASYMMETRY_LIVE_CONFIRM` set in the environment to today's date. It expires
     every day, so an unattended run cannot go live on a stale confirmation.
  3. At least `min_closed_positions_before_live` closed paper positions in the
     journal, with positive expectancy. The track record earns the promotion.
  4. No kill-switch file.

Three of those four are about time rather than technology. That is intentional.
The gap between "this looks great" and "this is still worth doing tomorrow" is
where most of the damage in a trading account gets avoided.

On the API itself: thinkorswim has no supported order endpoint. This targets the
Schwab Trader API, which means (a) equities and options only -- a futures order
returns HTTP 400 -- and (b) the refresh token expires every seven days, so a
scheduled run WILL eventually fail on auth and must fail loudly rather than
silently skipping the session.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any, Literal

from .journal import Journal
from .structures import Structure

Mode = Literal["paper", "live"]


class LiveTradingBlocked(RuntimeError):
    """Raised when live submission is requested but not earned."""


@dataclass(frozen=True)
class LiveGate:
    min_closed_positions_before_live: int = 30
    require_positive_expectancy: bool = True

    def check(self, *, mode: Mode, journal: Journal, root: Path,
              kill_switch_rel: str) -> None:
        if mode != "live":
            return

        if (root / kill_switch_rel).exists():
            raise LiveTradingBlocked(
                f"kill switch present at {kill_switch_rel} -- remove it deliberately"
            )

        confirm = os.environ.get("ASYMMETRY_LIVE_CONFIRM", "")
        today = date.today().isoformat()
        if confirm != today:
            raise LiveTradingBlocked(
                "ASYMMETRY_LIVE_CONFIRM must equal today's date "
                f"({today}); got {confirm!r}. This expires daily so a scheduled "
                "run cannot go live on yesterday's decision."
            )

        rec = journal.track_record(mode="paper")
        if rec["closed"] < self.min_closed_positions_before_live:
            raise LiveTradingBlocked(
                f"only {rec['closed']} closed paper positions; "
                f"{self.min_closed_positions_before_live} required. The record "
                "has not earned live money yet."
            )
        if self.require_positive_expectancy and (rec["avg_pnl"] or 0) <= 0:
            raise LiveTradingBlocked(
                f"paper expectancy is {rec['avg_pnl']:.2f} per position. "
                "Going live on a losing system is how an account dies."
            )


def build_schwab_order(structure: Structure, *, limit_price: float | None = None,
                       duration: str = "DAY") -> dict[str, Any]:
    """Schwab Trader API order payload for a long debit structure.

    Always a NET_DEBIT limit order. Market orders on multi-leg option spreads are
    a reliable way to get a fill you did not want -- on a wide weekly chain the
    market order is the trade.

    Note: multi-leg option orders on this API are reported as experimental by the
    developer community. Validate single-leg first and check every multi-leg fill
    by hand before trusting a scheduled run with one.
    """
    if limit_price is None:
        limit_price = round(sum(leg.ask for leg in structure.legs), 2)

    legs = [
        {
            "instruction": "BUY_TO_OPEN",
            "quantity": structure.contracts,
            "instrument": {"symbol": leg.symbol, "assetType": "OPTION"},
        }
        for leg in structure.legs
    ]

    return {
        "orderType": "NET_DEBIT",
        "session": "NORMAL",
        "price": f"{limit_price:.2f}",
        "duration": duration,
        "orderStrategyType": "SINGLE",
        "complexOrderStrategyType": (
            "STRADDLE" if structure.kind.value == "straddle"
            else "STRANGLE" if structure.kind.value == "strangle"
            else "NONE"
        ),
        "orderLegCollection": legs,
    }


class Executor:
    """Submits nothing unless every gate is open. Logs everything either way."""

    def __init__(
        self,
        *,
        mode: Mode,
        journal: Journal,
        root: Path,
        gate: LiveGate | None = None,
        kill_switch_rel: str = "state/KILL",
        schwab_client: Any | None = None,
    ):
        self.mode = mode
        self.journal = journal
        self.root = root
        self.gate = gate or LiveGate()
        self.kill_switch_rel = kill_switch_rel
        self.schwab = schwab_client

    def preflight(self) -> None:
        self.gate.check(
            mode=self.mode,
            journal=self.journal,
            root=self.root,
            kill_switch_rel=self.kill_switch_rel,
        )

    def submit(self, structure: Structure, candidate_id: int) -> dict[str, Any]:
        order = build_schwab_order(structure)

        if self.mode == "paper":
            self.journal.mark(
                candidate_id,
                kind="intraday",
                position_value=structure.max_loss,
                note=f"PAPER order built, not sent: {structure.describe()}",
            )
            return {"status": "paper", "order": order, "submitted": False}

        self.preflight()
        if self.schwab is None:
            raise LiveTradingBlocked("live mode requested but no Schwab client wired")

        resp = self.schwab.place_order(order)
        self.journal.mark(
            candidate_id,
            kind="intraday",
            position_value=structure.max_loss,
            note=f"LIVE order submitted: {resp.get('orderId', 'unknown id')}",
        )
        return {"status": "live", "order": order, "submitted": True, "response": resp}
