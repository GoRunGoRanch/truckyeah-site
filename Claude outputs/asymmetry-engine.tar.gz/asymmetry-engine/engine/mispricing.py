"""
The edge test.

Everything else in this engine is plumbing. This module is the only part that
claims an edge, so it is the only part worth arguing with.

The claim is NOT "this option is cheap so it might go up a lot." Every option
that costs $0.08 has a large potential multiple; that is what $0.08 means. The
claim is narrower and testable:

    For this name, on this KIND of catalyst, the option chain is currently
    pricing a smaller move than the name has historically made on that kind of
    catalyst.

If that gap is real and large enough to survive the bid-ask spread, buying the
move (rather than guessing the direction) has positive expectancy. If it is not,
the setup is declined no matter how attractive the payoff multiple looks.

Two ways to read the implied move, in order of preference:

  1. Vol-term-structure extraction. The front expiry contains the event; a later
     expiry mostly does not. The variance difference isolates the event:

         event_var = T_front * (sigma_front^2 - sigma_back^2)
         implied_event_move = sqrt(event_var)

     This is the honest number. It requires two expiries with usable IV.

  2. ATM straddle approximation, implied_move ~= 0.85 * straddle_mid / spot.
     Cruder -- the straddle also prices ordinary drift between now and expiry --
     and it runs when only one expiry is usable. Flagged as `approx` so it never
     silently passes for the good number.

The historical side is conditioned on catalyst TYPE, which is what lets one
formula cover both of Vivek's examples:

  * CRM: condition on the name's OWN earnings dates. Gap distribution of CRM on
    its own prints.
  * MU after an NVDA report: condition on the PEER's earnings dates. Gap
    distribution of MU on mornings after NVDA printed.

Same test, different conditioning set. No direction guess in either case.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Sequence

import numpy as np

# A catalyst sample below this count cannot support a claim. Twelve quarterly
# prints is three years; fewer than eight and the standard error on the mean
# swamps any edge we could detect.
MIN_SAMPLE = 8

# Straddle-to-event-move conversion. The straddle prices the event plus ordinary
# diffusion over the remaining life of the option; empirically ~0.8-0.85 of the
# straddle is the event for a front-week expiry. Conservative end chosen on
# purpose: it makes the implied move LARGER, which makes an edge HARDER to find.
STRADDLE_TO_MOVE = 0.85


@dataclass(frozen=True)
class HistoricalMoves:
    """Realized moves for one name, conditioned on one catalyst type."""

    symbol: str
    catalyst_kind: str          # "own_earnings" | "peer_earnings:NVDA" | "macro:CPI"
    # Signed overnight gaps as decimals: open_after / close_before - 1
    gaps: tuple[float, ...]
    # Signed close-to-close moves on the session after the catalyst
    day_moves: tuple[float, ...] = ()
    dates: tuple[str, ...] = ()

    @property
    def n(self) -> int:
        return len(self.gaps)

    @property
    def abs_gaps(self) -> np.ndarray:
        return np.abs(np.asarray(self.gaps, dtype=float))

    def mean_abs(self) -> float:
        return float(self.abs_gaps.mean()) if self.n else float("nan")

    def median_abs(self) -> float:
        return float(np.median(self.abs_gaps)) if self.n else float("nan")

    def pct_abs(self, q: float) -> float:
        return float(np.percentile(self.abs_gaps, q)) if self.n else float("nan")

    def upside_share(self) -> float:
        """Fraction of past catalysts that gapped up. Reported, never traded on.

        A name that gapped up 9 of 12 times is not a name that will gap up next
        time. This exists so the dashboard can show it and you can notice when
        your gut is quietly leaning on it.
        """
        if not self.n:
            return float("nan")
        return float(sum(1 for g in self.gaps if g > 0) / self.n)

    def stderr_abs(self) -> float:
        """Standard error of the mean absolute move -- the humility number."""
        if self.n < 2:
            return float("nan")
        return float(self.abs_gaps.std(ddof=1) / math.sqrt(self.n))


@dataclass(frozen=True)
class ImpliedMove:
    symbol: str
    expiry: str
    move_pct: float             # decimal, e.g. 0.062 == 6.2%
    spot: float
    method: str                 # "term_structure" | "straddle_approx"
    atm_strike: float
    straddle_mid: float
    # Round-trip friction as a fraction of the straddle premium. Paying the ask
    # and selling the bid on a wide weekly chain is frequently 8-15% of premium,
    # and on the $0.08 strikes that produce the eye-catching multiples it can
    # exceed 50%. Ignoring it is how backtests lie.
    spread_cost_frac: float = 0.0

    @property
    def is_approx(self) -> bool:
        return self.method == "straddle_approx"

    @property
    def move_dollars(self) -> float:
        return self.move_pct * self.spot


@dataclass
class EdgeResult:
    symbol: str
    catalyst_kind: str
    implied: ImpliedMove
    history: HistoricalMoves

    # E[|realized|] / implied_move. Above 1.0 means the chain has historically
    # underpriced this event for this name.
    ev_multiple: float = float("nan")
    # Same, after subtracting round-trip spread cost. This is the one that counts.
    ev_multiple_net: float = float("nan")
    # Fraction of past catalysts whose gap exceeded today's implied move.
    exceed_rate: float = float("nan")
    # Crude 1-sigma band on ev_multiple from the sampling error of the mean.
    ev_multiple_stderr: float = float("nan")

    passed: bool = False
    reasons: list[str] = field(default_factory=list)

    def summary(self) -> str:
        pct = lambda x: f"{x * 100:.1f}%"
        return (
            f"{self.symbol} [{self.catalyst_kind}] "
            f"implied {pct(self.implied.move_pct)} ({self.implied.method}) vs "
            f"hist mean |gap| {pct(self.history.mean_abs())} on n={self.history.n} "
            f"-> EV x{self.ev_multiple:.2f} (net x{self.ev_multiple_net:.2f}), "
            f"exceeded {pct(self.exceed_rate)} of the time"
        )


def implied_move_from_term_structure(
    *,
    symbol: str,
    spot: float,
    front_expiry: str,
    front_iv: float,
    front_t_years: float,
    back_iv: float,
    back_t_years: float,
    atm_strike: float,
    straddle_mid: float,
    spread_cost_frac: float = 0.0,
) -> ImpliedMove | None:
    """Isolate the event move from the front/back implied vol difference.

    Returns None when the front expiry is not actually elevated over the back --
    that means the chain is not pricing an event at all, and there is nothing
    here to be mispriced.
    """
    if front_t_years <= 0 or back_t_years <= front_t_years:
        return None
    if front_iv <= back_iv:
        return None

    event_var = front_t_years * (front_iv**2 - back_iv**2)
    if event_var <= 0:
        return None

    return ImpliedMove(
        symbol=symbol,
        expiry=front_expiry,
        move_pct=math.sqrt(event_var),
        spot=spot,
        method="term_structure",
        atm_strike=atm_strike,
        straddle_mid=straddle_mid,
        spread_cost_frac=spread_cost_frac,
    )


def implied_move_from_straddle(
    *,
    symbol: str,
    spot: float,
    expiry: str,
    atm_strike: float,
    straddle_mid: float,
    spread_cost_frac: float = 0.0,
) -> ImpliedMove | None:
    if spot <= 0 or straddle_mid <= 0:
        return None
    return ImpliedMove(
        symbol=symbol,
        expiry=expiry,
        move_pct=STRADDLE_TO_MOVE * straddle_mid / spot,
        spot=spot,
        method="straddle_approx",
        atm_strike=atm_strike,
        straddle_mid=straddle_mid,
        spread_cost_frac=spread_cost_frac,
    )


def evaluate_edge(
    implied: ImpliedMove,
    history: HistoricalMoves,
    *,
    min_ev_multiple: float = 1.25,
    min_sample: int = MIN_SAMPLE,
    max_spread_cost_frac: float = 0.20,
    require_exact_method: bool = False,
) -> EdgeResult:
    """Decide whether the chain is underpricing this catalyst. Declines by default.

    `min_ev_multiple` defaults to 1.25 rather than 1.0 on purpose. At 1.0 you are
    betting on a coin you believe is exactly fair, using a sample of a dozen
    events, against a market maker who does this for a living. The 25% cushion is
    the margin for everything the model does not know.
    """
    res = EdgeResult(
        symbol=implied.symbol,
        catalyst_kind=history.catalyst_kind,
        implied=implied,
        history=history,
    )

    if history.n < min_sample:
        res.reasons.append(
            f"declined: only {history.n} prior {history.catalyst_kind} events, "
            f"need {min_sample} -- too few to claim anything"
        )
        return res

    if implied.move_pct <= 0:
        res.reasons.append("declined: implied move is zero or negative")
        return res

    if require_exact_method and implied.is_approx:
        res.reasons.append(
            "declined: only the straddle approximation was available and this "
            "run requires the term-structure extraction"
        )
        return res

    abs_gaps = history.abs_gaps
    res.ev_multiple = float(abs_gaps.mean() / implied.move_pct)
    res.exceed_rate = float((abs_gaps > implied.move_pct).mean())

    se = history.stderr_abs()
    res.ev_multiple_stderr = (
        float(se / implied.move_pct) if not math.isnan(se) else float("nan")
    )

    # A straddle bought at the ask and closed at the bid gives up spread twice.
    # Express that as a haircut on the expected payoff multiple.
    res.ev_multiple_net = res.ev_multiple * (1.0 - implied.spread_cost_frac)

    if implied.spread_cost_frac > max_spread_cost_frac:
        res.reasons.append(
            f"declined: round-trip spread is {implied.spread_cost_frac * 100:.0f}% "
            f"of premium (cap {max_spread_cost_frac * 100:.0f}%) -- the edge is "
            f"inside the spread, the market maker keeps it"
        )
        return res

    if res.ev_multiple_net < min_ev_multiple:
        res.reasons.append(
            f"declined: net EV multiple {res.ev_multiple_net:.2f} below the "
            f"{min_ev_multiple:.2f} threshold -- chain is pricing this fairly"
        )
        return res

    # Sanity check against the sampling error: if one standard error takes the
    # edge below breakeven, the sample is carrying the whole conclusion.
    if (
        not math.isnan(res.ev_multiple_stderr)
        and res.ev_multiple_net - res.ev_multiple_stderr < 1.0
    ):
        res.reasons.append(
            f"declined: EV multiple {res.ev_multiple_net:.2f} +/- "
            f"{res.ev_multiple_stderr:.2f} -- one standard error erases it, so "
            f"this is sample noise rather than an edge"
        )
        return res

    res.passed = True
    res.reasons.append(
        f"passed: chain implies {implied.move_pct * 100:.1f}% but this name has "
        f"averaged {history.mean_abs() * 100:.1f}% on its last {history.n} "
        f"{history.catalyst_kind} events, exceeding today's implied move "
        f"{res.exceed_rate * 100:.0f}% of the time"
    )
    if implied.is_approx:
        res.reasons.append(
            "caution: implied move came from the straddle approximation, not the "
            "term-structure extraction -- treat the number as soft"
        )
    return res


def round_trip_spread_fraction(
    legs: Sequence[tuple[float, float]],
) -> float:
    """Round-trip cost as a fraction of mid premium for a set of (bid, ask) legs.

    You buy at the ask and later sell at the bid, so you lose the full spread on
    every leg. On a $0.08/$0.12 quote that is 40% of mid, which is precisely why
    the lottery-ticket strikes that produce screenshot-worthy multiples are
    usually uninvestable.
    """
    total_mid = 0.0
    total_spread = 0.0
    for bid, ask in legs:
        if ask <= 0 or ask < bid:
            return float("inf")
        total_mid += (bid + ask) / 2.0
        total_spread += ask - bid
    if total_mid <= 0:
        return float("inf")
    return total_spread / total_mid
