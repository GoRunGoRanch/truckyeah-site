"""Reward tiers, and the move each one actually costs.

Your colour scheme:

    RED     5x   available
    YELLOW  10x  available
    GREEN   25x  available

Higher tier, better colour. That reads correctly as a *convexity* scale, and it
is how you already think about these, so it stays.

But a ratio on its own is half a trade. Every strike in a chain offers some
multiple; the far ones offer enormous multiples precisely because they will
probably expire worthless. A 25x that needs the stock to travel another 8% and a
25x that needs another 40% are the same colour and completely different bets.

So every tier here carries `required_move_pct` beside it, and a tier whose move
exceeds `max_plausible_move` is marked UNREACHABLE rather than coloured green.
The colour tells you the payoff; the move tells you whether to believe it.

The study said what "plausible" means for your setup. Winners whose move was
still available after the catalyst went public ran a median 24.5% in the
underlying over about 4 sessions -- but the useful bound is not the median, it
is what you can expect to still be there when you enter in daylight. Roughly
half the move typically remains, so a required move much past ~15% is asking
for the top decile, not the median.

Break-even hit rates, since they are the whole point:

    5x   ->  1 in 5    (20.0%)
    10x  ->  1 in 10   (10.0%)
    25x  ->  1 in 25   ( 4.0%)

Those are the shares of attempts that must reach the tier for the series to
break even, assuming a total loss otherwise -- which for these strikes is the
normal outcome, not the bad case.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from enum import Enum
from typing import Sequence


class Tier(str, Enum):
    RED = "red"        # 5x
    YELLOW = "yellow"  # 10x
    GREEN = "green"    # 25x


TIER_MULTIPLE: dict[Tier, float] = {
    Tier.RED: 5.0,
    Tier.YELLOW: 10.0,
    Tier.GREEN: 25.0,
}

# Beyond this required continuation, a tier is flagged unreachable rather than
# shown as an opportunity. Derived from the study: about half a catalyst move is
# typically still available once it is public, and the median total was ~24.5%.
DEFAULT_MAX_MOVE = 0.15


def break_even_rate(multiple: float) -> float:
    """Share of attempts that must reach `multiple` to break even.

    Turning $1,000 into $5,000 is a 5x on the money -- $4,000 of profit on
    $1,000 risked -- so break-even is 1/5, not 1/6. The one-in-six figure is for
    a trade that returns the stake PLUS five times it.
    """
    return 1.0 / multiple if multiple > 0 else 1.0


@dataclass
class TierRung:
    tier: Tier
    multiple: float
    strike: float
    right: str
    expiry: str
    ask: float
    bid: float
    open_interest: int
    dte: int
    required_move_pct: float     # continuation needed, from current spot
    target_price: float          # what the contract must be worth
    contracts: int
    cost: float
    payout: float
    reachable: bool
    note: str = ""

    @property
    def break_even(self) -> float:
        return break_even_rate(self.multiple)

    @property
    def spread_frac(self) -> float:
        mid = (self.bid + self.ask) / 2
        return (self.ask - self.bid) / mid if mid > 0 else float("inf")

    def label(self) -> str:
        state = "" if self.reachable else "  UNREACHABLE"
        return (
            f"{self.tier.value.upper():<7}{self.multiple:>4.0f}x  "
            f"{self.strike:g}{self.right} {self.expiry} ({self.dte}d)  "
            f"ask {self.ask:.2f}  needs {self.required_move_pct * 100:+.1f}%  "
            f"{self.contracts}ct = ${self.cost:,.0f} -> ${self.payout:,.0f}{state}"
        )


def _dte_of(q, today: date | None = None) -> int:
    """Days to expiry, from the quote's own field or derived from its expiry.

    ORATS carries `dte`; the Schwab-shaped OptionQuote does not. Deriving it
    rather than defaulting to zero keeps one adapter from silently filtering
    every strike out of the ladder.
    """
    v = getattr(q, "dte", None)
    if v:
        return int(v)
    exp = str(getattr(q, "expiry", "") or "")[:10]
    if not exp:
        return 0
    try:
        d = datetime.strptime(exp, "%Y-%m-%d").date()
    except ValueError:
        return 0
    return max((d - (today or date.today())).days, 0)


def tier_ladder(
    chain: Sequence,
    *,
    spot: float,
    side: str,
    budget: float = 1000.0,
    min_dte: int = 5,
    max_dte: int = 14,
    min_open_interest: int = 100,
    max_spread_frac: float = 0.25,
    max_plausible_move: float = DEFAULT_MAX_MOVE,
) -> list[TierRung]:
    """For each tier, the cheapest strike that delivers it -- and its cost in move.

    Expiry window defaults to 5-14 days. The study was explicit about this: the
    winners whose move was still available AFTER the catalyst sat at a median 8
    DTE and took 4 sessions to peak, while the 3-DTE median in the headline came
    from pre-catalyst entries nobody can trade. Entering in daylight needs the
    extra week.

    Intrinsic value at expiry is used for the target, which is the pessimistic
    read -- selling earlier into remaining extrinsic beats it. Assuming otherwise
    is how a ladder flatters itself.
    """
    live = []
    for q in chain:
        if getattr(q, "right", None) != side:
            continue
        ask = float(getattr(q, "ask", 0) or 0)
        bid = float(getattr(q, "bid", 0) or 0)
        strike = float(getattr(q, "strike", 0) or 0)
        oi = int(getattr(q, "open_interest", 0) or 0)
        dte = _dte_of(q)
        if ask <= 0 or strike <= 0 or bid <= 0:
            continue
        if not (min_dte <= dte <= max_dte):
            continue
        if oi < min_open_interest:
            continue
        mid = (bid + ask) / 2
        if mid <= 0 or (ask - bid) / mid > max_spread_frac:
            continue
        live.append(q)

    out: list[TierRung] = []
    for tier, mult in TIER_MULTIPLE.items():
        best: TierRung | None = None
        for q in live:
            ask = float(q.ask)
            strike = float(q.strike)
            target = ask * mult
            needed = strike + target if side == "C" else strike - target
            if needed <= 0:
                continue
            move = needed / spot - 1.0
            contracts = int(budget // (ask * 100))
            if contracts < 1:
                continue
            cost = contracts * ask * 100
            rung = TierRung(
                tier=tier, multiple=mult, strike=strike, right=side,
                expiry=str(getattr(q, "expiry", "")), ask=ask, bid=float(q.bid),
                open_interest=int(getattr(q, "open_interest", 0) or 0),
                dte=_dte_of(q),
                required_move_pct=move, target_price=target,
                contracts=contracts, cost=cost, payout=contracts * target * 100,
                reachable=abs(move) <= max_plausible_move,
            )
            # Cheapest required continuation wins the tier.
            if best is None or abs(rung.required_move_pct) < abs(best.required_move_pct):
                best = rung
        if best:
            if not best.reachable:
                best.note = (
                    f"needs {abs(best.required_move_pct) * 100:.0f}% more — past what "
                    f"a public catalyst usually leaves on the table"
                )
            out.append(best)

    return out


def best_reachable(rungs: Sequence[TierRung]) -> TierRung | None:
    """Highest tier that is actually reachable. Green first, then yellow, then red."""
    order = [Tier.GREEN, Tier.YELLOW, Tier.RED]
    for t in order:
        for r in rungs:
            if r.tier == t and r.reachable:
                return r
    return None
