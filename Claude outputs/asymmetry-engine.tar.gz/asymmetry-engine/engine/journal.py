"""The candidate log.

Every candidate the screen surfaces is written here -- taken, declined, and
sized-to-zero alike -- with the reason attached. This is the difference between
a track record and a highlight reel.

The reason it logs DECLINED candidates too: without them you cannot tell whether
the engine is selective or merely lucky, and six months from now the only
question worth asking is "what did it pass on, and was it right to?" A log of
winners answers nothing.

Marks are written at close and again at expiry, so a position that showed +300%
intraday and expired worthless reads as what it was.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterator

SCHEMA = """
CREATE TABLE IF NOT EXISTS candidates (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    run_date            TEXT NOT NULL,
    created_at          TEXT NOT NULL,
    underlying          TEXT NOT NULL,
    catalyst_kind       TEXT NOT NULL,
    catalyst_date       TEXT,
    expiry              TEXT,
    structure_kind      TEXT,
    verdict             TEXT NOT NULL,       -- taken | declined | sized_to_zero
    reason              TEXT NOT NULL,
    spot_at_signal      REAL,
    implied_move_pct    REAL,
    implied_method      TEXT,
    hist_mean_abs_pct   REAL,
    hist_n              INTEGER,
    ev_multiple         REAL,
    ev_multiple_net     REAL,
    exceed_rate         REAL,
    rvol                REAL,
    contracts           INTEGER DEFAULT 0,
    debit               REAL DEFAULT 0,
    legs_json           TEXT,
    binding_constraint  TEXT,
    mode                TEXT NOT NULL        -- paper | live
);

CREATE TABLE IF NOT EXISTS marks (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id  INTEGER NOT NULL REFERENCES candidates(id),
    marked_at     TEXT NOT NULL,
    kind          TEXT NOT NULL,             -- close | expiry | intraday
    underlying_px REAL,
    position_value REAL,
    pnl           REAL,
    pnl_pct       REAL,
    note          TEXT
);

CREATE INDEX IF NOT EXISTS idx_candidates_run  ON candidates(run_date);
CREATE INDEX IF NOT EXISTS idx_candidates_sym  ON candidates(underlying);
CREATE INDEX IF NOT EXISTS idx_marks_candidate ON marks(candidate_id);
"""


@dataclass
class CandidateRecord:
    run_date: str
    underlying: str
    catalyst_kind: str
    verdict: str
    reason: str
    mode: str = "paper"
    catalyst_date: str | None = None
    expiry: str | None = None
    structure_kind: str | None = None
    spot_at_signal: float | None = None
    implied_move_pct: float | None = None
    implied_method: str | None = None
    hist_mean_abs_pct: float | None = None
    hist_n: int | None = None
    ev_multiple: float | None = None
    ev_multiple_net: float | None = None
    exceed_rate: float | None = None
    rvol: float | None = None
    contracts: int = 0
    debit: float = 0.0
    legs: list[dict[str, Any]] = field(default_factory=list)
    binding_constraint: str | None = None


class Journal:
    def __init__(self, db_path: str | Path):
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def record(self, rec: CandidateRecord) -> int:
        d = asdict(rec)
        legs = d.pop("legs")
        d["legs_json"] = json.dumps(legs)
        d["created_at"] = datetime.now().isoformat(timespec="seconds")
        cols = ", ".join(d)
        marks = ", ".join(":" + k for k in d)
        with self._conn() as c:
            cur = c.execute(f"INSERT INTO candidates ({cols}) VALUES ({marks})", d)
            return int(cur.lastrowid)

    def mark(
        self,
        candidate_id: int,
        *,
        kind: str,
        underlying_px: float | None = None,
        position_value: float | None = None,
        pnl: float | None = None,
        pnl_pct: float | None = None,
        note: str = "",
    ) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT INTO marks (candidate_id, marked_at, kind, underlying_px,"
                " position_value, pnl, pnl_pct, note)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    candidate_id,
                    datetime.now().isoformat(timespec="seconds"),
                    kind,
                    underlying_px,
                    position_value,
                    pnl,
                    pnl_pct,
                    note,
                ),
            )

    def open_positions(self, mode: str = "paper") -> list[sqlite3.Row]:
        """Taken candidates with no expiry mark yet."""
        with self._conn() as c:
            return list(
                c.execute(
                    "SELECT c.* FROM candidates c WHERE c.verdict = 'taken'"
                    " AND c.mode = ? AND NOT EXISTS ("
                    "   SELECT 1 FROM marks m WHERE m.candidate_id = c.id"
                    "   AND m.kind = 'expiry')",
                    (mode,),
                )
            )

    def debit_used_on(self, run_date: str, mode: str = "paper") -> float:
        with self._conn() as c:
            row = c.execute(
                "SELECT COALESCE(SUM(debit), 0) AS d FROM candidates"
                " WHERE run_date = ? AND verdict = 'taken' AND mode = ?",
                (run_date, mode),
            ).fetchone()
            return float(row["d"])

    def positions_in(self, underlying: str, mode: str = "paper") -> int:
        return sum(1 for r in self.open_positions(mode) if r["underlying"] == underlying)

    def track_record(self, mode: str = "paper") -> dict[str, Any]:
        """Honest summary. Counts declines. Reports the denominator.

        `avg_pnl` is per closed position in dollars, and `hit_rate` is the share
        that finished green. Neither is meaningful below ~30 closed positions,
        so `sufficient` says whether to believe any of it yet.
        """
        with self._conn() as c:
            surfaced = c.execute(
                "SELECT verdict, COUNT(*) n FROM candidates WHERE mode = ?"
                " GROUP BY verdict",
                (mode,),
            ).fetchall()
            closed = c.execute(
                "SELECT m.pnl, m.pnl_pct FROM marks m JOIN candidates c"
                " ON c.id = m.candidate_id WHERE m.kind = 'expiry' AND c.mode = ?",
                (mode,),
            ).fetchall()

        by_verdict = {r["verdict"]: r["n"] for r in surfaced}
        pnls = [r["pnl"] for r in closed if r["pnl"] is not None]
        n = len(pnls)
        return {
            "mode": mode,
            "surfaced": sum(by_verdict.values()),
            "by_verdict": by_verdict,
            "closed": n,
            "hit_rate": (sum(1 for p in pnls if p > 0) / n) if n else None,
            "total_pnl": sum(pnls) if n else 0.0,
            "avg_pnl": (sum(pnls) / n) if n else None,
            "sufficient": n >= 30,
            "caveat": (
                "Fewer than 30 closed positions. Nothing here means anything yet."
                if n < 30
                else f"{n} closed positions."
            ),
        }
