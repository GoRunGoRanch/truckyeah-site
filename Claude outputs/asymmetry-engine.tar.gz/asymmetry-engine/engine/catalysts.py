"""What counts as a catalyst, and who else it moves.

Two kinds, because the two motivating trades were two kinds:

  own_earnings   -- the name reports. CRM.
  peer_earnings  -- somebody else reports and this name moves in sympathy. MU
                    the morning after NVDA, which is not MU's event at all.

The peer relationship is the part people skip, and it is where the second trade
lived. When NVDA prints, the entire memory and semicap complex reprices
overnight, and the options chains on those names frequently do NOT mark up
enough beforehand, because the event is not on their calendar. That is a
structural reason for a mispricing to exist, which is a better foundation than
a pattern that merely showed up in a backtest.

Direction is deliberately absent from this module. A peer catalyst does not
imply sympathy in the same direction -- MU fell on a good NVDA print, which is
exactly the sell-the-news case that would break any rule assuming correlation
sign. The engine buys the move; it does not predict which way.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Iterable

# Bellwethers whose reports reprice a whole complex overnight. Edit freely --
# these are starting points, not truths. Add a name here and its peers get
# screened the next morning on the peer_earnings conditioning set.
DEFAULT_PEER_MAP: dict[str, list[str]] = {
    "NVDA": ["MU", "AMD", "AVGO", "MRVL", "TSM", "SMCI", "ARM", "WDC", "STX"],
    "TSM":  ["NVDA", "AMD", "AVGO", "MU", "ASML", "AMAT", "LRCX", "KLAC"],
    "MU":   ["WDC", "STX", "SNDK", "SIMO"],
    "AAPL": ["QCOM", "SWKS", "QRVO", "CRUS", "SKX"],
    "MSFT": ["ORCL", "NOW", "CRM", "SNOW", "MDB", "DDOG"],
    "CRM":  ["NOW", "WDAY", "HUBS", "MNDY", "TEAM"],
    "JPM":  ["BAC", "C", "WFC", "GS", "MS"],
    "COST": ["WMT", "TGT", "BJ", "KR"],
    "LLY":  ["NVO", "VKTX", "AMGN"],
    "AMD":  ["NVDA", "INTC", "AVGO", "MRVL"],
}


@dataclass(frozen=True)
class Catalyst:
    """One event, for one symbol, on one session."""

    symbol: str
    kind: str              # "own_earnings" | "peer_earnings:NVDA" | "macro:CPI"
    event_date: date       # the session the move is expected in
    source_symbol: str | None = None   # who actually reported, for peer events
    timing: str = "unknown"            # "bmo" | "amc" | "unknown"
    note: str = ""

    @property
    def is_peer(self) -> bool:
        return self.kind.startswith("peer_earnings")

    def label(self) -> str:
        if self.is_peer:
            return f"{self.symbol} sympathy to {self.source_symbol} earnings"
        if self.kind == "own_earnings":
            return f"{self.symbol} earnings ({self.timing})"
        return f"{self.symbol} {self.kind}"


@dataclass
class CatalystCalendar:
    """Builds the morning's catalyst set from an earnings calendar."""

    peer_map: dict[str, list[str]] = field(
        default_factory=lambda: dict(DEFAULT_PEER_MAP)
    )
    universe: set[str] = field(default_factory=set)

    def for_session(
        self,
        session: date,
        earnings: Iterable[tuple[str, date, str]],
    ) -> list[Catalyst]:
        """Catalysts in play for `session`.

        `earnings` is (symbol, report_date, timing) with timing in
        {"bmo", "amc", "unknown"}.

        A name that reports after the close on day D moves on session D+1; one
        that reports before the open on D moves on D. Getting this backwards is
        how you screen the day after the move, which is a quiet and expensive
        bug -- hence the explicit timing handling rather than a fixed offset.
        """
        out: list[Catalyst] = []
        seen: set[tuple[str, str]] = set()

        for sym, rpt, timing in earnings:
            move_session = rpt if timing == "bmo" else rpt + timedelta(days=1)
            if move_session != session:
                continue

            if not self.universe or sym in self.universe:
                key = (sym, "own_earnings")
                if key not in seen:
                    seen.add(key)
                    out.append(
                        Catalyst(
                            symbol=sym,
                            kind="own_earnings",
                            event_date=session,
                            timing=timing,
                        )
                    )

            for peer in self.peer_map.get(sym, []):
                if self.universe and peer not in self.universe:
                    continue
                kind = f"peer_earnings:{sym}"
                key = (peer, kind)
                if key in seen:
                    continue
                # A name reporting on its own account is not a sympathy trade.
                if any(c.symbol == peer and c.kind == "own_earnings" for c in out):
                    continue
                seen.add(key)
                out.append(
                    Catalyst(
                        symbol=peer,
                        kind=kind,
                        event_date=session,
                        source_symbol=sym,
                        timing=timing,
                        note=(
                            f"{sym} reports {timing}; {peer}'s own chain may not "
                            f"be marking up for it"
                        ),
                    )
                )

        return out

    def peers_of(self, symbol: str) -> list[str]:
        return list(self.peer_map.get(symbol, []))

    def bellwethers_for(self, symbol: str) -> list[str]:
        """Which bellwethers historically move this name -- the conditioning set."""
        return [b for b, peers in self.peer_map.items() if symbol in peers]
