"""Position sizing and the hard caps.

This module exists because of a specific, documented pattern: size escalation,
stop-out reversal, and early exits from positions that were too big to hold
calmly. An engine that finds good setups and sizes them badly is worse than no
engine, because it launders a discipline problem through a computer and makes it
look like a system.

So the caps here are not advisory. `size_position` returns an integer number of
contracts and it is the only function permitted to decide that number. Nothing
downstream may increase it, and there is no override parameter -- if a cap needs
to change it changes in config.yaml, in daylight, before the session, not in the
moment when a setup looks too good to pass up. That timing is the entire point.

Kelly is included because it is the honest answer to "how much," and it is
deliberately capped at one quarter. Full Kelly on a 12-sample edge estimate is a
way to go broke while being technically correct about expectancy.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class RiskLimits:
    # The committed 5-contract maximum. Not a suggestion.
    max_contracts: int = 5
    # Most you may spend on a single ticket, in dollars.
    max_debit_per_trade: float = 500.0
    # Most you may spend across every new position opened in one session.
    max_daily_debit: float = 1500.0
    # Concurrent open positions, and per-name concentration.
    max_open_positions: int = 4
    max_positions_per_underlying: int = 1
    # Fraction of account equity at risk in any one ticket.
    max_equity_frac_per_trade: float = 0.02
    # Kelly is scaled by this before anything else looks at it.
    kelly_fraction: float = 0.25
    # Touch this file and the engine opens nothing until it is removed.
    kill_switch_path: str = "state/KILL"

    def kill_switch_engaged(self, root: Path) -> bool:
        return (root / self.kill_switch_path).exists()


@dataclass
class SizingDecision:
    contracts: int
    debit: float
    binding_constraint: str
    kelly_contracts: float
    notes: list[str]

    @property
    def is_pass(self) -> bool:
        return self.contracts == 0


def kelly_contracts(
    payoffs: np.ndarray,
    debit_per_contract: float,
    account_equity: float,
    *,
    fraction: float = 0.25,
) -> float:
    """Fractional-Kelly contract count from the historical payoff distribution.

    Uses the empirical distribution directly rather than a win/loss
    approximation, because these payoffs are wildly asymmetric and the two-
    outcome Kelly formula misprices them badly.

    Returns a float; the caller rounds down. Zero or negative expectancy returns
    zero, which is the correct bet size for a trade with no edge.
    """
    if debit_per_contract <= 0 or account_equity <= 0 or payoffs.size == 0:
        return 0.0

    # Per-contract return on the debit for each historical outcome.
    r = payoffs / debit_per_contract
    if r.mean() <= 0:
        return 0.0

    # Maximise E[log(1 + f*r)] over f in (0, 1]. Coarse grid is plenty given the
    # estimation error already baked into r.
    fs = np.linspace(0.001, 1.0, 400)
    with np.errstate(divide="ignore", invalid="ignore"):
        growth = np.array(
            [np.mean(np.log1p(f * r)) if np.all(1 + f * r > 0) else -np.inf for f in fs]
        )
    if not np.isfinite(growth).any():
        return 0.0
    f_star = float(fs[int(np.nanargmax(growth))]) * fraction
    return (f_star * account_equity) / debit_per_contract


def size_position(
    *,
    debit_per_contract: float,
    payoffs_per_contract: np.ndarray,
    account_equity: float,
    limits: RiskLimits,
    open_positions: int = 0,
    positions_in_underlying: int = 0,
    debit_used_today: float = 0.0,
) -> SizingDecision:
    """The single authority on how many contracts. Returns 0 freely."""
    notes: list[str] = []
    k = kelly_contracts(
        payoffs_per_contract,
        debit_per_contract,
        account_equity,
        fraction=limits.kelly_fraction,
    )

    if debit_per_contract <= 0:
        return SizingDecision(0, 0.0, "invalid debit", k, ["debit must be positive"])

    if open_positions >= limits.max_open_positions:
        return SizingDecision(
            0, 0.0, "max_open_positions", k,
            [f"already holding {open_positions} positions (cap {limits.max_open_positions})"],
        )

    if positions_in_underlying >= limits.max_positions_per_underlying:
        return SizingDecision(
            0, 0.0, "max_positions_per_underlying", k,
            ["already have a position in this name; doubling up is the escalation pattern"],
        )

    candidates: dict[str, float] = {
        "kelly": math.floor(k),
        "max_contracts": float(limits.max_contracts),
        "max_debit_per_trade": math.floor(limits.max_debit_per_trade / debit_per_contract),
        "max_equity_frac_per_trade": math.floor(
            (limits.max_equity_frac_per_trade * account_equity) / debit_per_contract
        ),
        "max_daily_debit": math.floor(
            max(limits.max_daily_debit - debit_used_today, 0.0) / debit_per_contract
        ),
    }

    binding = min(candidates, key=lambda key: candidates[key])
    contracts = int(max(0, min(candidates.values())))

    if contracts == 0:
        notes.append(f"sized to zero by {binding}")
        if binding == "kelly":
            notes.append(
                "quarter-Kelly says this edge is too thin to bet at this price"
            )
    else:
        notes.append(
            f"{contracts} contract(s); binding constraint was {binding} "
            f"(kelly suggested {k:.2f})"
        )
        if k > limits.max_contracts:
            notes.append(
                f"kelly wanted {k:.1f} but the {limits.max_contracts}-contract cap "
                f"holds -- the cap wins, every time, that is what it is for"
            )

    return SizingDecision(contracts, contracts * debit_per_contract, binding, k, notes)
