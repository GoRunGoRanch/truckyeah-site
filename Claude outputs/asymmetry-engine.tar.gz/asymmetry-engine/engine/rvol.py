"""Relative volume: is anything actually happening right now?

The edge test is about how the chain is PRICED. This is about whether the tape
agrees something is going on. A catalyst on the calendar with dead pre-market
volume is a catalyst nobody cares about, and the mispricing it appears to offer
is usually a stale or wide quote rather than an opportunity.

RVOL must be measured time-of-day against time-of-day. Comparing 9:35am volume
to a full-day average makes every morning look quiet and every afternoon look
explosive; it is the most common way this indicator gets built wrong.

The thinkScript scans (TrendDayScanner, Volume-Climax Reversal) live server-side
in TOS and were not on disk, so the thresholds here are defaults rather than a
port of those. Paste the thinkScript and the constants get replaced with yours.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import time
from typing import Mapping, Sequence

import numpy as np

# Regular session, US equities, Eastern.
SESSION_OPEN = time(9, 30)
SESSION_CLOSE = time(16, 0)


@dataclass(frozen=True)
class RvolReading:
    symbol: str
    rvol: float
    window: str              # "premarket" | "opening_range" | "cumulative"
    observed: float
    baseline: float
    sample_days: int

    @property
    def is_meaningful(self) -> bool:
        """Ten days of baseline is the floor for the ratio to mean anything."""
        return self.sample_days >= 10 and self.baseline > 0

    def describe(self) -> str:
        return (
            f"{self.symbol} {self.window} RVOL {self.rvol:.1f}x "
            f"({self.observed:,.0f} vs {self.baseline:,.0f} baseline, "
            f"n={self.sample_days}d)"
        )


def premarket_rvol(
    symbol: str,
    today_premarket_volume: float,
    historical_premarket_volumes: Sequence[float],
) -> RvolReading:
    """Pre-market volume against the same name's typical pre-market volume.

    Median, not mean: one prior earnings morning in the lookback would otherwise
    triple the baseline and hide today's move entirely.
    """
    hist = np.asarray([v for v in historical_premarket_volumes if v > 0], dtype=float)
    baseline = float(np.median(hist)) if hist.size else 0.0
    rvol = (today_premarket_volume / baseline) if baseline > 0 else float("nan")
    return RvolReading(
        symbol=symbol,
        rvol=rvol,
        window="premarket",
        observed=float(today_premarket_volume),
        baseline=baseline,
        sample_days=int(hist.size),
    )


def intraday_rvol(
    symbol: str,
    today_cumulative_by_minute: Mapping[int, float],
    historical_cumulative_by_minute: Sequence[Mapping[int, float]],
    at_minute: int,
) -> RvolReading:
    """Cumulative volume at N minutes past the open vs the same point historically.

    `at_minute` is minutes since 9:30. Passing 15 gives you the opening-range
    reading, which is the one that matters for a gap.
    """
    observed = float(today_cumulative_by_minute.get(at_minute, 0.0))
    hist = np.asarray(
        [float(d[at_minute]) for d in historical_cumulative_by_minute
         if at_minute in d and d[at_minute] > 0],
        dtype=float,
    )
    baseline = float(np.median(hist)) if hist.size else 0.0
    rvol = (observed / baseline) if baseline > 0 else float("nan")
    return RvolReading(
        symbol=symbol,
        rvol=rvol,
        window="opening_range" if at_minute <= 30 else "cumulative",
        observed=observed,
        baseline=baseline,
        sample_days=int(hist.size),
    )


def passes_gate(reading: RvolReading, *, min_rvol: float = 2.0) -> tuple[bool, str]:
    """The gate. Declines on insufficient baseline rather than guessing."""
    if not reading.is_meaningful:
        return False, (
            f"declined: RVOL baseline unusable "
            f"({reading.sample_days} days of history) -- no reading, no trade"
        )
    if np.isnan(reading.rvol):
        return False, "declined: RVOL could not be computed"
    if reading.rvol < min_rvol:
        return False, (
            f"declined: {reading.window} RVOL {reading.rvol:.1f}x below the "
            f"{min_rvol:.1f}x gate -- the tape does not care about this catalyst"
        )
    return True, f"passed: {reading.describe()}"
