# Build spec — Asymmetry, as a web app

**Hand this whole file to a fresh Claude Code session, in an empty folder, with
the `asymmetry-engine` folder available.** It is written to be the entire brief.

---

## What you are building

A private web tool for one trader. Three times each weekday it scans ~500 US
large caps for catalyst-driven moves, prices the option chain on each mover, and
publishes a colour-coded list of reward tiers. He opens a bookmark and reads it.
He uploads a list of upcoming catalysts once a week. That is the whole product.

He is a physician, not an engineer. He currently runs this from a terminal and
it is the reason he doesn't run it daily. **Every design decision should be made
in favour of "he never opens a terminal again."**

---

## The architecture, and why not the obvious one

The obvious build is "put the Python on Vercel." Don't. Two hard constraints:

**Vercel Hobby crons run once per day, with ±59 minutes of scheduling slop.** A
scan meant for 7:00am could fire at 7:58 — after the market opens, when the
information is stale. Three passes a day needs Vercel Pro ($20/mo).

**The scan makes ~508 sequential HTTP calls.** That does not fit in a Hobby
function's 10-second ceiling, and is uncomfortable even in Pro's 60s.

So split it:

```
GitHub Actions          runs the existing Python scan on a cron, 3x weekday.
   (free, no timeout)   Writes results to Supabase. No rewrite needed.
        |
        v
    Supabase            Postgres. Scans, tiers, catalysts, run log.
        |
        v
     Vercel             Next.js. Reads Supabase, renders the dashboard,
   (free Hobby)         accepts catalyst uploads, has a "Run now" button.
```

GitHub Actions gives real cron with minute precision, no function timeout, free
minutes, and it runs the Python **unchanged**. Vercel does what Vercel is good
at: serving a fast page. Nobody pays $20/mo for a scheduler.

**Caveat to handle:** GitHub disables scheduled workflows on repos with ~60 days
of no activity. The nightly job should touch a file or the workflow should be
re-enabled on push; note this in the README so it doesn't die silently in
January.

---

## Piece 1 — The scanner (mostly done)

`asymmetry-engine/` is a working, tested Python package. **Do not rewrite its
logic.** It has 31 passing tests and the numbers in it came from a real study of
57 historical winners. Specifically leave alone:

- `engine/tiers.py` — the 5x/10x/25x ladder and the `required_move_pct` that
  makes the colours mean something
- `engine/gappers.py` — catalyst screen, direction taken from the move
- `engine/risk.py` — position sizing and the hard caps
- `engine/data/orats*.py` — the ORATS client, its caching, its auth handling

**What to change:** `scripts/scan_live.py` currently writes an HTML file. Add a
`--json` flag that emits the same data as JSON on stdout, and a small
`scripts/push_to_supabase.py` that reads that JSON and upserts it. Keep the HTML
output working — it is the fallback when the web app is down.

### The GitHub Action

`.github/workflows/scan.yml`, three cron entries (times are UTC; the user is
America/Denver so account for DST or use a fixed UTC schedule and say so):

| Local (MT) | Purpose |
|---|---|
| 07:00 | pre-open — overnight gaps |
| 10:30 | midday — intraday thrusts |
| 14:30 | post-close — after-hours reporters |

Steps: checkout, setup-python 3.12, pip install -r requirements.txt, run
`scan_live.py --json`, pipe to `push_to_supabase.py`. Secrets:
`ORATS_TOKEN`, `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`.

Also add `workflow_dispatch:` so the web app's "Run now" button can trigger it
via the GitHub API.

---

## Piece 2 — Supabase schema

```sql
-- every scan pass
create table runs (
  id            bigserial primary key,
  ran_at        timestamptz not null default now(),
  session       text not null,           -- morning | midday | evening
  names_scanned int  not null,
  names_through int  not null,
  ok            boolean not null default true,
  error         text
);

-- one row per name that cleared the screen
create table movers (
  id          bigserial primary key,
  run_id      bigint references runs(id) on delete cascade,
  symbol      text not null,
  move_pct    numeric not null,
  rvol        numeric,
  price       numeric,
  side        text not null,             -- C | P
  iv_rank     numeric,
  px_chg_1y   numeric,
  sector      text,
  catalyst_age text,
  created_at  timestamptz default now()
);

-- three per mover
create table tiers (
  id             bigserial primary key,
  mover_id       bigint references movers(id) on delete cascade,
  tier           text not null,          -- red | yellow | green
  multiple       numeric not null,       -- 5 | 10 | 25
  strike         numeric,
  expiry         date,
  dte            int,
  ask            numeric,
  bid            numeric,
  open_interest  int,
  required_move  numeric not null,       -- THE column that matters
  contracts      int,
  cost           numeric,
  payout         numeric,
  reachable      boolean not null
);

-- what he uploads weekly
create table catalysts (
  id         bigserial primary key,
  symbol     text not null,
  event_date date not null,
  kind       text,                       -- earnings | fda | product | analyst | macro | other
  note       text,
  source     text,                       -- 'upload' | 'orats'
  created_at timestamptz default now(),
  unique (symbol, event_date, kind)
);

-- his own trade log, so the hit rate eventually gets measured
create table trades (
  id           bigserial primary key,
  mover_id     bigint references movers(id),
  symbol       text not null,
  opened_at    timestamptz not null,
  closed_at    timestamptz,
  side         text, strike numeric, expiry date,
  contracts    int, entry_price numeric, exit_price numeric,
  pnl          numeric,
  tier_taken   text,
  notes        text
);
```

Row-level security: this is a single-user tool. Lock every table to the owner's
auth uid, or put the whole app behind Supabase Auth with one account. **Do not
ship it publicly readable** — it is his positions.

---

## Piece 3 — The Next.js app on Vercel

App Router, TypeScript, Tailwind. Server components reading Supabase directly;
no client-side service key, ever.

### `/` — today's scan

The main surface. For each mover, a card:

- Header: ticker, % move (green up / red down), price, RVOL chip, IV-rank chip,
  a "beaten down" chip when `px_chg_1y <= -20`, and CALLS or PUTS taken from the
  move direction
- Three tier tiles: **green 25x, yellow 10x, red 5x**

**The single most important UI rule:** each tile leads with `required_move` —
"needs +8.7%" — in the largest type in the tile, larger than the multiple. A
tier whose `reachable` is false renders grey and struck-through, not green.
Colour is payoff; the required move is whether to believe it. Getting this
backwards makes the tool actively harmful.

Each tile also shows: contract (strike/expiry/DTE), ask → target price,
contracts affordable at his budget, cost → payout, open interest, and the
break-even hit rate ("1 in 25").

Budget is a control at the top of the page, default $1,000, persisted.

Empty state matters and should not look like an error: *"Nothing cleared the
screen. In the 100-day study, 92.5% of names produced nothing — this is the
normal result."*

### `/catalysts` — the weekly upload

- Paste a block of text or drop a CSV: `SYMBOL, DATE, KIND, NOTE`
- Also accept a freeform paste (a list of tickers and dates from an earnings
  calendar) and parse it leniently — he will paste messy things
- Table of upcoming catalysts, editable, deletable
- These feed the next scan: a name with a catalyst in the next 3 sessions gets
  flagged on its card even if it hasn't moved yet

### `/history` — the record

Every past run, every mover surfaced, whether he took it. This is where the hit
rate eventually comes from, and it is the only part that can ever tell him
whether the tool works. **Do not skip it because it is unglamorous.**

Show: total surfaced, taken, closed, hit rate against the tier's break-even bar,
and a plain sentence when the sample is too small to mean anything (under ~30
closed positions).

### `/trades` — logging

Quick form to log a trade from a mover card ("I took this"), and to close it.
Minimal fields. The whole point is that logging takes ten seconds or he won't do
it.

### "Run now" button

Header button that POSTs to a route which triggers the GitHub Action via
`workflow_dispatch`. Show a spinner and poll `runs` for a new row. He will use
this constantly; make it feel instant even though the scan takes minutes.

---

## Secrets

| Where | Name | Notes |
|---|---|---|
| GitHub Actions | `ORATS_TOKEN` | never in the repo |
| GitHub Actions | `SUPABASE_URL`, `SUPABASE_SERVICE_KEY` | service key, server only |
| Vercel | `SUPABASE_URL`, `SUPABASE_ANON_KEY` | anon key for the app |
| Vercel | `GITHUB_TOKEN`, `GITHUB_REPO` | fine-grained PAT, actions:write only |

`.env.example` in the repo, `.env` gitignored. The ORATS token has appeared in a
chat log once already — tell him to rotate it before deploying.

---

## Facts from the study that must survive into the app

These are not preferences. They came from a sweep of 512 tickers over 100
sessions and they are why the defaults are what they are.

- **Expiry window 5–14 days, default 8.** Winners whose move was still available
  after the catalyst went public sat at a median 8 DTE. The 3-day median in the
  raw summary came from pre-catalyst entries nobody can trade.
- **`max_plausible_move` 15%.** About half a catalyst move typically remains once
  it is public, on a median total of ~24.5%. A tier needing more is asking for
  the top decile.
- **Break-even is 1/multiple.** 5x is 1 in 5 (20%), not 1 in 6. Turning $1,000
  into $5,000 is a 5x on the money.
- **92.5% of names produce nothing in a quarter.** The empty state is the normal
  state and the copy must say so.
- **Hard caps stay hard.** 5 contracts max, $500/trade, $1,500/day, one position
  per underlying. `engine/risk.py` is the only thing that sizes, and it has no
  override parameter. Do not add one to the UI.

---

## What this tool must never become

It shows what moved and what the chain pays. It does not recommend, and no
screen should read like it does. No "BUY" buttons, no confidence scores, no
"strong setup" language. **Nothing in this system has demonstrated an edge** —
the study found the winners, not the denominator. The `/history` page exists
precisely because that question is still open.

No order placement. Not in v1, not behind a flag.

---

## Order of work

1. Supabase project + schema + RLS
2. `--json` flag and `push_to_supabase.py` in the Python
3. GitHub Action, verified by a manual `workflow_dispatch` run
4. Next.js `/` reading real rows
5. `/catalysts` upload
6. `/history` and `/trades`
7. "Run now"

**Ship after step 4.** A dashboard he can read beats a complete app he is
waiting for. Everything after that is additive.

---

## Definition of done

He opens a bookmark on his phone at 7:05am and sees what moved overnight, which
strikes pay 5x / 10x / 25x, and how far each one needs the stock to travel. He
never opens a terminal. Once a week he pastes next week's earnings dates into a
box. When he takes a trade he taps a button and it is logged.
