# Start here

There are two separate things in this folder. They do not depend on each other.
Do the first one. The second can wait.

---

## 1. The scan — works today, nothing to install

`thinkscript/AllSessionMovers.ts`

This is the piece that finds the names. It runs entirely inside thinkorswim on
your normal brokerage login. No Python, no API key, no subscription, no
developer account. Open that file, read the header, paste it into TOS.

**If you only ever do this one thing, you still have the morning list.**

---

## 2. The engine — Python, needs the Schwab API

Everything else here. It does the part TOS can't: given a live option chain, it
tells you which strike actually pays 5:1 and how far the stock has to travel to
get there. It also logs every candidate so you eventually have a real hit rate
instead of three remembered wins.

This one needs setup, and it needs the Schwab developer app approved.

### Setup, one command at a time

Open **Terminal** on the Mac. Run these one at a time and stop if any errors.

```bash
cd ~/asymmetry-engine
```
If that says "no such file or directory", the folder isn't there yet — unzip the
bundle first and use whatever path it landed in.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Open `.env` in any text editor and fill in from your Schwab developer dashboard:

```
SCHWAB_API_KEY=<App Key>
SCHWAB_APP_SECRET=<Secret>
SCHWAB_CALLBACK_URL=https://127.0.0.1:8182
```

The callback must match what you registered on Schwab **exactly**. If you
registered something different, change this line to match Schwab, not the
reverse.

```bash
python scripts/schwab_auth.py
```

A browser opens. **Log in with your BROKERAGE credentials here** — not your
developer account. This is the step that connects the two. Your browser will
warn about the certificate on `127.0.0.1`; that's expected, click through.

```bash
./scripts/check_token.sh
```

Should say how many days are left. Seven, then you re-run `schwab_auth.py`.
Put a recurring reminder in your phone now.

### Then

```bash
python run_morning.py --dry-run
```

Screens and prints, writes nothing. If that works, drop `--dry-run`.

---

## The three accounts, because this confused things once

| | What it is | Login |
|---|---|---|
| **thinkorswim** | where the scan runs | brokerage |
| **developer.schwab.com** | where the app is registered | a separate developer login, on purpose |
| **the app's access to your account** | granted by `schwab_auth.py` | brokerage |

The developer account being different from your brokerage account is correct,
not a mistake. They get connected at the `schwab_auth.py` step and not before.

---

## Honest state of this

The scan works. The engine runs and has 19 passing tests, none of which is a
backtest — it has never been pointed at real market data, and no part of it has
demonstrated an edge. Paper mode is the default and live trading is gated behind
30 closed paper positions.

The number that decides whether any of this is worth doing is the hit rate: at
1:5, roughly **one in six** has to be a 5-bagger to break even. Nothing here
knows that number yet. Logging trades is how you find it out.
