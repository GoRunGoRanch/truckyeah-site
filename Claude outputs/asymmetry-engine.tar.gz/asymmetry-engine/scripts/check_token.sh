#!/usr/bin/env bash
# Prints how much life the Schwab token has left. Safe for cron.
# Schwab expires refresh tokens at 7 days, no exceptions, no workaround.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TOKEN="${SCHWAB_TOKEN_PATH:-$ROOT/state/schwab_token.json}"

if [[ ! -f "$TOKEN" ]]; then
  echo "NO TOKEN at $TOKEN — run: python scripts/schwab_auth.py"; exit 1
fi
AGE_S=$(( $(date +%s) - $(stat -f %m "$TOKEN" 2>/dev/null || stat -c %Y "$TOKEN") ))
AGE_D=$(( AGE_S / 86400 ))
LEFT=$(( 7 - AGE_D ))
if (( LEFT <= 0 )); then
  echo "EXPIRED ($AGE_D days old). Run: python scripts/schwab_auth.py"; exit 1
elif (( LEFT <= 2 )); then
  echo "WARNING: $LEFT day(s) left. Re-auth soon."; exit 0
else
  echo "OK: $LEFT day(s) left."; exit 0
fi
