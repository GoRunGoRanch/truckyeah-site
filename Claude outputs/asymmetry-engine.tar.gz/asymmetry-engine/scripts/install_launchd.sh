#!/usr/bin/env bash
# Schedule the scan three times a day on macOS.
#
# You are in Mountain time; the 9:30 ET open is 7:30 local.
#   07:00 MT (09:00 ET)  pre-open  -- overnight gaps, before the bell
#   10:30 MT (12:30 ET)  midday    -- intraday thrusts that developed
#   14:30 MT (16:30 ET)  post-close-- names that reported after the bell
#
# launchd uses local time and follows DST, so these stay correct in November.
# Override any of them with MORNING_H, MIDDAY_H, EVENING_H.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LABEL="com.truckyeah.asymmetry.scan"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
PYTHON="$ROOT/.venv/bin/python"
[[ -x "$PYTHON" ]] || PYTHON="$(command -v python3)"

MORNING_H="${MORNING_H:-7}";  MORNING_M="${MORNING_M:-0}"
MIDDAY_H="${MIDDAY_H:-10}";   MIDDAY_M="${MIDDAY_M:-30}"
EVENING_H="${EVENING_H:-14}"; EVENING_M="${EVENING_M:-30}"

mkdir -p "$HOME/Library/LaunchAgents" "$ROOT/state/logs"

slots=""
for wd in 1 2 3 4 5; do
  for hm in "$MORNING_H $MORNING_M" "$MIDDAY_H $MIDDAY_M" "$EVENING_H $EVENING_M"; do
    set -- $hm
    slots="$slots
    <dict><key>Weekday</key><integer>$wd</integer><key>Hour</key><integer>$1</integer><key>Minute</key><integer>$2</integer></dict>"
  done
done

cat > "$PLIST" <<PLIST_EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>WorkingDirectory</key><string>$ROOT</string>
  <key>ProgramArguments</key>
  <array>
    <string>$PYTHON</string>
    <string>$ROOT/scripts/scan_live.py</string>
  </array>
  <key>StartCalendarInterval</key>
  <array>$slots
  </array>
  <key>StandardOutPath</key><string>$ROOT/state/logs/scan.out.log</string>
  <key>StandardErrorPath</key><string>$ROOT/state/logs/scan.err.log</string>
  <key>RunAtLoad</key><false/>
</dict></plist>
PLIST_EOF

launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST"
echo "Loaded $LABEL — weekdays at:"
printf "  %02d:%02d  pre-open\n  %02d:%02d  midday\n  %02d:%02d  post-close\n" \
  "$MORNING_H" "$MORNING_M" "$MIDDAY_H" "$MIDDAY_M" "$EVENING_H" "$EVENING_M"
echo
echo "Output:  $ROOT/state/scan.html   (bookmark it)"
echo "Logs:    $ROOT/state/logs/"
echo "Run now: python scripts/scan_live.py --open"
echo "Stop:    launchctl unload $PLIST"
