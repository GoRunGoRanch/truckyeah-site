#!/usr/bin/env python3
"""The evidence run: every qualifying gap, not the memorable ones.

    python scripts/study_gaps.py --universe universe.txt \
        --start 2026-01-02 --end 2026-08-29 --out study.csv

WHAT THIS IS FOR

You cannot build a forward strategy from trades you remember, because you
remember the ones that worked. This script defines the setup in code, sweeps a
date range, and returns EVERY day that met the definition -- the CRMs and the
forty names you have never heard of that gapped 6% and died by noon.

The losers are the entire point. A playbook built on winners tells you what a
winner looks like, which you already know. What you need is what separates them
from the failures that looked identical at 9:31.

HOW IT DECIDES

Entry is mechanical and hindsight-free:

  1. A day qualifies when the gap (open vs prior close) exceeds --min-gap and
     volume exceeds --min-rvol times the name's recent median.
  2. Side is taken FROM the gap. Up-gap buys calls, down-gap buys puts. No
     prediction anywhere.
  3. The strike is the first one at least --otm-pct beyond spot in the gap
     direction, on the nearest expiry at least --min-dte days out.
  4. You pay the ask on the entry day's close and sell the bid on the exit day's
     close. Every day in between is checked so `hit_target` is honest about
     whether 5x was ever available, not just whether it was there at the end.

WHAT IT WILL PROBABLY TELL YOU

That most of these lose. That is not a reason to stop -- it is the denominator
you need. Turning $1,000 into $5,000 is a 5x on the money, so the bar is one in
five -- 20%. The question the output answers is whether your hit rate clears it,
and which conditions push it above.

Requests: one per symbol to find events, then ~(hold+1) per event. A 200-name
universe over 8 months lands in the low thousands. Fine on the Live tier.
"""

from __future__ import annotations

import argparse
import csv
import sys
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from statistics import median

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.config import load_dotenv  # noqa: E402
from engine.data.orats import OratsClient, OratsAuthError, OratsError, _f  # noqa: E402
from engine.gappers import required_hit_rate  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


@dataclass
class Event:
    symbol: str
    entry_date: str
    exit_date: str
    side: str                  # C or P
    prev_close: float
    open_px: float
    gap_pct: float
    rvol: float
    off_high_pct: float        # beaten-down score, recorded not gated
    spot_entry: float
    spot_exit: float
    continuation_pct: float    # underlying move from entry close to exit close
    expiry: str
    strike: float
    entry_ask: float
    exit_bid: float
    best_bid: float            # best mark seen on any day held
    return_pct: float
    peak_return_pct: float
    hit_target: int            # 1 if peak return >= target multiple
    contracts_for_1k: int
    note: str = ""


def _bars(client: OratsClient, symbol: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for b in client.dailies(symbol):
        d = str(b.get("tradeDate") or "")[:10]
        if d:
            out[d] = b
    return out


def find_events(
    client: OratsClient,
    symbol: str,
    *,
    start: str,
    end: str,
    min_gap: float,
    min_rvol: float,
    vol_lookback: int,
    min_price: float,
) -> list[tuple[str, float, float, float, float, float]]:
    """(date, prev_close, open, gap_pct, rvol, off_high_pct) for qualifying days."""
    bars = _bars(client, symbol)
    days = sorted(bars)
    out = []

    for i, d in enumerate(days):
        if d < start or d > end or i < vol_lookback:
            continue
        prev = bars[days[i - 1]]
        cur = bars[d]

        prev_close = _f(prev, "clsPx", "close", "cPrice")
        open_px = _f(cur, "opnPx", "open", "oPrice")
        vol = _f(cur, "stockVolume", "volume", "vol")
        if not prev_close or not open_px or not vol or prev_close <= 0:
            continue
        if open_px < min_price:
            continue

        gap = open_px / prev_close - 1.0
        if abs(gap) < min_gap:
            continue

        # Median, not mean: one prior earnings day would otherwise triple the
        # baseline and hide today entirely.
        hist = [
            _f(bars[x], "stockVolume", "volume", "vol") or 0
            for x in days[i - vol_lookback : i]
        ]
        hist = [v for v in hist if v > 0]
        if len(hist) < vol_lookback // 2:
            continue
        base = median(hist)
        rvol = vol / base if base > 0 else 0
        if rvol < min_rvol:
            continue

        window = days[max(0, i - 252) : i + 1]
        highs = [_f(bars[x], "hiPx", "high", "hPrice") or 0 for x in window]
        hi = max(highs) if highs else 0
        off_high = max(0.0, 1.0 - open_px / hi) if hi > 0 else 0.0

        out.append((d, prev_close, open_px, gap, rvol, off_high))

    return out


def price_event(
    client: OratsClient,
    symbol: str,
    day: str,
    *,
    side: str,
    otm_pct: float,
    min_dte: int,
) -> tuple[dict, float, float, str] | None:
    """Pick the strike and its entry ask on `day`. Returns (row, strike, ask, expiry)."""
    try:
        chain = client.hist_strikes(symbol, day)
    except OratsError:
        return None
    if not chain:
        return None

    spot = _f(chain[0], "stockPrice", "spotPrice", "stkPx")
    if not spot:
        return None

    d0 = datetime.strptime(day, "%Y-%m-%d").date()
    expiries = sorted({str(r.get("expirDate"))[:10] for r in chain if r.get("expirDate")})
    expiry = next(
        (
            e
            for e in expiries
            if (datetime.strptime(e, "%Y-%m-%d").date() - d0).days >= min_dte
        ),
        None,
    )
    if not expiry:
        return None

    target = spot * (1 + otm_pct) if side == "C" else spot * (1 - otm_pct)
    rows = [r for r in chain if str(r.get("expirDate"))[:10] == expiry]
    cands = [
        r
        for r in rows
        if (_f(r, "strike") or 0) >= target if side == "C"
    ] if side == "C" else [
        r for r in rows if (_f(r, "strike") or 1e9) <= target
    ]
    if not cands:
        return None

    row = min(cands, key=lambda r: abs((_f(r, "strike") or 0) - target))
    ask = _f(row, "callAskPrice", "callAsk") if side == "C" else _f(row, "putAskPrice", "putAsk")
    strike = _f(row, "strike")
    if not ask or ask <= 0 or not strike:
        return None
    return row, strike, ask, expiry


def mark_on(
    client: OratsClient, symbol: str, day: str, expiry: str, strike: float, side: str
) -> float | None:
    """Bid for that exact contract on `day`."""
    try:
        chain = client.hist_strikes(symbol, day)
    except OratsError:
        return None
    for r in chain:
        if str(r.get("expirDate"))[:10] != expiry:
            continue
        if abs((_f(r, "strike") or -1) - strike) > 1e-6:
            continue
        return _f(r, "callBidPrice", "callBid") if side == "C" else _f(r, "putBidPrice", "putBid")
    return None


def run(client: OratsClient, symbols: list[str], args) -> list[Event]:
    events: list[Event] = []

    for n, sym in enumerate(symbols, 1):
        try:
            qualifying = find_events(
                client, sym,
                start=args.start, end=args.end,
                min_gap=args.min_gap, min_rvol=args.min_rvol,
                vol_lookback=args.vol_lookback, min_price=args.min_price,
            )
        except OratsAuthError as e:
            print(f"\nFATAL: {e}", file=sys.stderr)
            return events
        except OratsError as e:
            print(f"  {sym}: {e}", file=sys.stderr)
            continue
        except Exception as e:
            msg = str(e)
            if "403" in msg or "401" in msg:
                print(f"\nFATAL: ORATS rejected the request — {msg}\n"
                      f"Check ORATS_TOKEN in .env for stray characters.",
                      file=sys.stderr)
                return events
            print(f"  {sym}: skipped ({msg})", file=sys.stderr)
            continue

        print(f"[{n}/{len(symbols)}] {sym}: {len(qualifying)} qualifying day(s)",
              file=sys.stderr)

        bars = _bars(client, sym)
        days = sorted(bars)

        for (d, prev_close, open_px, gap, rvol, off_high) in qualifying:
            side = "C" if gap > 0 else "P"

            # Enter on the catalyst day's close, or the next one. Day-after
            # entry is the honest version of "I saw it and acted" -- the gap
            # is public, the chain has repriced, and you pay for both.
            i_cat = days.index(d)
            i_entry = i_cat + args.entry_delay
            if i_entry >= len(days):
                continue
            entry_day = days[i_entry]

            picked = price_event(client, sym, entry_day, side=side,
                                 otm_pct=args.otm_pct, min_dte=args.min_dte)
            if not picked:
                continue
            row, strike, ask, expiry = picked

            hold_days = days[i_entry + 1 : i_entry + 1 + args.hold]
            if not hold_days:
                continue

            marks = []
            for hd in hold_days:
                if hd > expiry:
                    break
                b = mark_on(client, sym, hd, expiry, strike, side)
                if b is not None:
                    marks.append((hd, b))
            if not marks:
                continue

            exit_date, exit_bid = marks[-1]
            best_bid = max(b for _, b in marks)
            spot_entry = _f(bars[entry_day], "clsPx", "close", "cPrice") or open_px
            spot_exit = _f(bars[exit_date], "clsPx", "close", "cPrice") or spot_entry

            events.append(
                Event(
                    symbol=sym, entry_date=entry_day, exit_date=exit_date, side=side,
                    prev_close=prev_close, open_px=open_px, gap_pct=gap, rvol=rvol,
                    off_high_pct=off_high, spot_entry=spot_entry, spot_exit=spot_exit,
                    continuation_pct=spot_exit / spot_entry - 1.0,
                    expiry=expiry, strike=strike, entry_ask=ask, exit_bid=exit_bid,
                    best_bid=best_bid,
                    return_pct=exit_bid / ask - 1.0,
                    peak_return_pct=best_bid / ask - 1.0,
                    hit_target=1 if best_bid >= ask * args.target else 0,
                    contracts_for_1k=int(1000 // (ask * 100)),
                )
            )

    return events


def summarise(events: list[Event], target: float) -> None:
    n = len(events)
    print(f"\n{'=' * 70}\n{n} qualifying events\n{'=' * 70}")
    if n < 20:
        print("Too few to conclude anything. Widen the universe or the date range.")
        return

    rets = np.array([e.return_pct for e in events])
    peaks = np.array([e.peak_return_pct for e in events])
    hits = sum(e.hit_target for e in events)
    need = required_hit_rate(target - 1)

    print(f"  mean return (held to exit)   {rets.mean() * 100:>+8.1f}%")
    print(f"  median return                {median(rets) * 100:>+8.1f}%")
    print(f"  green at exit                {int((rets > 0).sum())}/{n}  "
          f"({(rets > 0).mean() * 100:.0f}%)")
    print(f"  total losses (-90% or worse) {int((rets <= -0.90).sum())}/{n}")
    print()
    print(f"  reached {target:g}x at any point   {hits}/{n}  ({hits / n * 100:.1f}%)")
    print(f"  break-even rate needed       {need * 100:.1f}%")
    print(f"  mean PEAK return             {peaks.mean() * 100:>+8.1f}%")

    print(f"\n  VERDICT: ", end="")
    if hits / n >= need * 1.5:
        print("TARGET RATE CLEARED WITH ROOM.")
        print(f"  {hits / n * 100:.1f}% reached {target:g}x against a {need * 100:.1f}% bar.")
        print("  Note this counts the PEAK, so it assumes you actually sold there.")
        print("  You will not. Exit discipline is now the binding constraint, not")
        print("  the setup.")
    elif hits / n >= need:
        print("MARGINAL.")
        print(f"  {hits / n * 100:.1f}% vs a {need * 100:.1f}% bar, and that is on peak")
        print("  marks you would have had to sell perfectly to capture.")
    else:
        print("BELOW BREAK-EVEN.")
        print(f"  Only {hits / n * 100:.1f}% ever reached {target:g}x against a "
              f"{need * 100:.1f}% bar,")
        print("  and that is the generous peak measure. As defined, this setup")
        print("  does not support 1:5 sizing. Change the definition, not the math.")

    # The conditions worth looking at first.
    print(f"\n  Split by beaten-down (>=20% off the 52w high):")
    for label, subset in (
        ("beaten down", [e for e in events if e.off_high_pct >= 0.20]),
        ("not beaten", [e for e in events if e.off_high_pct < 0.20]),
    ):
        if len(subset) >= 10:
            h = sum(e.hit_target for e in subset)
            print(f"    {label:<12} n={len(subset):<4} hit {h / len(subset) * 100:.1f}%")

    print(f"\n  Split by gap direction:")
    for label, subset in (
        ("up-gaps", [e for e in events if e.gap_pct > 0]),
        ("down-gaps", [e for e in events if e.gap_pct < 0]),
    ):
        if len(subset) >= 10:
            h = sum(e.hit_target for e in subset)
            print(f"    {label:<12} n={len(subset):<4} hit {h / len(subset) * 100:.1f}%")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Sweep every qualifying gap event")
    ap.add_argument("--universe", required=True, help="file with one ticker per line")
    ap.add_argument("--start", required=True)
    ap.add_argument("--end", required=True)
    ap.add_argument("--out", default="study.csv")
    ap.add_argument("--min-gap", type=float, default=0.04)
    ap.add_argument("--min-rvol", type=float, default=3.0)
    ap.add_argument("--min-price", type=float, default=20.0)
    ap.add_argument("--vol-lookback", type=int, default=20)
    ap.add_argument("--otm-pct", type=float, default=0.03,
                    help="how far beyond spot to buy, in the gap direction")
    ap.add_argument("--min-dte", type=int, default=8,
                    help="the study's finding: reachable winners sat at a median "
                         "8 DTE. Three-day contracts came from pre-catalyst "
                         "entries nobody can trade.")
    ap.add_argument("--hold", type=int, default=4,
                    help="sessions held; reachable winners took a median 4 to peak")
    ap.add_argument("--entry-delay", type=int, default=0, choices=[0, 1],
                    help="0 = enter on the catalyst day's close, 1 = the day after")
    ap.add_argument("--target", type=float, default=5.0, help="target multiple")
    args = ap.parse_args(argv)

    load_dotenv(ROOT / ".env")
    import os

    token = os.environ.get("ORATS_TOKEN")
    if not token:
        print("ORATS_TOKEN not set in .env", file=sys.stderr)
        return 1

    symbols = [
        s.strip().upper()
        for s in Path(args.universe).read_text().splitlines()
        if s.strip() and not s.startswith("#")
    ]
    print(f"{len(symbols)} symbols, {args.start} to {args.end}", file=sys.stderr)

    client = OratsClient(token=token)
    events = run(client, symbols, args)

    if events:
        with open(args.out, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(asdict(events[0]).keys()))
            w.writeheader()
            for e in events:
                w.writerow(asdict(e))
        print(f"\n{len(events)} rows -> {args.out}")

    summarise(events, args.target)
    return 0


if __name__ == "__main__":
    sys.exit(main())
