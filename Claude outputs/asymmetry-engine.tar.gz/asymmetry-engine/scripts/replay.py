#!/usr/bin/env python3
"""Replay past catalysts against real ORATS history. The evidence step.

This is the OptionNet Explorer workflow -- step back to the close before an
earnings print, look at what the ATM straddle actually cost, step forward to the
close after, see what it was worth -- except it runs all twelve events in one
command instead of by hand in a Windows VM.

    python scripts/replay.py --symbol CRM --events 12
    python scripts/replay.py --symbol MU --peer NVDA --events 12
    python scripts/replay.py --symbol CRM --events 12 --csv crm.csv

What it answers, and it is the only question that matters right now:

    Over this name's last N catalysts, did buying the ATM straddle at the close
    before, and selling it at the close after, make money on average?

If the mean return is comfortably positive after spread, the mispricing the
whole engine is built on exists for this name. If it hovers around zero or
negative, it does not, and no amount of scanning will conjure it. Either answer
is worth $99.

Read the output honestly. The mean is what compounds, not the best row. A single
CRM-shaped outlier can carry a mean while eleven other events bled -- which is
why the summary prints the median and the win rate next to it, and why the
verdict refuses to call an edge that one standard error erases.
"""

from __future__ import annotations

import argparse
import csv as csvmod
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from statistics import median

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.config import load_dotenv  # noqa: E402
from engine.data.orats import OratsClient, OratsError, _f  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


@dataclass
class EventResult:
    event_date: str
    before_date: str
    after_date: str
    spot_before: float
    spot_after: float
    expiry: str
    strike: float
    straddle_cost: float      # paid at the ask, per share
    straddle_value: float     # sold at the bid, per share
    gap_pct: float
    implied_pct: float

    @property
    def pnl_per_share(self) -> float:
        return self.straddle_value - self.straddle_cost

    @property
    def return_pct(self) -> float:
        return self.pnl_per_share / self.straddle_cost if self.straddle_cost else 0.0

    @property
    def exceeded(self) -> bool:
        return abs(self.gap_pct) > self.implied_pct


def _prev_session(client: OratsClient, ticker: str, day: str) -> str | None:
    """Last session with data strictly before `day`."""
    rows = client.dailies(ticker)
    days = sorted({str(r.get("tradeDate") or "")[:10] for r in rows if r.get("tradeDate")})
    prior = [d for d in days if d < day]
    return prior[-1] if prior else None


def _next_session(client: OratsClient, ticker: str, day: str) -> str | None:
    rows = client.dailies(ticker)
    days = sorted({str(r.get("tradeDate") or "")[:10] for r in rows if r.get("tradeDate")})
    later = [d for d in days if d >= day]
    return later[0] if later else None


def _atm_straddle(strikes: list[dict], spot: float) -> tuple[dict, float] | None:
    """Nearest-the-money strike row and its distance from spot.

    ORATS returns one row per strike carrying BOTH the call and put quotes, so a
    single row is the whole straddle.
    """
    best, best_dist = None, float("inf")
    for row in strikes:
        k = _f(row, "strike")
        if k is None:
            continue
        d = abs(k - spot)
        if d < best_dist:
            best, best_dist = row, d
    return (best, best_dist) if best else None


def _straddle_prices(row: dict) -> tuple[float, float] | None:
    """(ask total, bid total) per share for the call+put at this strike."""
    ca = _f(row, "callAskPrice", "callAsk")
    cb = _f(row, "callBidPrice", "callBid")
    pa = _f(row, "putAskPrice", "putAsk")
    pb = _f(row, "putBidPrice", "putBid")
    if None in (ca, cb, pa, pb):
        # Fall back to theoretical values when quotes are absent. Flagged by the
        # caller as optimistic -- it assumes a fill at mid, which you will not get.
        cv, pv = _f(row, "callValue"), _f(row, "putValue")
        if cv is None or pv is None:
            return None
        return cv + pv, cv + pv
    return ca + pa, cb + pb


def replay(
    client: OratsClient,
    symbol: str,
    *,
    peer: str | None = None,
    events: int = 12,
    verbose: bool = True,
) -> list[EventResult]:
    if peer:
        sessions = client._own_earnings_move_sessions(peer)
        label = f"{symbol} on {peer} earnings"
    else:
        sessions = client._own_earnings_move_sessions(symbol)
        label = f"{symbol} own earnings"

    sessions = sorted(set(sessions), reverse=True)[: events * 2]
    if verbose:
        print(f"\n{label}: {len(sessions)} candidate event session(s)\n")

    out: list[EventResult] = []
    for sess in sessions:
        if len(out) >= events:
            break
        try:
            after = _next_session(client, symbol, sess)
            if not after:
                continue
            before = _prev_session(client, symbol, after)
            if not before:
                continue

            chain_before = client.hist_strikes(symbol, before)
            chain_after = client.hist_strikes(symbol, after)
            if not chain_before or not chain_after:
                continue

            spot_before = _f(chain_before[0], "stockPrice", "spotPrice", "stkPx")
            spot_after = _f(chain_after[0], "stockPrice", "spotPrice", "stkPx")
            if not spot_before or not spot_after:
                continue

            # Nearest expiry strictly after the event, from the before-chain.
            expiries = sorted({
                str(r.get("expirDate"))[:10] for r in chain_before if r.get("expirDate")
            })
            expiry = next((e for e in expiries if e > before), None)
            if not expiry:
                continue

            rows_b = [r for r in chain_before if str(r.get("expirDate"))[:10] == expiry]
            rows_a = [r for r in chain_after if str(r.get("expirDate"))[:10] == expiry]
            pick = _atm_straddle(rows_b, spot_before)
            if not pick:
                continue
            row_b, _ = pick
            strike = _f(row_b, "strike")

            row_a = next(
                (r for r in rows_a if _f(r, "strike") == strike), None
            )
            if row_a is None:
                continue

            pb_ = _straddle_prices(row_b)
            pa_ = _straddle_prices(row_a)
            if not pb_ or not pa_:
                continue
            cost = pb_[0]          # pay the ask
            value = pa_[1]         # sell the bid
            if cost <= 0:
                continue

            out.append(
                EventResult(
                    event_date=sess,
                    before_date=before,
                    after_date=after,
                    spot_before=spot_before,
                    spot_after=spot_after,
                    expiry=expiry,
                    strike=strike,
                    straddle_cost=cost,
                    straddle_value=value,
                    gap_pct=spot_after / spot_before - 1.0,
                    implied_pct=0.85 * cost / spot_before,
                )
            )
            if verbose:
                r = out[-1]
                print(
                    f"  {r.after_date}  {r.strike:>8g}  "
                    f"cost {r.straddle_cost:>6.2f} -> {r.straddle_value:>6.2f}  "
                    f"gap {r.gap_pct*100:>+6.1f}%  "
                    f"implied {r.implied_pct*100:>5.1f}%  "
                    f"return {r.return_pct*100:>+7.1f}%"
                )
        except OratsError as e:
            print(f"  {sess}: ORATS error — {e}", file=sys.stderr)
        except Exception as e:  # one bad event must not kill the replay
            print(f"  {sess}: skipped ({e})", file=sys.stderr)

    return out


def summarise(symbol: str, label: str, results: list[EventResult]) -> None:
    n = len(results)
    print(f"\n{'=' * 68}\n{label} — {n} event(s)\n{'=' * 68}")
    if n < 5:
        print("Too few usable events to conclude anything. Widen --events or")
        print("check that ORATS has chain history this far back for this name.")
        return

    rets = np.array([r.return_pct for r in results])
    gaps = np.array([abs(r.gap_pct) for r in results])
    imps = np.array([r.implied_pct for r in results])
    wins = int((rets > 0).sum())

    mean_ret = float(rets.mean())
    se = float(rets.std(ddof=1) / np.sqrt(n))
    ev_mult = float(gaps.mean() / imps.mean()) if imps.mean() else float("nan")

    print(f"  mean return per straddle   {mean_ret*100:>+8.1f}%   (± {se*100:.1f}% s.e.)")
    print(f"  median return              {median(rets)*100:>+8.1f}%")
    print(f"  win rate                   {wins}/{n}  ({wins/n*100:.0f}%)")
    print(f"  mean |gap|                 {gaps.mean()*100:>8.1f}%")
    print(f"  mean implied move          {imps.mean()*100:>8.1f}%")
    print(f"  EV multiple (gap/implied)  {ev_mult:>8.2f}x")
    print(f"  gap exceeded implied       {sum(r.exceeded for r in results)}/{n}")

    print(f"\n  VERDICT: ", end="")
    if mean_ret + se < 0:
        print("NEGATIVE EDGE — THE CHAIN IS OVERPRICING THIS.")
        print(f"  Mean return {mean_ret*100:+.1f}% ± {se*100:.1f}%. Buying this name's")
        print("  catalyst straddle has reliably LOST money over this sample. The")
        print("  interesting trade here is the other side, which this engine does")
        print("  not take and which carries undefined risk. Leave it alone.")
    elif mean_ret - se <= 0:
        print("NO EDGE DEMONSTRATED.")
        print(f"  Mean return {mean_ret*100:+.1f}% ± {se*100:.1f}% straddles zero. On this")
        print("  evidence the chain is pricing this name's catalysts about right,")
        print("  and the engine should keep declining it.")
    elif mean_ret - se < 0.15:
        print("MARGINAL.")
        print(f"  Positive but thin ({mean_ret*100:+.1f}% ± {se*100:.1f}%). Worth watching,")
        print("  not worth sizing into. Re-run when there are more events.")
    else:
        print("EDGE PRESENT IN THIS SAMPLE.")
        print(f"  Mean {mean_ret*100:+.1f}% ± {se*100:.1f}% over {n} events. Note this is")
        print("  in-sample on a small n, and assumes you paid the ask and sold the")
        print("  bid at the close. Real fills and IV crush timing will be worse.")

    print(
        "\n  Reminder: the mean is what compounds. Check whether one row is\n"
        "  carrying it — a single outlier in twelve is a story, not an edge."
    )


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Replay catalysts against ORATS history")
    ap.add_argument("--symbol", required=True)
    ap.add_argument("--peer", help="condition on this bellwether's earnings instead")
    ap.add_argument("--events", type=int, default=12)
    ap.add_argument("--csv", help="write per-event rows to this file")
    args = ap.parse_args(argv)

    load_dotenv(ROOT / ".env")
    import os

    token = os.environ.get("ORATS_TOKEN")
    if not token:
        print("ORATS_TOKEN not set. Put it in .env next to config.yaml.", file=sys.stderr)
        return 1

    client = OratsClient(token=token)
    sym = args.symbol.upper()
    peer = args.peer.upper() if args.peer else None
    label = f"{sym} on {peer} earnings" if peer else f"{sym} own earnings"

    results = replay(client, sym, peer=peer, events=args.events)
    summarise(sym, label, results)

    if args.csv and results:
        with open(args.csv, "w", newline="") as fh:
            w = csvmod.writer(fh)
            w.writerow(["event", "before", "after", "spot_before", "spot_after",
                        "expiry", "strike", "cost", "value", "gap_pct",
                        "implied_pct", "return_pct"])
            for r in results:
                w.writerow([r.event_date, r.before_date, r.after_date,
                            f"{r.spot_before:.2f}", f"{r.spot_after:.2f}",
                            r.expiry, r.strike, f"{r.straddle_cost:.2f}",
                            f"{r.straddle_value:.2f}", f"{r.gap_pct:.4f}",
                            f"{r.implied_pct:.4f}", f"{r.return_pct:.4f}"])
        print(f"\n  rows -> {args.csv}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
