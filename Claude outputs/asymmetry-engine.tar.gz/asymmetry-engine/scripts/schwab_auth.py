#!/usr/bin/env python3
"""One-time (and then weekly) Schwab authorisation.

Run this from a Terminal on the Mac, sitting in front of it, with a browser
available:

    python scripts/schwab_auth.py

Schwab's refresh tokens expire after SEVEN DAYS and there is no supported way
around it. So this is a recurring chore, not a one-time setup step, and the
morning run is built to fail loudly rather than skip a session when the token
has gone stale. Put a weekly reminder somewhere you will actually see it.

If you would rather be told than discover it: `scripts/check_token.sh` prints
the token's age and is safe to run from cron.
"""

from __future__ import annotations

import os
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.config import load_dotenv  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    load_dotenv(ROOT / ".env")

    api_key = os.environ.get("SCHWAB_API_KEY")
    secret = os.environ.get("SCHWAB_APP_SECRET")
    callback = os.environ.get("SCHWAB_CALLBACK_URL", "https://127.0.0.1:8182")
    token_path = Path(
        os.environ.get("SCHWAB_TOKEN_PATH", ROOT / "state" / "schwab_token.json")
    )

    if not api_key or not secret:
        print(
            "SCHWAB_API_KEY and SCHWAB_APP_SECRET must be set in .env.\n"
            "Register an app at https://developer.schwab.com — individual\n"
            "developer access to your own account needs no commercial review,\n"
            "but the app itself takes a few days to be approved.",
            file=sys.stderr,
        )
        return 1

    try:
        from schwab.auth import client_from_login_flow
    except ImportError:
        print("pip install -r requirements.txt first", file=sys.stderr)
        return 1

    token_path.parent.mkdir(parents=True, exist_ok=True)
    if token_path.exists():
        age = datetime.now() - datetime.fromtimestamp(token_path.stat().st_mtime)
        print(f"Existing token is {age.days}d {age.seconds // 3600}h old. Replacing it.")

    print("A browser window will open. Log in to Schwab and approve the app.")
    client_from_login_flow(
        api_key=api_key,
        app_secret=secret,
        callback_url=callback,
        token_path=str(token_path),
    )

    print(f"\nToken written to {token_path}")
    print("Valid for 7 days. Re-run this before it expires or the morning run stops.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
