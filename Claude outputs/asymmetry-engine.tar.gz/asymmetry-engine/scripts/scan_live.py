#!/usr/bin/env python3
"""The daily scan. Catalyst movers, with the reward tiers each chain offers.

    python scripts/scan_live.py                 # writes state/scan.html
    python scripts/scan_live.py --open          # and opens it
    python scripts/scan_live.py --budget 500

Runs morning, midday and evening. Each pass:

  1. One /cores call per symbol -- today's price against the prior close, plus
     today's stock volume. Cheap, and enough to reject 95% of the universe.
  2. Survivors get a live /strikes chain, and the chain gets a tier ladder:
     the cheapest strike delivering 5x, 10x and 25x, and the continuation each
     one needs.
  3. Everything lands in state/scan.html and appends to the journal, so you have
     a record of what was shown and when -- not just what you took.

ENTRY WINDOW: day of the catalyst, or the day after. Names whose move happened
two or more sessions ago are dropped, because by then the study says the move is
mostly gone.

REQUESTS: about 508 + a handful per pass, three passes a day, plus one daily
volume-baseline refresh. Roughly 2,000/day, 42,000/month -- inside the Live
tier's 100,000.

WHAT THIS DOES NOT DO: decide anything. It shows what is moving and what the
chain pays. Nothing here has demonstrated an edge; the study found that 92.5% of
names produce nothing in a quarter, and that the reachable winners needed about
8 days to expiry. Both facts are wired into the defaults, neither is a promise.
"""

from __future__ import annotations

import argparse
import json
import sys
import webbrowser
from datetime import date, datetime, timedelta
from pathlib import Path
from statistics import median

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.config import load_config, load_dotenv  # noqa: E402
from engine.data.orats import OratsAuthError, OratsClient, OratsError, _f  # noqa: E402
from engine.data.orats_live import OratsLiveClient  # noqa: E402
from engine.tiers import TIER_MULTIPLE, Tier, best_reachable, tier_ladder  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
BASELINE = ROOT / "state" / "volume_baseline.json"


# ---------------------------------------------------------------- baselines

def load_baseline(client: OratsClient, symbols: list[str], *, lookback: int = 20) -> dict:
    """Median daily volume per symbol, refreshed once a day.

    Recomputing this on every pass would triple its cost for data that changes
    once. Stored with the date it was built so a stale file is obvious.
    """
    today = date.today().isoformat()
    if BASELINE.exists():
        try:
            cached = json.loads(BASELINE.read_text())
            if cached.get("date") == today:
                return cached["median_volume"]
        except (json.JSONDecodeError, OSError, KeyError):
            pass

    print(f"building volume baseline for {len(symbols)} symbols "
          f"(once a day, ~{len(symbols)} requests)...", file=sys.stderr)
    out: dict[str, float] = {}
    for i, sym in enumerate(symbols, 1):
        if i % 100 == 0:
            print(f"  {i}/{len(symbols)}", file=sys.stderr)
        try:
            bars = client.dailies(sym, fresh=True)
        except OratsAuthError:
            raise
        except Exception:
            continue
        vols = [
            _f(b, "stockVolume", "volume", "vol") or 0
            for b in sorted(bars, key=lambda b: str(b.get("tradeDate") or ""))[-lookback - 1 : -1]
        ]
        vols = [v for v in vols if v > 0]
        if len(vols) >= lookback // 2:
            out[sym] = median(vols)

    BASELINE.parent.mkdir(parents=True, exist_ok=True)
    BASELINE.write_text(json.dumps({"date": today, "median_volume": out}))
    return out


# ---------------------------------------------------------------- screening

def screen(client: OratsClient, symbols: list[str], baseline: dict, args) -> list[dict]:
    """One /cores call per symbol. Returns the names worth a chain fetch."""
    hits = []
    for i, sym in enumerate(symbols, 1):
        if i % 100 == 0:
            print(f"  screened {i}/{len(symbols)}", file=sys.stderr)
        try:
            rows = client.cores(sym)
        except OratsAuthError:
            raise
        except Exception:
            continue
        if not rows:
            continue
        r = rows[0]

        prior = _f(r, "priorCls")
        px = _f(r, "pxCls", "stockPrice", "pxAtmIv")
        vol = _f(r, "stkVolu")
        if not prior or not px or prior <= 0:
            continue

        move = px / prior - 1.0
        base = baseline.get(sym, 0)
        rvol = (vol / base) if (base and vol) else 0.0

        if abs(move) < args.min_move or rvol < args.min_rvol:
            continue

        hits.append({
            "symbol": sym,
            "screen_move": move,
            "rvol": rvol,
            "price": px,
            "prior_close": prior,
            "iv_rank": _f(r, "ivRank1y"),
            "last_earnings": str(r.get("lastErn") or "")[:10],
            "next_earnings": str(r.get("nextErn") or "")[:10],
            "sector": r.get("sectorName") or r.get("sector") or "",
            "px_chg_1y": _f(r, "stkPxChng1y"),
            "avg_opt_volume": _f(r, "avgOptVolu20d"),
        })
    return hits


def catalyst_age(hit: dict) -> str:
    """Day-of, day-after, or stale. Earnings dates are the only hard marker."""
    today = date.today()
    le = hit.get("last_earnings") or ""
    try:
        d = datetime.strptime(le, "%Y-%m-%d").date()
    except ValueError:
        return "unknown"
    days = (today - d).days
    if days <= 0:
        return "today"
    if days == 1:
        return "yesterday"
    if days <= 3:
        return f"{days}d ago"
    return "no recent earnings"


# ---------------------------------------------------------------- rendering

CSS = """
:root{--bg:#FAF8F4;--panel:#FFF;--panel2:#F2EFE9;--line:#DED8CE;--line2:#C4BCAE;
--ink:#1B1D21;--ink2:#55575E;--ink3:#87888F;--brass:#A8761C;
--red:#B3402C;--red-bg:#F8E7E2;--yellow:#8A6A16;--yellow-bg:#FBF3DC;
--green:#1F6B4A;--green-bg:#E2F0E8;--dead:#9A9691;--dead-bg:#F0EDE7;}
@media(prefers-color-scheme:dark){:root:not([data-theme="light"]){
--bg:#101419;--panel:#171C23;--panel2:#1D232B;--line:#2A323C;--line2:#3A444F;
--ink:#E7EAEE;--ink2:#A3AAB4;--ink3:#767D87;--brass:#D9A441;
--red:#E07A5F;--red-bg:#2E1C17;--yellow:#D9A441;--yellow-bg:#2A2415;
--green:#5BC08D;--green-bg:#12261D;--dead:#6B6F75;--dead-bg:#1B2027;}}
:root[data-theme="dark"]{
--bg:#101419;--panel:#171C23;--panel2:#1D232B;--line:#2A323C;--line2:#3A444F;
--ink:#E7EAEE;--ink2:#A3AAB4;--ink3:#767D87;--brass:#D9A441;
--red:#E07A5F;--red-bg:#2E1C17;--yellow:#D9A441;--yellow-bg:#2A2415;
--green:#5BC08D;--green-bg:#12261D;--dead:#6B6F75;--dead-bg:#1B2027;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,
BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;-webkit-font-smoothing:antialiased}
.wrap{max-width:1080px;margin:0 auto;padding:28px 20px 70px}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-variant-numeric:tabular-nums}
header{border-bottom:2px solid var(--ink);padding-bottom:12px;margin-bottom:20px}
.eyebrow{font-family:ui-monospace,monospace;font-size:11px;letter-spacing:.14em;
text-transform:uppercase;color:var(--brass)}
h1{font-size:29px;margin:5px 0;letter-spacing:-.02em}
.dek{color:var(--ink2);font-size:14px;margin:0}
.name{background:var(--panel);border:1px solid var(--line);border-radius:10px;
margin-bottom:14px;overflow:hidden}
.nhead{display:flex;align-items:center;gap:12px;padding:12px 16px;
background:var(--panel2);border-bottom:1px solid var(--line);flex-wrap:wrap}
.tick{font-family:ui-monospace,monospace;font-size:19px;font-weight:700}
.chg{font-family:ui-monospace,monospace;font-size:16px;font-weight:600}
.up{color:var(--green)}.dn{color:var(--red)}
.chip{font-family:ui-monospace,monospace;font-size:10.5px;letter-spacing:.08em;
text-transform:uppercase;padding:3px 8px;border-radius:999px;border:1px solid var(--line2);
color:var(--ink3)}
.chip.hot{border-color:var(--brass);color:var(--brass)}
.spacer{flex:1}
.tiers{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:1px;
background:var(--line)}
.tier{padding:12px 15px;background:var(--panel)}
.tier.red{background:var(--red-bg)}.tier.yellow{background:var(--yellow-bg)}
.tier.green{background:var(--green-bg)}.tier.dead{background:var(--dead-bg);opacity:.7}
.tlabel{font-family:ui-monospace,monospace;font-size:10.5px;letter-spacing:.1em;
text-transform:uppercase;font-weight:700;margin-bottom:5px}
.tier.red .tlabel{color:var(--red)}.tier.yellow .tlabel{color:var(--yellow)}
.tier.green .tlabel{color:var(--green)}.tier.dead .tlabel{color:var(--dead)}
.contract{font-family:ui-monospace,monospace;font-size:14px;font-weight:600;margin-bottom:6px}
.need{font-size:13px;color:var(--ink2)}
.need b{font-family:ui-monospace,monospace;color:var(--ink)}
.meta{font-size:11.5px;color:var(--ink3);margin-top:6px;line-height:1.5}
.unreach{font-size:11.5px;color:var(--dead);margin-top:5px;font-style:italic}
.empty{background:var(--panel);border:1px dashed var(--line2);border-radius:10px;
padding:30px;text-align:center;color:var(--ink2);font-size:14.5px}
.note{background:var(--panel);border:1px solid var(--line);border-left:3px solid var(--brass);
border-radius:8px;padding:14px 16px;margin-bottom:20px;font-size:13.5px;color:var(--ink2)}
.note b{color:var(--ink)}
footer{margin-top:30px;padding-top:14px;border-top:1px solid var(--line);
font-size:11.5px;color:var(--ink3);line-height:1.7}
"""


def render(hits: list[dict], *, args, scanned: int) -> str:
    import html as H
    now = datetime.now()
    session = ("morning" if now.hour < 11 else "midday" if now.hour < 15 else "evening")

    cards = []
    for h in hits:
        rungs = h.get("rungs") or []
        move = h["live_move"]
        chips = [
            f'<span class="chip">RVOL {h["rvol"]:.1f}x</span>',
            f'<span class="chip">{H.escape(h["catalyst_age"])}</span>',
        ]
        if h.get("iv_rank"):
            cls = "chip hot" if h["iv_rank"] > 75 else "chip"
            chips.append(f'<span class="{cls}">IV rank {h["iv_rank"]:.0f}</span>')
        if h.get("px_chg_1y") is not None and h["px_chg_1y"] <= -20:
            chips.append(f'<span class="chip hot">{h["px_chg_1y"]:.0f}% on the year</span>')

        tiles = []
        for t in (Tier.GREEN, Tier.YELLOW, Tier.RED):
            r = next((x for x in rungs if x.tier == t), None)
            if r is None:
                tiles.append(
                    f'<div class="tier dead"><div class="tlabel">{t.value} · '
                    f'{TIER_MULTIPLE[t]:.0f}x</div>'
                    f'<div class="need">No strike in the 5–14 day window offers this '
                    f'with usable open interest.</div></div>')
                continue
            cls = t.value if r.reachable else "dead"
            tiles.append(f"""<div class="tier {cls}">
  <div class="tlabel">{t.value} · {r.multiple:.0f}x &nbsp;·&nbsp; 1 in {r.multiple:.0f}</div>
  <div class="contract">{r.strike:g}{r.right} {H.escape(r.expiry)} · {r.dte}d</div>
  <div class="need">needs <b>{r.required_move_pct*100:+.1f}%</b> more · ask
    <b>{r.ask:.2f}</b> → <b>{r.target_price:.2f}</b></div>
  <div class="meta">{r.contracts} contracts = ${r.cost:,.0f} → ${r.payout:,.0f}
    · OI {r.open_interest:,} · spread {r.spread_frac*100:.0f}%</div>
  {f'<div class="unreach">{H.escape(r.note)}</div>' if r.note else ''}
</div>""")

        cards.append(f"""<div class="name">
  <div class="nhead">
    <span class="tick">{H.escape(h['symbol'])}</span>
    <span class="chg {'up' if move>0 else 'dn'}">{move*100:+.1f}%</span>
    <span class="mono" style="color:var(--ink3);font-size:13px">${h['live_price']:.2f}</span>
    {''.join(chips)}
    <span class="spacer"></span>
    <span class="chip">{'CALLS' if move>0 else 'PUTS'}</span>
  </div>
  <div class="tiers">{''.join(tiles)}</div>
</div>""")

    body = "".join(cards) or f"""<div class="empty">
  Nothing cleared the screen — no name moved {args.min_move*100:.0f}%+ on
  {args.min_rvol:.1f}x volume.<br><br>
  This is the normal result. In the 100-day study, 92.5% of names produced
  nothing at all.</div>"""

    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Scan — {now:%b %d, %H:%M}</title><style>{CSS}</style></head><body>
<div class="wrap">
<header>
  <div class="eyebrow">{session} pass · {scanned} names screened · {len(hits)} through</div>
  <h1>Catalyst movers</h1>
  <p class="dek">{now:%A %d %B %Y, %H:%M} · entry window is the catalyst day or the one after.</p>
</header>

<div class="note">
  <b>Colour is payoff, not quality.</b> Green means a 25× strike exists — which
  it usually does, somewhere far out of the money. The number that decides the
  trade is <b>needs +x%</b>: how much further the stock has to travel. A tier
  needing more than {args.max_move*100:.0f}% is greyed out, because the study
  found roughly half a catalyst move is still available once it's public, on a
  median total of about 24%. Asking for more is asking for the top decile.
</div>

{body}

<footer>
  Break-even hit rates: 5× needs 1 in 5 · 10× needs 1 in 10 · 25× needs 1 in 25.
  Those assume a total loss otherwise, which for these strikes is the normal
  outcome. Expiry window 5–14 days, from the study's finding that reachable
  winners sat at a median 8 DTE and took 4 sessions to peak.
  Targets use intrinsic value at expiry — selling earlier into remaining
  extrinsic beats them. Nothing here has demonstrated an edge. Not investment advice.
</footer>
</div></body></html>"""


# ---------------------------------------------------------------- main

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Live catalyst scan with reward tiers")
    ap.add_argument("--config", default=str(ROOT / "config.yaml"))
    ap.add_argument("--universe", default=str(ROOT / "universe.txt"))
    ap.add_argument("--min-move", type=float, default=0.05)
    ap.add_argument("--min-rvol", type=float, default=2.5)
    ap.add_argument("--min-price", type=float, default=20.0)
    ap.add_argument("--budget", type=float, default=1000.0)
    ap.add_argument("--min-dte", type=int, default=5)
    ap.add_argument("--max-dte", type=int, default=14)
    ap.add_argument("--max-move", type=float, default=0.15,
                    help="required continuation past which a tier is greyed out")
    ap.add_argument("--max-names", type=int, default=12)
    ap.add_argument("--out", default=str(ROOT / "state" / "scan.html"))
    ap.add_argument("--open", action="store_true")
    args = ap.parse_args(argv)

    load_dotenv(ROOT / ".env")
    cfg = load_config(args.config)

    symbols = [s.strip().upper() for s in Path(args.universe).read_text().splitlines()
               if s.strip() and not s.startswith("#")]

    try:
        client = OratsClient(token=cfg.orats_token)
        live = OratsLiveClient(token=cfg.orats_token)
    except RuntimeError as e:
        print(f"config: {e}", file=sys.stderr)
        return 1

    try:
        baseline = load_baseline(client, symbols)
        print(f"screening {len(symbols)} names...", file=sys.stderr)
        hits = screen(client, symbols, baseline, args)
    except OratsAuthError as e:
        print(f"\nFATAL: {e}", file=sys.stderr)
        return 3

    hits = [h for h in hits if h["price"] >= args.min_price]
    hits.sort(key=lambda h: -abs(h["screen_move"]))
    hits = hits[: args.max_names]
    print(f"{len(hits)} name(s) through the screen; pulling live chains...", file=sys.stderr)

    kept = []
    for h in hits:
        try:
            chain = live.parsed_chain(h["symbol"])
            spot = live.spot(h["symbol"]) or h["price"]
        except OratsAuthError as e:
            print(f"\nFATAL: {e}", file=sys.stderr)
            return 3
        except Exception as e:
            print(f"  {h['symbol']}: chain unavailable ({e})", file=sys.stderr)
            continue

        # Recompute the move from the LIVE spot. /cores can lag intraday, so a
        # name that only qualified on a stale close gets dropped here.
        move = spot / h["prior_close"] - 1.0
        if abs(move) < args.min_move:
            print(f"  {h['symbol']}: {move*100:+.1f}% on live spot — below gate, dropped",
                  file=sys.stderr)
            continue

        h["live_price"] = spot
        h["live_move"] = move
        h["catalyst_age"] = catalyst_age(h)
        h["rungs"] = tier_ladder(
            chain, spot=spot, side=("C" if move > 0 else "P"),
            budget=args.budget, min_dte=args.min_dte, max_dte=args.max_dte,
            max_plausible_move=args.max_move,
        )
        best = best_reachable(h["rungs"])
        print(f"  {h['symbol']:<6} {move*100:+6.1f}%  RVOL {h['rvol']:.1f}x  "
              f"{'best: ' + best.tier.value + f' ({best.required_move_pct*100:+.1f}%)' if best else 'no reachable tier'}",
              file=sys.stderr)
        kept.append(h)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(render(kept, args=args, scanned=len(symbols)), encoding="utf-8")
    print(f"\n{len(kept)} name(s) -> {out}", file=sys.stderr)

    if args.open:
        webbrowser.open(f"file://{out.resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
