#!/usr/bin/env python3
"""Find every option that went from pennies to dollars. Hypothesis generation.

    python scripts/find_multibaggers.py --symbols CRM,DELL,MU,TSLA,NVDA \
        --days 100 --out winners.csv

    python scripts/find_multibaggers.py --universe universe.txt --days 100 \
        --max-entry 0.50 --min-multiple 20

THE TWO-PHASE METHOD, AND WHY THIS SCRIPT IS PHASE ONE

You cannot invent trading rules from nothing. You look at what worked, find what
the winners had in common, and turn that into a hypothesis. That is this script:
it sweeps historical chains and returns every contract that was cheap and later
was not -- the 0.20-to-10 trades -- with everything that was true about the
underlying at the moment it was still cheap.

This is NOT evidence that those patterns predict anything. Of course the winners
had features; so did the thousand contracts with identical features that expired
worthless. That question belongs to phase two, `study_gaps.py`, which defines a
rule and runs it over every event including the failures.

Generate here. Test there. Skipping the second half is where people go broke
with a beautiful playbook.

WHAT IT RECORDS

For each multibagger: the entry date when it was still cheap, its DTE and
distance from spot at that moment, the peak it reached, how many sessions that
took, and how far the underlying had to travel. That last column is the honest
one -- a contract that 50x'd because the stock moved 30% is not a repeatable
setup unless you can find the next 30% move.

REQUESTS

One chain fetch per symbol per trading day: ~100 per symbol over 100 days. Start
with 10-20 symbols (about 1-2k requests) before pointing it at the full
universe, which would be ~11k.
"""

from __future__ import annotations

import argparse
import csv
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from statistics import median

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.config import load_dotenv  # noqa: E402
from engine.data.orats import OratsClient, OratsAuthError, OratsError, _f  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


@dataclass
class Multibagger:
    symbol: str
    right: str
    expiry: str
    strike: float
    entry_date: str
    entry_ask: float
    peak_date: str
    peak_bid: float
    multiple: float
    sessions_to_peak: int
    dte_at_entry: int
    spot_at_entry: float
    spot_at_peak: float
    underlying_move_pct: float
    otm_pct_at_entry: float          # how far out of the money when cheap
    contracts_for_1k: int
    profit_on_1k: float
    # Why this window was scanned at all -- the catalyst footprint in the bars.
    catalyst_date: str = ""
    catalyst_gap_pct: float = 0.0
    catalyst_thrust_pct: float = 0.0
    catalyst_rvol: float = 0.0


def _trading_days(client: OratsClient, symbol: str, days: int) -> list[str]:
    bars = client.dailies(symbol)
    ds = sorted({str(b.get("tradeDate") or "")[:10] for b in bars if b.get("tradeDate")})
    return ds[-days:]


def _earnings_windows(
    client: OratsClient, symbol: str, sessions: list[str], *, before: int, after: int
) -> list[str]:
    """Only the sessions near an earnings date.

    Scanning every session spends ~80% of its requests on quiet days where
    nothing happened. Earnings land on known dates, so a window around each one
    finds the same catalyst moves for a fifth of the cost -- which buys five
    times the tickers, and breadth is what actually finds a pattern.

    Costs one extra /cores call per symbol to learn the dates. ORATS hands back
    the last twelve in `ernDate1`..`ernDate12`.
    """
    rows = client.cores(symbol)
    if not rows:
        return sessions

    dates: list[str] = []
    for i in range(1, 13):
        d = rows[0].get(f"ernDate{i}")
        if d:
            dates.append(str(d)[:10])
    nxt = rows[0].get("nextErn") or rows[0].get("lastErn")
    if nxt:
        dates.append(str(nxt)[:10])
    if not dates:
        return sessions

    idx = {s: i for i, s in enumerate(sessions)}
    keep: set[str] = set()
    for d in dates:
        # First session on or after the announcement; earnings often land on a
        # non-trading day or after the close, so anchor forward then widen.
        anchor = next((s for s in sessions if s >= d), None)
        if anchor is None:
            continue
        i = idx[anchor]
        for j in range(max(0, i - before), min(len(sessions), i + after + 1)):
            keep.add(sessions[j])

    return sorted(keep)


def _catalyst_windows(
    client: OratsClient,
    symbol: str,
    sessions: list[str],
    *,
    min_move: float,
    min_rvol: float,
    vol_lookback: int,
    before: int,
    after: int,
) -> tuple[list[str], dict[str, dict]]:
    """Sessions where SOMETHING happened, found from daily bars alone.

    This is the answer to "catalysts matter, but not only earnings." Restricting
    to the earnings calendar is cheap and blind: it would have missed TSLA's
    Cybercab run and MU's fade after NVDA printed, because neither was that
    ticker's own event.

    Daily OHLCV is ONE request and covers every session. A catalyst -- any
    catalyst -- leaves the same fingerprint in it: a violent move on abnormal
    volume. So detect the footprint rather than the cause, and spend the
    expensive chain requests only there.

    Catches both shapes:
      gap      open vs prior close, the overnight repricing
      thrust   close vs open, the move that develops during the session

    Returns the sessions to fetch, plus why each qualified so the CSV can carry
    the gap and RVOL that flagged it.
    """
    bars = _bars_by_date(client, symbol)
    if not bars:
        return sessions, {}

    idx = {s: i for i, s in enumerate(sessions)}
    keep: set[str] = set()
    why: dict[str, dict] = {}

    for i, d in enumerate(sessions):
        if i < vol_lookback or d not in bars:
            continue
        prev = bars.get(sessions[i - 1])
        cur = bars[d]
        if not prev:
            continue

        prev_close = _f(prev, "clsPx", "close", "cPrice")
        open_px = _f(cur, "opnPx", "open", "oPrice")
        close_px = _f(cur, "clsPx", "close", "cPrice")
        vol = _f(cur, "stockVolume", "volume", "vol")
        if not prev_close or not open_px or not close_px or not vol:
            continue

        gap = open_px / prev_close - 1.0
        thrust = close_px / open_px - 1.0

        hist = [
            _f(bars[x], "stockVolume", "volume", "vol") or 0
            for x in sessions[i - vol_lookback : i]
            if x in bars
        ]
        hist = [v for v in hist if v > 0]
        if len(hist) < vol_lookback // 2:
            continue
        base = median(hist)
        rvol = vol / base if base > 0 else 0

        if rvol < min_rvol:
            continue
        if abs(gap) < min_move and abs(thrust) < min_move:
            continue

        why[d] = {"gap_pct": gap, "thrust_pct": thrust, "rvol": rvol}
        for j in range(max(0, i - before), min(len(sessions), i + after + 1)):
            keep.add(sessions[j])

    return sorted(keep), why


def _bars_by_date(client: OratsClient, symbol: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for b in client.dailies(symbol):
        d = str(b.get("tradeDate") or "")[:10]
        if d:
            out[d] = b
    return out


def _chain_snapshot(
    client: OratsClient, symbol: str, day: str
) -> tuple[float | None, dict]:
    """(spot, {(right, expiry, strike): (bid, ask)}) for one session.

    Spot is returned separately rather than stuffed into the same dict under a
    sentinel key -- mixing a scalar into a dict of tuples is how you get an
    unpacking crash three functions later.
    """
    try:
        rows = client.hist_strikes(symbol, day)
    except OratsError:
        return None, {}
    if not rows:
        return None, {}

    spot = _f(rows[0], "stockPrice", "spotPrice", "stkPx")
    out: dict = {}
    for r in rows:
        strike = _f(r, "strike")
        expiry = str(r.get("expirDate") or "")[:10]
        if not strike or not expiry:
            continue
        cb, ca = _f(r, "callBidPrice", "callBid"), _f(r, "callAskPrice", "callAsk")
        pb, pa = _f(r, "putBidPrice", "putBid"), _f(r, "putAskPrice", "putAsk")
        if cb is not None and ca is not None:
            out[("C", expiry, strike)] = (cb, ca)
        if pb is not None and pa is not None:
            out[("P", expiry, strike)] = (pb, pa)
    return spot, out


def scan_symbol(
    client: OratsClient,
    symbol: str,
    *,
    days: int,
    max_entry: float,
    min_entry: float,
    min_multiple: float,
    earnings_only: bool = False,
    catalyst_only: bool = True,
    min_move: float = 0.05,
    min_rvol: float = 2.5,
    vol_lookback: int = 20,
    before: int = 1,
    after: int = 5,
) -> list[Multibagger]:
    """Build each contract's price series, then find the ones that exploded."""
    sessions = _trading_days(client, symbol, days)
    if len(sessions) < 5:
        return []

    why: dict[str, dict] = {}
    if earnings_only:
        sessions = _earnings_windows(client, symbol, sessions,
                                     before=before, after=after)
    elif catalyst_only:
        sessions, why = _catalyst_windows(
            client, symbol, sessions,
            min_move=min_move, min_rvol=min_rvol,
            vol_lookback=vol_lookback, before=before, after=after,
        )
    if len(sessions) < 3:
        return []

    # (right, expiry, strike) -> [(date, bid, ask, spot)]
    series: dict[tuple, list] = defaultdict(list)

    for d in sessions:
        spot, snap = _chain_snapshot(client, symbol, d)
        if not snap:
            continue
        for key, (bid, ask) in snap.items():
            series[key].append((d, bid, ask, spot))

    found: list[Multibagger] = []

    for (right, expiry, strike), points in series.items():
        points.sort(key=lambda p: p[0])

        # Earliest session where it was genuinely cheap AND fillable.
        entry = None
        for i, (d, bid, ask, spot) in enumerate(points):
            if min_entry <= ask <= max_entry and bid > 0:
                entry = (i, d, ask, spot)
                break
        if entry is None:
            continue

        i0, entry_date, entry_ask, spot_entry = entry
        later = points[i0 + 1 :]
        if not later:
            continue

        peak_date, peak_bid, spot_peak = max(
            ((d, bid, spot) for d, bid, _a, spot in later), key=lambda t: t[1]
        )
        multiple = peak_bid / entry_ask if entry_ask > 0 else 0
        if multiple < min_multiple:
            continue

        d0 = datetime.strptime(entry_date, "%Y-%m-%d").date()
        dexp = datetime.strptime(expiry, "%Y-%m-%d").date()
        sessions_to_peak = sum(1 for d, *_ in later if d <= peak_date)

        otm = 0.0
        if spot_entry:
            otm = (strike / spot_entry - 1.0) if right == "C" else (1.0 - strike / spot_entry)

        contracts = int(1000 // (entry_ask * 100)) if entry_ask > 0 else 0

        found.append(
            Multibagger(
                symbol=symbol, right=right, expiry=expiry, strike=strike,
                entry_date=entry_date, entry_ask=entry_ask,
                peak_date=peak_date, peak_bid=peak_bid, multiple=multiple,
                sessions_to_peak=sessions_to_peak,
                dte_at_entry=(dexp - d0).days,
                spot_at_entry=spot_entry or 0, spot_at_peak=spot_peak or 0,
                underlying_move_pct=(
                    (spot_peak / spot_entry - 1.0) if spot_entry and spot_peak else 0
                ),
                otm_pct_at_entry=otm,
                contracts_for_1k=contracts,
                profit_on_1k=contracts * (peak_bid - entry_ask) * 100,
                **_nearest_catalyst(why, entry_date),
            )
        )

    # One row per underlying move, not fifty. Adjacent strikes on the same day
    # all explode together and would otherwise flood the output.
    best: dict[tuple, Multibagger] = {}
    for m in found:
        k = (m.symbol, m.right, m.entry_date)
        if k not in best or m.profit_on_1k > best[k].profit_on_1k:
            best[k] = m
    return sorted(best.values(), key=lambda m: m.multiple, reverse=True)


def _nearest_catalyst(why: dict[str, dict], entry_date: str) -> dict:
    """The catalyst day at or just after entry -- the move this bet was on."""
    if not why:
        return {}
    later = sorted(d for d in why if d >= entry_date)
    d = later[0] if later else max(why)
    w = why[d]
    return {
        "catalyst_date": d,
        "catalyst_gap_pct": w["gap_pct"],
        "catalyst_thrust_pct": w["thrust_pct"],
        "catalyst_rvol": w["rvol"],
    }


def summarise(rows: list[Multibagger]) -> None:
    n = len(rows)
    print(f"\n{'=' * 74}\n{n} multibagger(s) found\n{'=' * 74}")
    if not n:
        print("None. Loosen --min-multiple or widen --max-entry.")
        return

    print(f"\n{'sym':<7}{'side':<5}{'entry':<12}{'ask':>7}{'peak':>8}"
          f"{'mult':>8}{'sess':>6}{'DTE':>5}{'OTM%':>7}{'stock%':>8}{'$ on 1k':>10}")
    print("-" * 74)
    for m in rows[:40]:
        print(
            f"{m.symbol:<7}{m.right:<5}{m.entry_date:<12}{m.entry_ask:>7.2f}"
            f"{m.peak_bid:>8.2f}{m.multiple:>7.1f}x{m.sessions_to_peak:>6}"
            f"{m.dte_at_entry:>5}{m.otm_pct_at_entry * 100:>6.1f}%"
            f"{m.underlying_move_pct * 100:>+7.1f}%{m.profit_on_1k:>10,.0f}"
        )
    if n > 40:
        print(f"... {n - 40} more in the CSV")

    mults = np.array([m.multiple for m in rows])
    moves = np.array([abs(m.underlying_move_pct) for m in rows])
    dtes = np.array([m.dte_at_entry for m in rows])
    otms = np.array([m.otm_pct_at_entry for m in rows])
    sess = np.array([m.sessions_to_peak for m in rows])

    print(f"\nWHAT THE WINNERS HAD IN COMMON")
    print(f"  median multiple            {median(mults):.1f}x")
    print(f"  median DTE at entry        {median(dtes):.0f} days")
    print(f"  median distance OTM        {median(otms) * 100:.1f}%")
    print(f"  median sessions to peak    {median(sess):.0f}")
    print(f"  median underlying move     {median(moves) * 100:.1f}%")
    print(f"  calls / puts               "
          f"{sum(1 for m in rows if m.right == 'C')} / "
          f"{sum(1 for m in rows if m.right == 'P')}")

    print(f"\nTHE NUMBER THAT MATTERS MOST")
    print(f"  Median underlying move required: {median(moves) * 100:.1f}%.")
    print(f"  Every one of these needed the stock to make that move. The option")
    print(f"  was never the edge -- finding the next {median(moves) * 100:.0f}% move is. That is")
    print(f"  the question the catalyst classification has to answer, and it is")
    print(f"  what study_gaps.py then tests against the events that failed.")

    print(f"\nNEXT")
    print(f"  Pull the news for each entry_date above and label the catalyst:")
    print(f"  earnings / guidance / analyst / FDA / sympathy / index / squeeze /")
    print(f"  macro / none. The labels are the hypothesis. Then run study_gaps.py")
    print(f"  to find out whether the same setup, applied blind, actually pays.")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Find options that went from pennies to dollars")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--symbols", help="comma-separated tickers")
    g.add_argument("--universe", help="file with one ticker per line")
    ap.add_argument("--days", type=int, default=100, help="trading days to look back")
    ap.add_argument("--max-entry", type=float, default=0.50,
                    help="the option must have cost this or less to qualify")
    ap.add_argument("--min-entry", type=float, default=0.05,
                    help="below this the quote is noise and unfillable")
    ap.add_argument("--min-multiple", type=float, default=20.0)
    ap.add_argument("--out", default="winners.csv")
    ap.add_argument("--earnings-only", action="store_true",
                    help="restrict to earnings dates only. Blind to sympathy "
                         "moves, product events and analyst catalysts.")
    ap.add_argument("--all-days", action="store_true",
                    help="scan every session. Thorough and ~5x the requests.")
    ap.add_argument("--min-move", type=float, default=0.05,
                    help="gap or intraday thrust that marks a catalyst day")
    ap.add_argument("--min-rvol", type=float, default=2.5)
    ap.add_argument("--window-before", type=int, default=1)
    ap.add_argument("--window-after", type=int, default=5)
    args = ap.parse_args(argv)

    load_dotenv(ROOT / ".env")
    import os

    token = os.environ.get("ORATS_TOKEN")
    if not token:
        print("ORATS_TOKEN not set in .env", file=sys.stderr)
        return 1

    if args.symbols:
        symbols = [s.strip().upper() for s in args.symbols.split(",") if s.strip()]
    else:
        symbols = [
            s.strip().upper()
            for s in Path(args.universe).read_text().splitlines()
            if s.strip() and not s.startswith("#")
        ]

    if not args.all_days and not args.earnings_only:
        per_event = args.window_before + args.window_after + 1
        events = 4     # observed rough rate for a large cap over ~100 sessions
        est = len(symbols) * (1 + events * per_event)
        print(f"{len(symbols)} symbols, catalyst days only "
              f"(any move >={args.min_move*100:.0f}% on >={args.min_rvol:.1f}x "
              f"volume) ~ {est:,} requests", file=sys.stderr)
    elif args.earnings_only:
        per_event = args.window_before + args.window_after + 1
        events = max(1, round(args.days / 63))      # ~1 earnings per quarter
        est = len(symbols) * (1 + events * per_event)
        print(f"{len(symbols)} symbols, earnings windows only "
              f"(~{events} event(s) x {per_event} sessions) ~ {est:,} requests",
              file=sys.stderr)
    else:
        est = len(symbols) * args.days
        print(f"{len(symbols)} symbols x {args.days} days ~ {est:,} requests",
              file=sys.stderr)
        print("Tip: --earnings-only costs ~1/5 of this and finds the same "
              "catalyst moves.", file=sys.stderr)
    if est > 90000:
        print("That will consume most of a Live-tier month. Narrow it.",
              file=sys.stderr)

    client = OratsClient(token=token)
    rows: list[Multibagger] = []

    for i, sym in enumerate(symbols, 1):
        print(f"[{i}/{len(symbols)}] {sym}", file=sys.stderr)
        try:
            found = scan_symbol(
                client, sym,
                days=args.days, max_entry=args.max_entry,
                min_entry=args.min_entry, min_multiple=args.min_multiple,
                earnings_only=args.earnings_only,
                catalyst_only=not args.all_days and not args.earnings_only,
                min_move=args.min_move, min_rvol=args.min_rvol,
                before=args.window_before, after=args.window_after,
            )
            rows.extend(found)
            if found:
                print(f"    {len(found)} winner(s), best {found[0].multiple:.0f}x",
                      file=sys.stderr)
        except OratsAuthError as e:
            print(f"\nFATAL: {e}", file=sys.stderr)
            return rows
        except OratsError as e:
            print(f"    ORATS error: {e}", file=sys.stderr)
        except Exception as e:
            msg = str(e)
            if "403" in msg or "401" in msg:
                print(f"\nFATAL: ORATS rejected the request for {sym} — {msg}\n"
                      f"Every symbol will fail the same way. Check ORATS_TOKEN "
                      f"in .env for stray characters.", file=sys.stderr)
                return rows
            print(f"    skipped ({msg})", file=sys.stderr)

    rows.sort(key=lambda m: m.multiple, reverse=True)

    if rows:
        with open(args.out, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(asdict(rows[0]).keys()))
            w.writeheader()
            for m in rows:
                w.writerow(asdict(m))
        print(f"\n{len(rows)} rows -> {args.out}")

    summarise(rows)
    return 0


if __name__ == "__main__":
    sys.exit(main())
