# Asymmetry Engine

A morning screen that looks for one specific thing: **catalysts where the option
chain is pricing a smaller move than the name has historically made on that kind
of catalyst.** It runs on your Mac, writes a private local dashboard, and in
paper mode builds orders without sending them.

It is not connected to truckyeahtraders.com and does not publish anything.

---

## What it actually claims

The two trades that started this — CRM's earnings gap and MU's fade after NVDA
reported — look like the same idea but are not. CRM was its own catalyst and
gapped up. MU had someone else's catalyst and went down on good news. A screen
that says "catalyst + volume → buy the cheap OTM strike" has no way to tell
those apart, and both are only obvious afterwards.

So this engine does not predict direction. It asks a narrower question that can
be answered without hindsight:

> Given what this name has actually done on its last N events of this kind, is
> today's chain pricing enough movement?

When the answer is no by a wide enough margin to survive the bid-ask spread, it
buys the move — a straddle or strangle — rather than a side. The one exception
is when the vol surface itself says one side is unusually cheap for this name,
which is a statement about skew, not about the news.

**What it will not do:** find you a $0.08 strike that becomes $10.97. That
screen is one line of code and returns hundreds of names a week, nearly all of
which expire worthless. The $0.08 *is* the market's odds estimate and it is
usually about right. Ranking by potential multiple selects for lottery tickets
with 40%-wide spreads; this engine rejects those on purpose (`max_spread_cost_frac`).

**Expect most mornings to be empty.** That is the system working. The chain
prices these events correctly most of the time, and a screen that finds a trade
every day is not selective, it is broken.

---

## Setup

```bash
cd asymmetry-engine
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # then fill it in
```

**ORATS** — subscribe at <https://orats.com/data-api>, put the token in `.env`.
This is what supplies the historical side of the comparison: `/hist/earnings`
gives past announcement dates *with timing* (which decides whether a name moves
on session D or D+1), and `/hist/dailies` gives the bars the gaps are computed
from.

**Schwab** — register an app at <https://developer.schwab.com>. Individual
developer access to your own account needs no commercial review, but app
approval takes a few days. Then:

```bash
python scripts/schwab_auth.py     # opens a browser; do this sitting at the Mac
```

**Run it:**

```bash
python run_morning.py             # paper, today
python run_morning.py --dry-run   # screen only, journal nothing
open state/dashboard.html
```

**Schedule it:**

```bash
./scripts/install_launchd.sh      # weekdays 07:00 MT (09:00 ET) by default
```

---

## The weekly chore you cannot avoid

Schwab refresh tokens expire after **seven days** and re-authorising requires a
browser. There is no supported workaround. So:

- The scheduled run **will** fail on auth roughly once a week, forever.
- It fails **loudly** — it writes a dashboard saying so rather than silently
  skipping the session, because a job that quietly does nothing is how you find
  out six weeks later that it never fired.
- `./scripts/check_token.sh` prints days remaining and is safe to cron.

Also: thinkorswim itself has no order API. TOS is a terminal. Everything
automated goes through the Schwab Trader API, which handles equities and options
only — a futures order returns HTTP 400.

---

## Going live

Paper is the default and the gate to live has four conditions, three of which
are about time rather than technology:

1. `mode: live` in `config.yaml`, changed deliberately.
2. `ASYMMETRY_LIVE_CONFIRM` set to **today's** date — it expires daily, so a
   scheduled run can never go live on a stale decision.
3. At least 30 closed paper positions with positive expectancy in the journal.
4. No `state/KILL` file.

If any fail, the run drops to paper and says why. This is deliberate: the gap
between "this looks great" and "this still looks great tomorrow" is where most
of the damage in a trading account gets avoided.

**Halt everything, any time:** `touch state/KILL`

---

## The caps are the point

`engine/risk.py` is the only thing that decides position size, and there is no
override parameter. The defaults:

| | |
|---|---|
| max contracts | **5** |
| max debit per trade | $500 |
| max debit per day | $1,500 |
| max open positions | 4 |
| max per underlying | 1 (no doubling up) |
| sizing | quarter-Kelly, capped by all of the above |

Every position is long premium, so max loss equals the debit and is known at
entry. Nothing here sells naked premium; that is not a limitation, it is the
design.

Changing a cap means editing `config.yaml` before the session. That timing is
the entire feature.

---

## What gets logged

Every candidate — **taken, declined, and sized-to-zero** — goes into
`state/journal.db` with the reason attached. Declines are logged because the
only question worth asking in six months is "what did it pass on, and was it
right to?" A log of winners answers nothing.

Positions are marked at close and again at expiry, so something that showed
+300% intraday and expired worthless reads as what it was.

---

## Layout

```
run_morning.py           the morning run, one pass, no interaction
config.yaml              every threshold that can decide a trade
engine/
  mispricing.py          the edge test — the only part claiming an edge
  catalysts.py           own-earnings and peer-sympathy calendar
  rvol.py                relative volume gate, time-of-day matched
  structures.py          straddle / strangle / skew-justified single side
  risk.py                sizing and the hard caps
  journal.py             the candidate log
  execution.py           order building and the live gate
  dashboard.py           the private local page
  data/schwab.py         live chains, quotes, orders
  data/orats.py          historical gaps and earnings timing
scripts/
  schwab_auth.py         weekly re-auth
  check_token.sh         days remaining
  install_launchd.sh     scheduling
tests/                   19 tests, no network
```

---

## Honest limits

- **19 passing tests, zero backtests.** The tests prove the decision logic
  behaves — it passes real underpricing, declines fair pricing, thin samples and
  wide quotes. None of them is a result. Real numbers need ORATS history.
- **Eight to twenty past events is a small sample.** The engine reports the
  standard error and refuses setups where one standard error erases the edge,
  but small-sample inference stays small-sample inference.
- **IV crush is not modelled.** Payoffs are computed at expiry. Selling into the
  post-event vol collapse the same morning is usually better and always messier;
  until that is modelled, treat the payoff numbers as a floor, not a forecast.
- **Multi-leg option orders on the Schwab API are reported as experimental.**
  Validate single-leg fills by hand before trusting a scheduled run with a
  spread.
- **Nothing here is investment advice**, and a historical move distribution does
  not predict the next move. It only says what this chain has underpriced
  before.
