# TruckYeah — All-Session Movers
#
# Works pre-market, regular hours, and after-hours. Nothing to install, no API,
# no subscription. This is the piece that actually finds the names.
#
# INSTALL
#   TOS -> Scan tab -> Stock Hacker -> Add filter -> Study
#   -> pencil icon at the right of that row -> thinkScript Editor
#   -> select all, delete, paste this, OK
#
# SETTINGS ON THAT DIALOG
#   Aggregation: 5m
#   Include Extended-Hours Trading session: CHECKED
#
# ALSO ADD, as separate filters on the Stock Hacker tab (not in here)
#   Price >= 20          <- keeps out the $1.50 movers with no usable options
#   Optionable = Yes
#   Avg Volume >= 1,000,000
#
# WHY IT IS BUILT THIS WAY
#   TOS refuses daily references inside an intraday scan ("Secondary period not
#   allowed: Day"), and it refuses extended hours on a daily scan. Pre-market
#   therefore forces intraday, and yesterday's close has to be derived from the
#   intraday bars themselves. That is what refClose does below.

input minMovePct   = 4.0;    # move vs the last regular-session close
input minThrustPct = 2.5;    # move over the last N bars, any session
input thrustBars   = 6;      # 6 bars = 30 min on 5m
input volLookback  = 20;     # ~100 min of bars for the volume baseline
input minBarRvol   = 3.0;    # this bar vs that baseline

# --- last regular-session (4pm) close, latched from intraday bars -----------
# Pre-market Tuesday this holds Monday's close, which is the gap reference.
# After Tuesday's bell it becomes Tuesday's close, so an after-hours earnings
# jump measures off today -- which is what you want for a 4:05pm reporter.
def atClose = SecondsFromTime(1600) >= 0 and SecondsFromTime(1600)[1] < 0;
rec refClose = if atClose then close[1]
               else if IsNaN(refClose[1]) or refClose[1] == 0 then close
               else refClose[1];

def movePct = if refClose > 0 then 100 * (close - refClose) / refClose else 0;

# --- thrust: is it moving RIGHT NOW ----------------------------------------
def base      = close[thrustBars];
def thrustPct = if base > 0 then 100 * (close - base) / base else 0;

# --- is this bar unusually busy vs the recent bars --------------------------
# Bar-relative rather than daily-average, which sidesteps the secondary-period
# ban and self-adjusts by session: a busy pre-market bar stands out against
# quiet pre-market bars without any threshold table.
def avgBarVol = Average(volume, volLookback)[1];
def barRvol   = if avgBarVol > 0 then volume / avgBarVol else 0;

plot scan = (AbsValue(movePct) >= minMovePct or AbsValue(thrustPct) >= minThrustPct)
        and barRvol >= minBarRvol;

# TUNING
#   floods you   -> minBarRvol 5.0, or minThrustPct 4.0
#   stays silent -> minBarRvol 2.0, or minMovePct 3.0
#
# Save the query: hamburger menu top right -> Save Scan Query -> "All-Session
# Movers". Then you just open it instead of rebuilding, and you can hang an
# alert on it so TOS pushes to your phone.
