"""End-to-end wiring test with fake brokers.

No network, no credentials, no market data. This proves the parts connect and
that the decision path reaches a sane verdict -- it is emphatically NOT a
backtest and nothing it prints is a result. Real numbers require ORATS history
and `scripts/replay.py`.

The fake chain is shaped like a pre-earnings weekly: elevated front-month IV,
reasonable spreads, real open interest.
"""

from __future__ import annotations

import sys
from datetime import date, timedelta
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.catalysts import Catalyst, CatalystCalendar  # noqa: E402
from engine.config import AppConfig, ScreenConfig  # noqa: E402
from engine.journal import Journal  # noqa: E402
from engine.mispricing import HistoricalMoves  # noqa: E402
from engine.risk import RiskLimits  # noqa: E402
from engine.structures import OptionQuote  # noqa: E402
from run_morning import _screen_one  # noqa: E402

TODAY = date.today()
FRONT = (TODAY + timedelta(days=2)).isoformat()
BACK = (TODAY + timedelta(days=30)).isoformat()


def _chain(spot: float, *, front_iv: float, back_iv: float) -> list[OptionQuote]:
    out: list[OptionQuote] = []
    for expiry, iv in ((FRONT, front_iv), (BACK, back_iv)):
        for pct in (-0.15, -0.10, -0.05, 0.0, 0.05, 0.10, 0.15):
            strike = round(spot * (1 + pct), 0)
            for right in ("C", "P"):
                # Crude but monotone: further OTM is cheaper.
                moneyness = abs(pct)
                mid = max(spot * front_iv * 0.04 * (1.0 - moneyness * 3), 0.10)
                out.append(
                    OptionQuote(
                        symbol=f"{expiry}{right}{strike:g}",
                        underlying="TEST",
                        expiry=expiry,
                        strike=strike,
                        right=right,
                        bid=round(mid * 0.97, 2),
                        ask=round(mid * 1.03, 2),
                        iv=iv,
                        open_interest=2500,
                        volume=800,
                    )
                )
    return out


class FakeSchwab:
    def __init__(self, spot=200.0, volumes=None, chain=None):
        self._spot = spot
        self._volumes = volumes or ([1_000_000] * 20 + [9_000_000])
        self._chain = chain if chain is not None else _chain(spot, front_iv=0.95, back_iv=0.42)

    def price_history_daily(self, symbol, days=30):
        return [{"volume": v} for v in self._volumes]

    def spot(self, symbol):
        return self._spot

    def parsed_chain(self, symbol, **kw):
        return self._chain


class FakeOrats:
    def __init__(self, gaps, kind="own_earnings"):
        self._gaps = gaps
        self._kind = kind

    def catalyst_gaps(self, ticker, **kw):
        return HistoricalMoves(symbol=ticker, catalyst_kind="own_earnings",
                               gaps=tuple(self._gaps))

    def peer_catalyst_gaps(self, ticker, bellwether, **kw):
        return HistoricalMoves(symbol=ticker,
                               catalyst_kind=f"peer_earnings:{bellwether}",
                               gaps=tuple(self._gaps))


class Rec:
    """Stand-in for CandidateRecord with the fields _screen_one writes."""

    def __init__(self, underlying="TEST", kind="own_earnings"):
        self.underlying = underlying
        self.catalyst_kind = kind
        self.verdict = "declined"
        self.reason = ""
        self.rvol = self.spot_at_signal = self.expiry = None
        self.implied_move_pct = self.implied_method = None
        self.hist_n = self.hist_mean_abs_pct = None
        self.ev_multiple = self.ev_multiple_net = self.exceed_rate = None
        self.structure_kind = self.binding_constraint = None
        self.legs: list = []
        self.contracts = 0
        self.debit = 0.0


class FakeExecutor:
    mode = "paper"


@pytest.fixture
def cfg(tmp_path):
    return AppConfig(
        root=tmp_path,
        mode="paper",
        account_equity=25_000.0,
        screen=ScreenConfig(universe=["TEST"], min_rvol=2.0, min_ev_multiple=1.25),
        risk=RiskLimits(max_contracts=5, max_debit_per_trade=1500,
                        max_daily_debit=3000, max_equity_frac_per_trade=0.05),
    )


@pytest.fixture
def journal(tmp_path):
    return Journal(tmp_path / "j.db")


def _run(cfg, journal, *, schwab, orats, cat, rec=None):
    rec = rec or Rec(cat.symbol, cat.kind)
    _screen_one(
        cat, cfg, schwab, orats, CatalystCalendar(), rec,
        journal=journal, executor=FakeExecutor(),
        debit_used=0.0, open_now=0,
    )
    return rec


def test_dead_tape_is_declined_before_any_option_math(cfg, journal):
    """RVOL gate runs first and cheaply. No volume, no trade, no chain fetch."""
    flat = FakeSchwab(volumes=[1_000_000] * 21)
    rec = _run(cfg, journal, schwab=flat, orats=FakeOrats([0.12] * 12),
               cat=Catalyst("TEST", "own_earnings", TODAY))
    assert rec.verdict == "declined"
    assert "RVOL" in rec.reason
    assert rec.implied_move_pct is None   # never got that far


def test_underpriced_own_earnings_reaches_a_position(cfg, journal):
    """History averages ~13% against a chain implying far less."""
    rec = _run(
        cfg, journal,
        schwab=FakeSchwab(),
        orats=FakeOrats([0.14, -0.12, 0.15, -0.11, 0.13, 0.16,
                         -0.10, 0.12, 0.14, -0.13, 0.11, 0.15]),
        cat=Catalyst("TEST", "own_earnings", TODAY),
    )
    assert rec.verdict in {"taken", "sized_to_zero"}, rec.reason
    assert rec.implied_move_pct is not None
    assert rec.hist_n == 12
    if rec.verdict == "taken":
        assert 1 <= rec.contracts <= cfg.risk.max_contracts
        assert rec.legs


def test_fairly_priced_name_is_declined_with_a_stated_reason(cfg, journal):
    """The common outcome. Must say WHY, not just return nothing."""
    rec = _run(
        cfg, journal,
        schwab=FakeSchwab(),
        orats=FakeOrats([0.02, -0.018, 0.021, -0.019, 0.02, 0.017,
                         -0.022, 0.019, 0.02, -0.018, 0.021, 0.02]),
        cat=Catalyst("TEST", "own_earnings", TODAY),
    )
    assert rec.verdict == "declined"
    assert rec.ev_multiple is not None      # the test actually ran
    assert "pricing this fairly" in rec.reason or "sample noise" in rec.reason


def test_peer_catalyst_uses_the_peer_conditioning_set(cfg, journal):
    """The MU case: catalyst belongs to NVDA, history is MU-after-NVDA."""
    rec = _run(
        cfg, journal,
        schwab=FakeSchwab(spot=900.0, chain=_chain(900.0, front_iv=0.80, back_iv=0.40)),
        orats=FakeOrats([0.09, -0.08, 0.11, -0.075, 0.10, 0.085,
                         -0.095, 0.08, 0.105, -0.09, 0.095, -0.10]),
        cat=Catalyst("MU", "peer_earnings:NVDA", TODAY, source_symbol="NVDA"),
    )
    assert rec.hist_n == 12
    assert rec.implied_move_pct is not None
    assert rec.verdict in {"taken", "sized_to_zero", "declined"}


def test_contract_cap_is_never_exceeded_however_good_the_edge(cfg, journal):
    """An absurd edge must still respect the 5-contract ceiling."""
    rec = _run(
        cfg, journal,
        schwab=FakeSchwab(),
        orats=FakeOrats([0.40, -0.38, 0.42, -0.39, 0.41, 0.37,
                         -0.43, 0.40, 0.44, -0.36, 0.39, 0.41]),
        cat=Catalyst("TEST", "own_earnings", TODAY),
    )
    assert rec.contracts <= cfg.risk.max_contracts


def test_kill_switch_file_is_detected(cfg):
    (cfg.root / "state").mkdir(parents=True, exist_ok=True)
    assert not cfg.risk.kill_switch_engaged(cfg.root)
    (cfg.root / "state" / "KILL").touch()
    assert cfg.risk.kill_switch_engaged(cfg.root)


def test_every_verdict_carries_a_reason(cfg, journal):
    """No silent declines. Ever. A blank reason is a bug."""
    for gaps in ([0.12] * 12, [0.02] * 12, [0.30, 0.05] * 6, [0.1] * 3):
        rec = _run(cfg, journal, schwab=FakeSchwab(), orats=FakeOrats(gaps),
                   cat=Catalyst("TEST", "own_earnings", TODAY))
        assert rec.reason.strip(), f"empty reason for gaps={gaps[:3]}"
