"""Tests for the ORATS live adapter.

No network. These check the two things most likely to be silently wrong when
swapping data vendors: the OSI symbol construction ORATS does not give us, and
the row-per-strike to call/put expansion.

A bad OSI symbol produces an order for the wrong contract. A bad expansion
produces a chain that looks fine and prices the wrong side.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.data.orats_live import OratsLiveClient, osi_symbol  # noqa: E402


def test_osi_symbol_matches_the_crm_reference():
    """The contract from the original screenshot: .CRM260828C252.5"""
    assert osi_symbol("CRM", "2026-08-28", "C", 252.5) == "CRM   260828C00252500"


def test_osi_symbol_pads_short_roots_to_six():
    s = osi_symbol("MU", "2026-08-28", "P", 900.0)
    assert s == "MU    260828P00900000"
    assert len(s) == 21


def test_osi_symbol_handles_six_char_root_without_padding():
    s = osi_symbol("GOOGL", "2026-09-04", "C", 250.0)
    assert s.startswith("GOOGL ")
    assert len(s) == 21


def test_osi_symbol_handles_fractional_strikes():
    """Half-dollar and quarter strikes must not round away."""
    assert osi_symbol("SPY", "2026-09-04", "C", 612.5).endswith("C00612500")
    assert osi_symbol("F", "2026-09-04", "P", 12.25).endswith("P00012250")


class FakeOrats:
    """Stands in for OratsClient; returns one row-per-strike payload."""

    def __init__(self, rows):
        self._rows = rows

    def _get(self, path, **params):
        return self._rows

    def cores(self, ticker):
        return [{}]

    def dailies(self, ticker, **kw):
        return [
            {"tradeDate": "2026-08-27", "clsPx": 198.5, "opnPx": 200.0,
             "hiPx": 201.0, "loPx": 197.0, "stockVolume": 5_000_000},
            {"tradeDate": "2026-08-28", "clsPx": 261.5, "opnPx": 228.0,
             "hiPx": 263.5, "loPx": 227.0, "stockVolume": 41_000_000},
        ]


ROW = {
    "ticker": "CRM",
    "expirDate": "2026-08-28",
    "strike": 252.5,
    "stockPrice": 261.5,
    "callBidPrice": 7.50, "callAskPrice": 8.50,
    "putBidPrice": 0.40, "putAskPrice": 0.55,
    "callOpenInterest": 12000, "putOpenInterest": 3400,
    "callVolume": 8800, "putVolume": 1200,
    "callMidIv": 0.62, "putMidIv": 0.64,
    "delta": 0.72,
}


@pytest.fixture
def client():
    c = OratsLiveClient(token="fake")
    c._client = FakeOrats([ROW])
    return c


def test_one_row_becomes_a_call_and_a_put(client):
    chain = client.parsed_chain("CRM")
    assert len(chain) == 2
    assert {q.right for q in chain} == {"C", "P"}
    assert all(q.strike == 252.5 for q in chain)
    assert all(q.expiry == "2026-08-28" for q in chain)


def test_call_and_put_get_their_own_quotes_not_each_others(client):
    """The failure that would look fine and price the wrong side."""
    call = next(q for q in client.parsed_chain("CRM") if q.right == "C")
    put = next(q for q in client.parsed_chain("CRM") if q.right == "P")
    assert (call.bid, call.ask) == (7.50, 8.50)
    assert (put.bid, put.ask) == (0.40, 0.55)
    assert call.open_interest == 12000
    assert put.open_interest == 3400


def test_put_delta_is_converted_from_orats_call_delta(client):
    """ORATS reports call delta on the row; the put's is delta - 1."""
    put = next(q for q in client.parsed_chain("CRM") if q.right == "P")
    assert put.delta == pytest.approx(-0.28)


def test_symbols_are_valid_osi(client):
    for q in client.parsed_chain("CRM"):
        assert len(q.symbol) == 21
        assert q.symbol.startswith("CRM   260828")


def test_rows_missing_quotes_are_skipped_not_faked():
    """A theoretical value is not a price. Better to drop the leg."""
    bad = dict(ROW)
    del bad["callBidPrice"]
    del bad["callAskPrice"]
    c = OratsLiveClient(token="fake")
    c._client = FakeOrats([bad])
    chain = c.parsed_chain("CRM")
    assert [q.right for q in chain] == ["P"]


def test_spot_is_read_from_the_chain(client):
    assert client.spot("CRM") == 261.5


def test_daily_bars_are_shaped_like_schwab_candles(client):
    bars = client.price_history_daily("CRM")
    assert [b["datetime"] for b in bars] == ["2026-08-27", "2026-08-28"]
    assert bars[-1]["close"] == 261.5
    assert bars[-1]["volume"] == 41_000_000
    # RVOL code reads .get("volume") off these; it must be present and numeric.
    assert all(isinstance(b["volume"], (int, float)) for b in bars)


def test_place_order_refuses_clearly(client):
    with pytest.raises(NotImplementedError, match="cannot place orders"):
        client.place_order({})
