"""Tests for the edge test.

The scenarios below are SHAPED after the CRM and MU cases but the numbers are
illustrative, not historical -- this machine has no market-data access, so
nothing here is a backtest. `scripts/replay.py` is where real ORATS history gets
pointed at the same functions to produce actual results.

What these tests prove is that the decision logic behaves: that it passes a real
underpricing, and that it declines fair pricing, thin samples, and the wide
lottery-ticket quotes that generate impressive screenshots and poor returns.
"""

import numpy as np
import pytest

from engine.mispricing import (
    HistoricalMoves,
    evaluate_edge,
    implied_move_from_straddle,
    implied_move_from_term_structure,
    round_trip_spread_fraction,
)


def _hist(symbol, kind, moves):
    return HistoricalMoves(symbol=symbol, catalyst_kind=kind, gaps=tuple(moves))


def test_term_structure_extraction_isolates_the_event():
    """Front expiry at 95% IV over a back expiry at 45% should imply a real move."""
    im = implied_move_from_term_structure(
        symbol="CRM",
        spot=198.50,
        front_expiry="2026-08-28",
        front_iv=0.95,
        front_t_years=2 / 365,
        back_iv=0.45,
        back_t_years=30 / 365,
        atm_strike=200.0,
        straddle_mid=15.20,
    )
    assert im is not None
    assert im.method == "term_structure"
    # sqrt(2/365 * (0.95^2 - 0.45^2)) ~= 6.5%
    assert 0.055 < im.move_pct < 0.075


def test_term_structure_returns_none_when_no_event_is_priced():
    """Front IV below back IV means the chain sees no event. Nothing to trade."""
    assert (
        implied_move_from_term_structure(
            symbol="AAPL",
            spot=200.0,
            front_expiry="2026-09-05",
            front_iv=0.28,
            front_t_years=5 / 365,
            back_iv=0.32,
            back_t_years=40 / 365,
            atm_strike=200.0,
            straddle_mid=4.0,
        )
        is None
    )


def test_own_earnings_underpricing_passes():
    """CRM-shaped: chain implies ~6.5%, name has averaged ~11% on its own prints."""
    im = implied_move_from_straddle(
        symbol="CRM",
        spot=198.50,
        expiry="2026-08-28",
        atm_strike=200.0,
        straddle_mid=15.20,
        spread_cost_frac=0.06,
    )
    hist = _hist(
        "CRM",
        "own_earnings",
        [0.14, -0.09, 0.11, -0.13, 0.08, 0.16, -0.07, 0.12, 0.10, -0.11, 0.09, 0.15],
    )
    res = evaluate_edge(im, hist)
    assert res.passed, res.reasons
    assert res.ev_multiple > 1.4
    assert res.ev_multiple_net < res.ev_multiple  # spread always costs something


def test_peer_catalyst_underpricing_passes():
    """MU-shaped: the catalyst is NVDA's print, not MU's. Same test, different set."""
    im = implied_move_from_straddle(
        symbol="MU",
        spot=980.0,
        expiry="2026-08-28",
        atm_strike=980.0,
        straddle_mid=46.0,
        spread_cost_frac=0.05,
    )
    hist = _hist(
        "MU",
        "peer_earnings:NVDA",
        [-0.075, 0.06, -0.09, 0.055, -0.08, 0.07, -0.11, 0.05, 0.085, -0.065,
         0.09, -0.07, 0.06, -0.10],
    )
    res = evaluate_edge(im, hist)
    assert res.passed, res.reasons
    assert res.catalyst_kind == "peer_earnings:NVDA"


def test_fairly_priced_event_is_declined():
    """The common case. The chain usually gets it right and we should say so."""
    im = implied_move_from_straddle(
        symbol="AAPL",
        spot=200.0,
        expiry="2026-08-28",
        atm_strike=200.0,
        straddle_mid=14.0,
        spread_cost_frac=0.04,
    )
    hist = _hist(
        "AAPL",
        "own_earnings",
        [0.055, -0.06, 0.05, -0.048, 0.062, 0.044, -0.058, 0.051, 0.049, -0.053],
    )
    res = evaluate_edge(im, hist)
    assert not res.passed
    assert "pricing this fairly" in " ".join(res.reasons)


def test_wide_spread_lottery_ticket_is_declined():
    """The $0.08/$0.12 strike. Huge multiple, uninvestable quote."""
    im = implied_move_from_straddle(
        symbol="XYZ",
        spot=100.0,
        expiry="2026-08-28",
        atm_strike=100.0,
        straddle_mid=3.0,
        spread_cost_frac=0.45,
    )
    hist = _hist("XYZ", "own_earnings", [0.18, -0.15, 0.20, -0.17, 0.22, 0.16,
                                          -0.19, 0.21, 0.14, -0.16])
    res = evaluate_edge(im, hist)
    assert not res.passed
    assert "inside the spread" in " ".join(res.reasons)


def test_thin_sample_is_declined_even_when_the_edge_looks_huge():
    """A recent IPO with three prints and a 3x apparent edge is still noise."""
    im = implied_move_from_straddle(
        symbol="NEWCO",
        spot=50.0,
        expiry="2026-08-28",
        atm_strike=50.0,
        straddle_mid=2.0,
        spread_cost_frac=0.05,
    )
    hist = _hist("NEWCO", "own_earnings", [0.25, -0.30, 0.28, 0.22])
    res = evaluate_edge(im, hist)
    assert not res.passed
    assert "too few to claim anything" in " ".join(res.reasons)


def test_edge_inside_one_standard_error_is_declined():
    """A marginal mean carried by one outlier must not pass."""
    im = implied_move_from_straddle(
        symbol="WOBBLY",
        spot=100.0,
        expiry="2026-08-28",
        atm_strike=100.0,
        straddle_mid=7.0,
        spread_cost_frac=0.03,
    )
    # Mean is dragged over the line by a single 30% event; the rest sit near
    # the implied move. High variance, small n -- exactly the case to refuse.
    hist = _hist(
        "WOBBLY",
        "own_earnings",
        [0.06, -0.05, 0.30, 0.055, -0.06, 0.05, -0.045, 0.065, 0.05, -0.055],
    )
    res = evaluate_edge(im, hist)
    assert not res.passed
    assert "sample noise" in " ".join(res.reasons)


def test_round_trip_spread_fraction_on_a_penny_option():
    """0.08 bid / 0.12 ask is 40% of mid, round trip."""
    assert round_trip_spread_fraction([(0.08, 0.12)]) == pytest.approx(0.40)


def test_round_trip_spread_fraction_multi_leg():
    """A strangle gives up spread on both legs."""
    frac = round_trip_spread_fraction([(1.00, 1.10), (0.90, 1.00)])
    assert frac == pytest.approx(0.20 / 2.00)


def test_round_trip_spread_fraction_rejects_crossed_quotes():
    assert round_trip_spread_fraction([(1.0, 0.5)]) == float("inf")


def test_upside_share_is_reported_but_never_gates():
    """A lopsided history is information, not a direction signal."""
    hist = _hist("TREND", "own_earnings",
                 [0.10, 0.09, 0.11, 0.08, 0.12, 0.10, 0.09, -0.05, 0.11, 0.10])
    assert hist.upside_share() == pytest.approx(0.9)
    im = implied_move_from_straddle(
        symbol="TREND", spot=100.0, expiry="2026-08-28",
        atm_strike=100.0, straddle_mid=6.0, spread_cost_frac=0.05,
    )
    res = evaluate_edge(im, hist)
    # Whatever the verdict, nothing in it depends on the 90% up-rate.
    assert "upside" not in " ".join(res.reasons).lower()
