#!/bin/bash
# Double-click me. The honest test: counts losers as well as winners.
cd "$(dirname "$0")/.."
clear
echo "======================================================="
echo "  DENOMINATOR"
echo "======================================================="
echo "  Enters AFTER the catalyst is public and counts EVERY"
echo "  trade, including the ones that went to zero."
echo
echo "  The bar is 20%. One in five must reach 5x or the"
echo "  strategy loses money regardless of how good the"
echo "  winners look."
echo
echo "  This takes a while. Leave it running."
echo
read -p "  Press Return to start, or Ctrl-C to back out. "
bash scripts/run_denominator.sh
echo
echo "Press any key to close."
read -n 1
