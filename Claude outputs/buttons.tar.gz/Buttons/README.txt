THE BUTTONS
===========

Double-click any of these in Finder. No Terminal typing.

  1 — SCAN NOW              During market hours. Live chains, tier ladders,
                            opens an HTML report in your browser.

  2 — WEEKEND REPLAY        Market closed. Same scan, priced off the last
                            completed session. Use it on a Sunday.

  3 — BACKTEST A TRADE      Asks ticker / buy date / expiry / how many, then
                            replays the real chain. Defaults are the ASO
                            September trade — just hit Return four times.

  4 — DENOMINATOR           Run once. Counts losers as well as winners.
                            This is the one that says whether any of it pays.


FIRST TIME ONLY
---------------
macOS will block an unsigned .command file. Two ways past it:

  Easy:  right-click the file -> Open -> Open anyway
  Once:  open Terminal, run:  xattr -d com.apple.quarantine ~/asymmetry-engine/Buttons/*.command

Do that once per file and they behave like normal apps after.

Drag the Buttons folder to your Dock or Desktop if you want them closer.


IF A BUTTON FAILS
-----------------
The window stays open and prints the error. Copy the whole thing and send it
to Claude. Do not close it and retry -- the error text is the useful part.
