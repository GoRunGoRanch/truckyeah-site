#!/bin/bash
# Double-click me. Asks what trade to replay, then shows what it would have paid.
cd "$(dirname "$0")/.."
clear
echo "======================================================="
echo "  BACKTEST A TRADE"
echo "======================================================="
echo "  Replays a real chain from history. Entry at the ask,"
echo "  exit at the bid. Press Return to accept a default."
echo

if [ ! -d .venv ]; then echo "No .venv. See START-HERE.md."; read -n1; exit 1; fi
source .venv/bin/activate

read -p "  Ticker           [ASO]         : " T;  T=${T:-ASO}
read -p "  Buy date         [2026-09-08]  : " E;  E=${E:-2026-09-08}
read -p "  Expiry           [2026-09-11]  : " X;  X=${X:-2026-09-11}
read -p "  Calls or puts    [C]           : " S;  S=${S:-C}
read -p "  How many         [50]          : " N;  N=${N:-50}
read -p "  One strike only  [all]         : " K

ARGS=(--ticker "$T" --entry "$E" --expiry "$X" --side "$S" --contracts "$N")
[ -n "$K" ] && ARGS+=(--strike "$K")

echo
python scripts/one_trade.py "${ARGS[@]}"
STATUS=$?

echo
if [ $STATUS -ne 0 ]; then
  echo "-------------------------------------------------------"
  echo "  It stopped. Copy everything above and send it to me."
  echo "-------------------------------------------------------"
fi
echo "Press any key to close."
read -n 1
