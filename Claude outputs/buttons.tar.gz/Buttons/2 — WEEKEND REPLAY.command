#!/bin/bash
# Double-click me. Works when the market is closed.
# Replays the last trading day so you can study setups on a Sunday.
cd "$(dirname "$0")/.."
clear
echo "======================================================="
echo "  WEEKEND REPLAY — last session's movers and ladders"
echo "======================================================="
echo "  The market is closed, so this reads the most recent"
echo "  session's data instead of live quotes."
echo

if [ ! -d .venv ]; then echo "No .venv. See START-HERE.md."; read -n1; exit 1; fi
source .venv/bin/activate

python scripts/scan_live.py --weekend "$@"
STATUS=$?

echo
if [ $STATUS -ne 0 ]; then
  echo "-------------------------------------------------------"
  echo "  It stopped. Copy everything above and send it to me."
  echo "  (If it says --weekend is unknown, tell me.)"
  echo "-------------------------------------------------------"
elif [ -f state/scan.html ]; then
  open state/scan.html
fi
echo
echo "Press any key to close."
read -n 1
