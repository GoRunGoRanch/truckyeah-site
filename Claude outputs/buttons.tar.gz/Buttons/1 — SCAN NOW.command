#!/bin/bash
# Double-click me. Live scan -> HTML report opens in your browser.
cd "$(dirname "$0")/.."
clear
echo "======================================================="
echo "  SCAN NOW — live chains, tier ladders"
echo "======================================================="
echo

if [ ! -d .venv ]; then echo "No .venv. See START-HERE.md."; read -n1; exit 1; fi
source .venv/bin/activate

python scripts/scan_live.py "$@"
STATUS=$?

echo
if [ $STATUS -ne 0 ]; then
  echo "-------------------------------------------------------"
  echo "  It stopped. Copy everything above and send it to me."
  echo "-------------------------------------------------------"
elif [ -f state/scan.html ]; then
  open state/scan.html
  echo "  Report opened in your browser."
  echo "  Nothing listed = nothing cleared the screen. That is the"
  echo "  normal result on most days, not an error."
fi
echo
echo "Press any key to close."
read -n 1
