#!/usr/bin/env python3
"""Replay ONE option trade on real historical chains.

Different question from replay.py. That one asks "does buying this name's
earnings straddle pay, over twelve events?" This one asks "if I had bought
these calls on this day, what would have happened?" -- one ticker, one entry
date, one expiry, every strike priced.

Entry is at the ASK, exit at the BID, both from ORATS history. No mid-price
fantasy. Strikes with no exit quote settle at intrinsic and are marked.

    python scripts/one_trade.py --ticker ASO --entry 2026-09-08 --expiry 2026-09-11
    python scripts/one_trade.py --ticker ASO --entry 2026-09-08 --expiry 2026-09-11 \
        --contracts 50 --strike 47.5

One event is an anecdote. It tells you what happened; it does not tell you how
often it happens. The denominator run is what answers that.
"""

from __future__ import annotations

import argparse
import html
import os
import sys
import webbrowser
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.config import load_dotenv  # noqa: E402
from engine.data.orats import OratsClient, OratsError, _f  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


def _d(s: str) -> date:
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        raise SystemExit(f"Date must look like 2026-09-08, got {s!r}")


def _ask(row, side):
    return _f(row, "callAskPrice", "callAsk") if side == "C" else _f(row, "putAskPrice", "putAsk")


def _bid(row, side):
    return _f(row, "callBidPrice", "callBid") if side == "C" else _f(row, "putBidPrice", "putBid")


def _spot(chain):
    for r in chain:
        px = _f(r, "stockPrice", "spotPrice", "stkPx")
        if px:
            return px
    return None


def _chain_on(client, ticker, day: date, expiry: str):
    try:
        rows = client.hist_strikes(ticker, day.isoformat())
    except OratsError:
        return []
    return [r for r in rows if str(r.get("expirDate"))[:10] == expiry]


def _walk_back(client, ticker, target: date, expiry: str, back: int = 7):
    """Walk backwards until a chain appears -- covers weekends and holidays."""
    for i in range(back + 1):
        day = target - timedelta(days=i)
        rows = _chain_on(client, ticker, day, expiry)
        if rows:
            return day, rows
    return None, []


@dataclass
class Leg:
    strike: float
    entry_ask: float
    exit_value: float
    basis: str
    contracts: int

    @property
    def cost(self):
        return self.entry_ask * 100 * self.contracts

    @property
    def pnl(self):
        return self.exit_value * 100 * self.contracts - self.cost

    @property
    def multiple(self):
        return self.exit_value / self.entry_ask if self.entry_ask > 0 else 0.0


def run(a) -> int:
    load_dotenv(ROOT / ".env")
    token = os.environ.get("ORATS_TOKEN")
    if not token:
        print("ORATS_TOKEN not set. Put it in .env next to config.yaml.", file=sys.stderr)
        return 1

    client = OratsClient(token=token)
    ticker, side = a.ticker.upper(), a.side.upper()
    entry_day, expiry = _d(a.entry), a.expiry
    _d(expiry)  # validate

    print(f"\n  {ticker} {side}   entry {entry_day}   expiry {expiry}"
          f"   {a.contracts} contract{'s' if a.contracts != 1 else ''}")
    print("  " + "=" * 68)

    entry_rows = _chain_on(client, ticker, entry_day, expiry)
    if not entry_rows:
        found, entry_rows = _walk_back(client, ticker, entry_day, expiry)
        if not entry_rows:
            print(f"\n  No {ticker} chain expiring {expiry} on or near {entry_day}.")
            print("  Either that expiry does not exist for this name, or ORATS has")
            print("  no chain history that far back. Try a nearby Friday.\n")
            return 1
        print(f"  (no session on {entry_day}; used {found})")
        entry_day = found

    exit_day, exit_rows = _walk_back(client, ticker, _d(expiry), expiry)

    spot_in, spot_out = _spot(entry_rows), _spot(exit_rows) if exit_rows else None
    if spot_out is None:
        try:
            end = _d(expiry)
            bars = client.dailies(ticker)
            days = [r for r in bars if str(r.get("tradeDate"))[:10] <= end.isoformat()]
            if days:
                spot_out = _f(days[-1], "clsPx", "close", "cPrice")
        except OratsError:
            pass

    if not spot_in or not spot_out:
        print("\n  Could not establish both entry and exit spot prices.\n")
        return 1

    move = (spot_out / spot_in - 1.0) * 100
    print(f"  spot {spot_in:.2f} -> {spot_out:.2f}   ({move:+.2f}%)"
          + (f"   exit priced {exit_day}" if exit_day else ""))
    print()

    exit_by_k = {_f(r, "strike"): r for r in exit_rows if _f(r, "strike") is not None}

    legs = []
    for r in sorted(entry_rows, key=lambda x: _f(x, "strike") or 0):
        k, ask = _f(r, "strike"), _ask(r, side)
        if k is None or not ask or ask <= 0:
            continue
        if a.strike is not None and abs(k - a.strike) > 1e-6:
            continue
        er = exit_by_k.get(k)
        val, basis = (_bid(er, side) if er else None), "bid"
        if val is None:
            val = max(0.0, (spot_out - k) if side == "C" else (k - spot_out))
            basis = "intrinsic"
        legs.append(Leg(k, ask, val, basis, a.contracts))

    if not legs:
        print("  No strikes with a usable ask at that expiry.\n")
        return 1

    hdr = f"  {'strike':>8} {'entry ask':>10} {'exit':>9} {'mult':>8} {'cost':>11} {'P&L':>13}"
    print(hdr)
    print("  " + "-" * (len(hdr) - 2))
    for l in legs:
        mark = "i" if l.basis == "intrinsic" else " "
        print(f"  {l.strike:>8.1f} {l.entry_ask:>10.2f} {l.exit_value:>8.2f}{mark}"
              f" {l.multiple:>7.2f}x {l.cost:>11,.0f} {l.pnl:>+13,.0f}")

    best = max(legs, key=lambda l: l.multiple)
    hits = sum(1 for l in legs if l.multiple >= 5.0)
    print()
    print(f"  best:  {best.strike:.1f} strike, {best.entry_ask:.2f} -> {best.exit_value:.2f}"
          f"  =  {best.multiple:.2f}x   ({best.pnl:+,.0f} on {a.contracts})")
    print(f"  strikes that reached 5x:  {hits} of {len(legs)}")
    if any(l.basis == "intrinsic" for l in legs):
        print("  'i' = no exit quote, settled at intrinsic")

    if a.contracts * best.entry_ask * 100 > 500:
        print()
        print(f"  NOTE: {a.contracts} contracts is ${best.cost:,.0f}. engine/risk.py caps a")
        print("  live trade at 5 contracts and $500. This is a replay, so it is not")
        print("  sized -- but do not read the P&L column as a position you would take.")

    print()

    out = ROOT / "state" / f"trade_{ticker}_{entry_day}_{expiry}.html"
    out.parent.mkdir(exist_ok=True)
    out.write_text(_render(ticker, side, entry_day, expiry, spot_in, spot_out,
                           move, legs, a.contracts))
    print(f"  report -> {out}")
    if not a.no_open:
        webbrowser.open(f"file://{out.resolve()}")
    return 0


def _render(ticker, side, entry_day, expiry, spot_in, spot_out, move, legs, contracts):
    rows = "\n".join(
        f"<tr class='{'win' if l.multiple >= 5 else ''}'>"
        f"<td>{l.strike:.1f}</td><td>{l.entry_ask:.2f}</td>"
        f"<td>{l.exit_value:.2f}{'<sup>i</sup>' if l.basis == 'intrinsic' else ''}</td>"
        f"<td><b>{l.multiple:.2f}x</b></td><td>${l.cost:,.0f}</td>"
        f"<td class='{'pos' if l.pnl >= 0 else 'neg'}'>{l.pnl:+,.0f}</td></tr>"
        for l in legs)
    hits = sum(1 for l in legs if l.multiple >= 5.0)
    return f"""<!doctype html><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>{html.escape(ticker)} {expiry}</title>
<style>
:root{{color-scheme:light dark;--bg:#f7f5f1;--fg:#1b1d21;--card:#fff;--line:#e2ddd4;--mut:#6b7280}}
@media(prefers-color-scheme:dark){{:root{{--bg:#14181e;--fg:#e9ecef;--card:#1c2229;--line:#2a323b;--mut:#9aa4af}}}}
body{{font:15px/1.55 -apple-system,system-ui,sans-serif;margin:0;padding:20px 16px;
background:var(--bg);color:var(--fg)}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:12px;
padding:20px;max-width:760px;margin:0 auto 14px}}
h1{{font-size:21px;margin:0 0 4px}} .sub{{color:var(--mut);margin:0 0 14px;font-size:14px}}
.big{{font-size:30px;font-weight:700;margin:2px 0}}
table{{border-collapse:collapse;width:100%}}
th{{text-align:right;font-size:11px;letter-spacing:.05em;text-transform:uppercase;
color:var(--mut);padding:6px 6px;border-bottom:2px solid var(--line)}}
th:first-child,td:first-child{{text-align:left}}
td{{text-align:right;padding:7px 6px;border-bottom:1px solid var(--line);
font-variant-numeric:tabular-nums}}
tr.win{{background:rgba(62,154,110,.14)}}
.pos{{color:#3e9a6e}} .neg{{color:#c4553d}} sup{{color:var(--mut)}}
.wrap{{overflow-x:auto}}
</style>
<div class=card>
<h1>{html.escape(ticker)} {side} &middot; {expiry} expiry</h1>
<p class=sub>Bought {entry_day} at the ask, sold at the bid &middot; {contracts} contract(s)<br>
Spot {spot_in:.2f} &rarr; {spot_out:.2f} <b>({move:+.2f}%)</b></p>
<p class=big>{hits} of {len(legs)} strikes reached 5&times;</p>
</div>
<div class=card><div class=wrap>
<table>
<tr><th>Strike</th><th>Entry ask</th><th>Exit</th><th>Multiple</th><th>Cost</th><th>P&amp;L</th></tr>
{rows}
</table></div>
<p class=sub style="margin-top:14px"><sup>i</sup> no exit quote; settled at intrinsic.<br>
This is one event replayed on real quotes. It shows what happened. It does not
show how often it happens &mdash; that is what the denominator run is for.</p>
</div>
"""


def main():
    ap = argparse.ArgumentParser(description="Replay one option trade on historical chains.")
    ap.add_argument("--ticker", required=True)
    ap.add_argument("--entry", required=True, help="YYYY-MM-DD you would have bought")
    ap.add_argument("--expiry", required=True, help="YYYY-MM-DD contract expiry")
    ap.add_argument("--side", default="C", choices=["C", "P"])
    ap.add_argument("--contracts", type=int, default=1)
    ap.add_argument("--strike", type=float, default=None)
    ap.add_argument("--no-open", action="store_true")
    return run(ap.parse_args())


if __name__ == "__main__":
    sys.exit(main())
