#!/usr/bin/env python3
"""Read a scan's JSON on stdin, write it to Supabase.

    python scripts/scan_live.py --json | python scripts/push_to_supabase.py

Needs SUPABASE_URL and SUPABASE_SERVICE_KEY in the environment. The service
key bypasses row-level security, so it belongs in GitHub Actions secrets and
never in the browser or the repo.

Writes one `runs` row, one `movers` row per name, and one `tiers` row per rung.
If a mover fails to insert, the run row is marked not-ok with the error rather
than leaving a half-written scan that reads as a clean empty day -- an empty
scan and a broken scan look identical on the dashboard otherwise, and only one
of them is normal.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request


def _env(name: str) -> str:
    v = os.environ.get(name, "").strip()
    if not v:
        sys.exit(f"{name} is not set. Add it to your GitHub Actions secrets.")
    return v


class Supabase:
    def __init__(self, url: str, key: str):
        self.base = url.rstrip("/") + "/rest/v1"
        self.headers = {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation",
        }

    def insert(self, table: str, row: dict) -> dict:
        req = urllib.request.Request(
            f"{self.base}/{table}",
            data=json.dumps(row).encode(),
            headers=self.headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                out = json.loads(r.read() or "[]")
        except urllib.error.HTTPError as e:
            body = e.read().decode(errors="replace")[:400]
            raise RuntimeError(f"{table} insert failed ({e.code}): {body}") from e
        if not out:
            raise RuntimeError(f"{table} insert returned nothing")
        return out[0]

    def patch(self, table: str, row_id: int, row: dict) -> None:
        req = urllib.request.Request(
            f"{self.base}/{table}?id=eq.{row_id}",
            data=json.dumps(row).encode(),
            headers=self.headers,
            method="PATCH",
        )
        try:
            urllib.request.urlopen(req, timeout=30).read()
        except urllib.error.HTTPError:
            pass  # best effort; the run row already exists


def main() -> int:
    raw = sys.stdin.read().strip()
    if not raw:
        sys.exit("No JSON on stdin. Did scan_live.py run with --json?")
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        sys.exit(f"stdin was not JSON: {e}")

    db = Supabase(_env("SUPABASE_URL"), _env("SUPABASE_SERVICE_KEY"))

    run = db.insert("runs", payload["run"])
    run_id = run["id"]
    movers = payload.get("movers", [])
    n_tiers = 0

    try:
        for m in movers:
            rungs = m.pop("tiers", [])
            m["run_id"] = run_id
            mover = db.insert("movers", m)
            for t in rungs:
                t["mover_id"] = mover["id"]
                db.insert("tiers", t)
                n_tiers += 1
    except RuntimeError as e:
        db.patch("runs", run_id, {"ok": False, "error": str(e)[:500]})
        sys.exit(f"partial write, run {run_id} marked not-ok: {e}")

    print(f"run {run_id}: {len(movers)} mover(s), {n_tiers} tier(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
