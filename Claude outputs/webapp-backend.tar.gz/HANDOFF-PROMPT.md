# The prompt

Copy everything below the line into a **new Claude Code session**, opened in an
empty folder that has `asymmetry-engine/` sitting inside it.

Do it in Claude Code rather than a Claude Project — the build needs to write
files, run `npm`, and push to GitHub, and a Project can only talk.

---

I'm building a private web tool for myself. I'm a physician, not an engineer —
assume I will not enjoy debugging, and optimise every choice for "this just
works without me opening a terminal."

Read `asymmetry-engine/BUILD-SPEC.md` first and in full. It is the complete
brief: architecture, schema, page-by-page UI, and the constraints behind each
default. Follow it. Where it says not to change something, don't.

Short version of what exists: `asymmetry-engine/` is a working, tested Python
package (31 passing tests) that scans ~500 US large caps for catalyst-driven
moves and prices the option chain on each one into three reward tiers — 5x, 10x,
25x — each with the underlying move it would require. It runs from a terminal
today, which is why I don't run it. I want it as a web app I open on my phone.

## Steps 1–3 are already written. Do not redo them.

- **`supabase/schema.sql`** — the whole schema plus indexes and RLS enabled.
  Paste it into the Supabase SQL editor and run it once.
- **`scripts/scan_live.py --json`** — emits the scan as JSON on stdout. The
  HTML output still works and must keep working; it's the fallback.
- **`scripts/push_to_supabase.py`** — reads that JSON on stdin, writes
  `runs` / `movers` / `tiers`. Marks the run not-ok on a partial write, so a
  broken scan never renders as a normal empty day.
- **`.github/workflows/scan.yml`** — three weekday crons plus
  `workflow_dispatch` for the "Run now" button.

The JSON→Supabase path was tested end to end against a stub server: payload
keys match schema columns exactly, one run + one mover + one tier row written,
exit 0. What has **not** been tested is a real Supabase, a real GitHub Actions
run, or a live ORATS scan feeding it. That's where you start.

**Your job, in this order — stop and show me after step 4:**

1. Create the Supabase project, run `supabase/schema.sql`, confirm RLS
2. Wire the three GitHub secrets, prove the Action with one manual
   `workflow_dispatch` run, and show me real rows landing in Supabase
3. Fix whatever that first real run breaks — assume something will
4. The Next.js dashboard at `/`, reading real rows

I want to see it working end to end before we build the catalyst upload, the
history page, and the trade log.

**Things I care about, in order:**

- **Every tier tile leads with the required move**, in bigger type than the
  multiple. "Needs +8.7%" is the number that decides the trade; "25x" is just
  the prize. A tier needing more than 15% renders grey, not green. Getting this
  backwards would make the tool worse than nothing.
- I open it on my phone at 7am. Mobile layout is the primary one.
- The empty state — no names cleared the screen — must read as normal, not as
  an error. That's the outcome most days.
- It never recommends. No BUY buttons, no scores, no "strong setup". It shows
  what moved and what the chain pays; I decide.

**Ask me before you assume:** my Supabase and Vercel accounts, the GitHub repo
name, and whether the repo should be private (it should).

I'll give you the ORATS token as a secret when you need it — not in chat.
