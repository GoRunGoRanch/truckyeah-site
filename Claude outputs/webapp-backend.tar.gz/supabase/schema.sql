-- Asymmetry web app schema.
-- Paste this whole file into the Supabase SQL editor and run it once.

create table if not exists runs (
  id            bigserial primary key,
  ran_at        timestamptz not null default now(),
  session       text not null,              -- morning | midday | evening
  names_scanned int  not null,
  names_through int  not null,
  weekend       boolean not null default false,
  budget        numeric,
  ok            boolean not null default true,
  error         text
);

create table if not exists movers (
  id           bigserial primary key,
  run_id       bigint references runs(id) on delete cascade,
  symbol       text not null,
  move_pct     numeric not null,
  rvol         numeric,
  price        numeric,
  side         text not null,               -- C | P
  iv_rank      numeric,
  px_chg_1y    numeric,
  sector       text,
  catalyst_age text,
  created_at   timestamptz default now()
);

create table if not exists tiers (
  id            bigserial primary key,
  mover_id      bigint references movers(id) on delete cascade,
  tier          text not null,              -- red | yellow | green
  multiple      numeric not null,
  strike        numeric,
  expiry        date,
  dte           int,
  ask           numeric,
  bid           numeric,
  open_interest int,
  required_move numeric not null,           -- THE column that matters
  contracts     int,
  cost          numeric,
  payout        numeric,
  break_even    numeric,
  reachable     boolean not null,
  note          text
);

create table if not exists catalysts (
  id         bigserial primary key,
  symbol     text not null,
  event_date date not null,
  kind       text,                          -- earnings|fda|product|analyst|macro|other
  note       text,
  source     text default 'upload',
  created_at timestamptz default now(),
  unique (symbol, event_date, kind)
);

create table if not exists trades (
  id          bigserial primary key,
  mover_id    bigint references movers(id),
  symbol      text not null,
  opened_at   timestamptz not null,
  closed_at   timestamptz,
  side        text, strike numeric, expiry date,
  contracts   int, entry_price numeric, exit_price numeric,
  pnl         numeric,
  tier_taken  text,
  notes       text
);

create index if not exists movers_run_idx    on movers(run_id);
create index if not exists tiers_mover_idx   on tiers(mover_id);
create index if not exists runs_ran_at_idx   on runs(ran_at desc);
create index if not exists catalysts_date_idx on catalysts(event_date);

-- Single-user tool. Lock everything down; the service key (server-side only)
-- bypasses RLS, the anon key gets nothing until you add a policy tied to your
-- own auth uid. These are your positions -- do not ship this publicly readable.
alter table runs       enable row level security;
alter table movers     enable row level security;
alter table tiers      enable row level security;
alter table catalysts  enable row level security;
alter table trades     enable row level security;
