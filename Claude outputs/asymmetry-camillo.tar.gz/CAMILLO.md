# Camillo social-arbitrage scan — protocol

This is a **research protocol**, not a screener. It sits beside the quantitative
engine, it does not run inside it. The engine takes direction from a move that
already happened; this asks what will *cause* a move nobody has priced yet.

Where they meet: a Camillo name that clears the board becomes a priority
ticker in `camillo_board.txt`, which `scan_live.py` flags when it gaps on
RVOL. The Camillo side supplies the *why*; the engine supplies the *when* and
the strike ladder.

---

## The core principle

Hidden trend
+ a second, independent confirming trend
+ a publicly traded beneficiary
+ evidence that behavior is turning into spending, contracts or revenue
+ low Wall Street awareness
+ stock not already substantially repriced
+ an identifiable catalyst
+ confirmation on the tape

Prefer the boring supplier, infrastructure company, retailer, component
maker, data provider or contractor underneath an obvious trend. **Find the
glue.**

Prefer stocks under $50 where possible. **A low share price is not a cheap
valuation.** Never confuse the two.

---

## Search surface

Consumer behavior · AI · semiconductors · energy · grid infrastructure ·
data centers · robotics · physical AI · automotive · fashion · beauty ·
girls'/women's sports · GLP-1 and diabetes · healthcare consumer trends ·
marriage and weddings · hobbies · screen-free and offline activity · pets ·
agriculture · defense · logistics · prediction markets · sports betting ·
creator economy · demographic change · teen behavior · industrial trends ·
unusual emerging niches.

---

## The Camillo Score — 0 to 100

| Component | Points |
|---|---|
| Social / search / behavioral acceleration | 25 |
| Evidence of actual spending, contracts, bookings or revenue impact | 20 |
| Demographic / TAM expansion | 15 |
| Strength of a SECOND independently supported intersecting trend | 15 |
| Low Wall Street awareness / information asymmetry | 15 |
| Stock has NOT already substantially repriced for the thesis | 10 |
| **Total** | **100** |

**A rising stock price does not raise the score.** A large move can *reduce*
it, because the information arbitrage has disappeared.

The score measures **information-arbitrage quality**. It does **not** measure
business quality, intrinsic value, probability of profit, expected return, or
safety.

---

## Classification

- **EARLY** — strong behavioral/social evidence, limited company-specific
  financial receipts.
- **DEVELOPING** — company-specific revenue, contracts, bookings or use cases
  are beginning to confirm the thesis.
- **DISCOVERED** — Wall Street, media or the company narrative explicitly
  recognizes the thesis, and/or the stock has substantially repriced.
- **BROKEN** — financial receipts or behavior contradict the thesis.

---

## Evidence vs inference

Every important candidate separates these explicitly:

- **EVIDENCE** — what can actually be verified, with a source and a date.
- **INFERENCE** — what those facts could mean for future revenue or earnings.

Never present inference as established fact. A missing number, reported as
missing, is worth more than a plausible-sounding guess.

---

## Catalyst and tape

The trading framework is: **catalyst + proof on tape + direction + risk/reward.**

Identify discrete upcoming catalysts — earnings, investor conferences,
product launches, regulatory decisions, sporting seasons, contract
announcements, industry conferences, government decisions, clinical events,
customer launches.

Then evaluate: when the catalyst became public · whether it is surprising ·
whether the market already knows · price response · volume · relative
strength · whether price confirms the thesis · invalidation level · chase
risk.

**Do not force a trade when catalyst and tape disagree.** A high score with a
broken tape is a watch item, not an entry.

---

## Options layer

Investigate the chain only for candidates scoring **90+**, and for unusually
compelling **80+** candidates that have a discrete upcoming catalyst.

Analyze: expirations around the catalyst · strikes · premium · bid/ask
spread · volume · open interest · implied volatility · implied move ·
break-even · maximum premium at risk · intrinsic vs extrinsic · IV-crush
risk · liquidity · chase risk.

Model scenario returns at **+5%, +10%, +15%, +20%, unchanged, −10%**, and
compare shares vs long calls vs call spreads.

**Do not recommend options merely because leverage produces a spectacular
hypothetical return.** If the options are illiquid, overpriced, or the IV
makes risk/reward unattractive, state plainly:

> **NO CLEAN OPTIONS SETUP.**

Sizing is governed by `engine/risk.py` — 5 contracts, $500 per trade, $1,500
per day, one position per underlying, quarter-Kelly, no override. The Camillo
protocol supplies ideas; it does not supply size.

---

## Performance ledger

`state/camillo_ledger.csv` is prospective and append-only.

The moment a company **first** scores 80+, record: ticker, date, stock price,
Camillo Score, stage, thesis, next catalyst. **Never change that historical
entry.**

On every subsequent scan, compute: current price · return since first 80+ ·
maximum favorable excursion · maximum drawdown where data permits · score
change · stage change · catalyst outcome · whether the thesis was confirmed
or broken.

This exists to prevent cherry-picking. **Track losers as carefully as
winners.**

---

## ASO — the first prospective test (preserved benchmark)

Academy Sports + Outdoors was repeatedly the #1 candidate **before** its
September 2026 earnings move.

Pre-event: ASO ~$44–45, Camillo Score 96/100, rank #1.

Original thesis: record girls' sports participation + explosive girls' flag
football growth + youth/team sports growth + the screen-free/offline physical
activity trend + required spending on footwear, apparel and equipment → a
potentially underrecognized demand beneficiary in Academy Sports.

Earnings were identified beforehand as the receipt test. After earnings the
stock jumped sharply into the $50s.

**Do not claim girls' sports caused the earnings beat.** The correct
conclusion: the thesis was identified prospectively, Academy subsequently
produced stronger results and guidance, and the stock repriced — but granular
category disclosure does not establish causation. Because the stock repriced,
ASO's score must **fall** as the low-awareness and not-yet-priced components
disappear.

### ASO options test (hypothetical, retrospective)

September 4, 2026 · 50 ASO September 18 $47.50 calls · ~$1.25 premium ·
50 × 100 × $1.25 = **$6,250 at risk.**

This was a hypothetical retrospective analysis. **It was not an executed
trade.** It is preserved as a worked example for testing the options
methodology — and as a standing reminder that 50 contracts and $6,250 are
each an order of magnitude outside `engine/risk.py`.

---

## Weekly run

On **"RUN THE CAMILLO SCAN"**, search *current* information. Do not rely on
prior knowledge. Find genuinely new evidence since the previous scan.

Look for: unexpected contracts · accelerating search or social behavior ·
retail sell-outs · participation statistics · new customer announcements ·
management commentary · bookings and backlog changes · capacity expansion ·
industry shortages · product launches · regulatory changes · new partnerships
· unusual volume · meaningful insider or company behavior · anything that has
not yet reached mainstream analyst narratives.

Cross-check every social signal against a financial receipt.

---

## Output format

1. **DATE**
2. **NEW 80+ CANDIDATES**
3. **MATERIAL SCORE CHANGES**
4. One table: `Ticker | Price | Camillo Score | Score Change | Stage | Trend Intersection | Next Catalyst`
5. Analysis of the top candidates, each with:
   EVIDENCE · INFERENCE · WHY THIS COULD HIT REVENUE · WHAT WALL STREET MAY BE
   MISSING · CATALYST · TAPE · INVALIDATION · OPTIONS
6. **#1 CAMILLO SETUP** — named only when the evidence justifies it.

If nothing deserves ≥80, say **NO NEW 80+ SETUP.** Do not manufacture a
winner.

---

## Critical experiment rule

This is a test of whether the methodology has genuine predictive value.
Therefore:

- No hindsight scoring.
- No changing historical entry prices.
- No hiding losers.
- No claiming causality without evidence.
- No treating a stock move as proof of the original thesis.
- No buying or chasing merely because something scored highly.

When a thesis becomes mainstream, **lower** its information-arbitrage score
even if the company continues performing well.
